package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ReviewRepository extends JpaRepository<Review, UUID> {
    
    List<Review> findByAppraisalFormId(UUID appraisalFormId);
    
    Optional<Review> findByReviewerAndAppraisalForm(User reviewer, AppraisalForm appraisalForm);
    
    List<Review> findByReviewer(User reviewer);
    
    List<Review> findByDecision(ReviewDecision decision);
    
    @Query("SELECT COUNT(r) FROM Review r WHERE r.decision = :decision")
    long countByDecision(@Param("decision") ReviewDecision decision);
    
    @Query("SELECT COUNT(r) FROM Review r WHERE r.decision = 'REJECTED'")
    long countRejected();
    
    @Query("SELECT r FROM Review r WHERE r.appraisalForm.id = :formId ORDER BY r.reviewedAt DESC")
    List<Review> findByAppraisalFormIdOrderByReviewedAt(@Param("formId") UUID formId);
    
    // New methods for DCM department filtering
    @Query("SELECT r FROM Review r WHERE r.reviewer = :reviewer AND r.level = :level")
    List<Review> findByReviewerAndLevel(@Param("reviewer") User reviewer, @Param("level") ReviewLevel level);
    
    @Query("SELECT COUNT(r) FROM Review r WHERE r.reviewer = :reviewer AND r.level = :level")
    long countByReviewerAndLevel(@Param("reviewer") User reviewer, @Param("level") ReviewLevel level);
    
    // Additional helpful methods
    @Query("SELECT r FROM Review r WHERE r.reviewer.department.name = :departmentName AND r.level = :level")
    List<Review> findByReviewerDepartmentAndLevel(@Param("departmentName") String departmentName, @Param("level") ReviewLevel level);
    
    // Count reviews by department and level
    @Query("SELECT COUNT(r) FROM Review r WHERE r.reviewer.department.name = :departmentName AND r.level = :level")
    long countByReviewerDepartmentAndLevel(@Param("departmentName") String departmentName, @Param("level") ReviewLevel level);
    
    // Count reviews by reviewer, level and decision
    @Query("SELECT COUNT(r) FROM Review r WHERE r.reviewer = :reviewer AND r.level = :level AND r.decision = :decision")
    long countByReviewerAndLevelAndDecision(@Param("reviewer") User reviewer, @Param("level") ReviewLevel level, @Param("decision") ReviewDecision decision);
}
