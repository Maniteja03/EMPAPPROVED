package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.auth.LoginRequestDTO;
import com.cvrce.apraisal.dto.auth.LoginResponseDTO;
import com.cvrce.apraisal.dto.user.UserCreateDTO;

public interface AuthService {
    LoginResponseDTO login(LoginRequestDTO request);
    
    /**
     * Register new user with auto-generated temporary password
     * @param dto User creation data
     * @return Generated temporary password for email notification
     */
    String register(UserCreateDTO dto);
}
