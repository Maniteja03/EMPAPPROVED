package com.cvrce.apraisal.dto.committee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeWorkloadDTO {
    private String committeeMemberName;
    private String academicYear;
    private int currentWorkload;
    private int completedReviews;
    private int pendingReviews;
    private int totalAssignedForms;
    private double completionRate;
    private double averageReviewTime;
    private boolean canTakeMoreWork;
    private int maxWorkloadCapacity;
    private String workloadStatus;
} 