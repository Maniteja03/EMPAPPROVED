package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.FormAssignment;
import com.cvrce.apraisal.entity.FormLock;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.repo.FormAssignmentRepository;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import com.cvrce.apraisal.service.DCMService;
import com.cvrce.apraisal.service.FormLockingService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class DCMServiceImpl implements DCMService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final AppraisalWorkflowService workflowService;
    private final FormAssignmentRepository formAssignmentRepository;
    private final FormLockingService formLockingService;

    /**
     * Get current authenticated DCM user
     */
    private User getCurrentDCM() {
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current DCM user not found"));
    }

    @Override
    public Map<String, Object> getDCMDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        
        // Get current DCM and their department
        User currentDCM = getCurrentDCM();
        String departmentName = currentDCM.getDepartment().getName();
        
        log.info("Getting DCM dashboard for {} from {} department", currentDCM.getFullName(), departmentName);
        
        // FIXED: Get assigned reviews count ONLY for this specific DCM (consistent with getAssignedReviews)
        long assignedReviews = formAssignmentRepository
                .findActiveAssignmentsByReviewer(currentDCM)
                .stream()
                .filter(assignment -> "DCM_REVIEW".equals(assignment.getAssignmentType()))
                .mapToLong(assignment -> assignment.getAppraisalForm().getStatus() == AppraisalStatus.DEPARTMENT_REVIEW ? 1 : 0)
                .sum();
        
        // Get completed reviews by current DCM only
        long completedReviews = reviewRepository.countByReviewerAndLevel(currentDCM, ReviewLevel.DEPARTMENT_REVIEW);
        
        // Get pending reviews for this DCM
        long pendingReviews = Math.max(0, assignedReviews - completedReviews);
        
        // Get active locks by this DCM
        long activeLocks = formLockingService.getActiveLocksByReviewer(currentDCM).size();
        
        dashboard.put("assignedReviews", assignedReviews);
        dashboard.put("completedReviews", completedReviews);
        dashboard.put("pendingReviews", pendingReviews);
        dashboard.put("activeLocks", activeLocks);
        dashboard.put("department", departmentName);
        dashboard.put("dcmName", currentDCM.getFullName());
        dashboard.put("lastUpdated", LocalDateTime.now());
        
        log.info("DCM Dashboard: {} assigned, {} completed, {} pending, {} locked for {} department", 
                assignedReviews, completedReviews, pendingReviews, activeLocks, departmentName);
        
        return dashboard;
    }

    @Override
    public Page<AppraisalFormDTO> getAssignedReviews(Pageable pageable) {
        // Get current DCM and their department
        User currentDCM = getCurrentDCM();
        String departmentName = currentDCM.getDepartment().getName();
        
        log.info("Getting assigned reviews for DCM {} from {} department", 
                currentDCM.getFullName(), departmentName);
        
        // FIXED: Get forms ONLY assigned to this specific DCM via FormAssignmentService
        List<AppraisalForm> assignedForms = formAssignmentRepository
                .findActiveAssignmentsByReviewer(currentDCM)
                .stream()
                .filter(assignment -> "DCM_REVIEW".equals(assignment.getAssignmentType()))
                .map(FormAssignment::getAppraisalForm)
                .filter(form -> form.getStatus() == AppraisalStatus.DEPARTMENT_REVIEW)
                .collect(Collectors.toList());
        
        // Convert to DTOs
        List<AppraisalFormDTO> dtoList = assignedForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Apply sorting and pagination
        dtoList = applySorting(dtoList, pageable);
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = start < dtoList.size() ? dtoList.subList(start, end) : new ArrayList<>();
        
        log.info("Found {} forms specifically assigned to DCM {} in {} department", 
                dtoList.size(), currentDCM.getFullName(), departmentName);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    /**
     * NEW: Start DCM review with form locking (like committee reviews)
     */
    @Override
    public Optional<FormLock> startFormReview(UUID formId, String dcmEmail) {
        User dcm = userRepository.findByEmail(dcmEmail)
                .orElseThrow(() -> new ResourceNotFoundException("DCM not found: " + dcmEmail));
        
        // Check if form is assigned to this DCM
        Optional<FormAssignment> assignment = formAssignmentRepository
                .findActiveAssignmentsByReviewer(dcm)
                .stream()
                .filter(a -> "DCM_REVIEW".equals(a.getAssignmentType()))
                .filter(a -> a.getAppraisalForm().getId().equals(formId))
                .findFirst();
        
        if (assignment.isEmpty()) {
            log.warn("Form {} is not assigned to DCM {}", formId, dcm.getFullName());
            return Optional.empty();
        }
        
        // Attempt to lock the form
        return formLockingService.lockForm(formId, dcm, ReviewLevel.DEPARTMENT_REVIEW);
    }

    /**
     * NEW: Get form for DCM review (with lock check)
     */
    @Override
    public AppraisalFormDTO getFormForReview(UUID formId, String dcmEmail) {
        User dcm = userRepository.findByEmail(dcmEmail)
                .orElseThrow(() -> new ResourceNotFoundException("DCM not found: " + dcmEmail));
        
        AppraisalForm form = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found"));
        
        // Check if form is locked by this DCM
        if (!formLockingService.isFormLockedByReviewer(formId, dcm)) {
            throw new IllegalStateException("Form is not locked by you for review");
        }
        
        return mapToDTO(form);
    }

    @Override
    @Transactional
    public ReviewDTO submitInitialReview(ReviewDTO reviewDTO, String currentUserEmail) {
        // Validate appraisal exists and is in correct state
        AppraisalForm appraisal = appraisalFormRepository.findById(reviewDTO.getAppraisalFormId())
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.DEPARTMENT_REVIEW) {
            throw new IllegalStateException("Appraisal is not in correct state for DCM review");
        }
        
        // SECURITY FIX: Get reviewer from authenticated user, not from client
        User reviewer = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current user not found: " + currentUserEmail));
        
        // DEPARTMENT SECURITY: Ensure DCM can only review forms from their department
        String dcmDepartment = reviewer.getDepartment().getName();
        String formDepartment = appraisal.getUser().getDepartment().getName();
        
        if (!dcmDepartment.equals(formDepartment)) {
            log.warn("SECURITY VIOLATION: DCM {} from {} tried to review form from {} department", 
                    reviewer.getFullName(), dcmDepartment, formDepartment);
            throw new SecurityException("You can only review appraisals from your own department");
        }
        
        // FORM LOCKING: Check if form is locked by this reviewer
        if (!formLockingService.isFormLockedByReviewer(appraisal.getId(), reviewer)) {
            throw new IllegalStateException("Form is not locked by you for review");
        }
        
        // Check if DCM already reviewed this form
        Optional<Review> existingReview = reviewRepository.findByReviewerAndAppraisalForm(reviewer, appraisal);
        if (existingReview.isPresent()) {
            throw new IllegalStateException("You have already reviewed this appraisal form");
        }
        
        // Create review
        Review review = Review.builder()
                .reviewer(reviewer)
                .appraisalForm(appraisal)
                .decision(ReviewDecision.valueOf(reviewDTO.getDecision()))
                .remarks(reviewDTO.getRemarks())
                .level(ReviewLevel.DEPARTMENT_REVIEW)
                .reviewedAt(LocalDateTime.now())
                .build();
        
        Review savedReview = reviewRepository.save(review);
        
        // Update appraisal status using workflow service
        AppraisalStatus newStatus = workflowService.transitionToNextStage(
            reviewDTO.getAppraisalFormId(), 
            appraisal.getStatus(), 
            reviewDTO.getDecision()
        );
        appraisal.setStatus(newStatus);
        appraisalFormRepository.save(appraisal);
        
        // Release form lock
        formLockingService.unlockForm(appraisal.getId(), reviewer);
        
        log.info("DCM {} from {} department submitted {} review for appraisal {} (Staff: {})", 
                reviewer.getFullName(), dcmDepartment, reviewDTO.getDecision(), 
                reviewDTO.getAppraisalFormId(), appraisal.getUser().getFullName());
        
        return mapReviewToDTO(savedReview);
    }

    /**
     * NEW: Cancel DCM review and release lock
     */
    @Override
    public boolean cancelFormReview(UUID formId, String dcmEmail) {
        User dcm = userRepository.findByEmail(dcmEmail)
                .orElseThrow(() -> new ResourceNotFoundException("DCM not found: " + dcmEmail));
        
        return formLockingService.unlockForm(formId, dcm);
    }

    /**
     * NEW: Get forms currently locked by this DCM
     */
    @Override
    public List<AppraisalFormDTO> getMyActiveReviews(String dcmEmail) {
        User dcm = userRepository.findByEmail(dcmEmail)
                .orElseThrow(() -> new ResourceNotFoundException("DCM not found: " + dcmEmail));
        
        return formLockingService.getActiveLocksByReviewer(dcm)
                .stream()
                .filter(lock -> lock.getReviewLevel() == ReviewLevel.DEPARTMENT_REVIEW)
                .map(lock -> appraisalFormRepository.findById(lock.getFormId()).orElse(null))
                .filter(Objects::nonNull)
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AppraisalFormDTO getAppraisalForDCMReview(UUID formId) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.DEPARTMENT_REVIEW) {
            throw new IllegalStateException("Appraisal is not available for DCM review");
        }
        
        return mapToDTO(appraisal);
    }

    @Override
    public Map<String, Object> getDCMStatistics(String academicYear) {
        User currentDCM = getCurrentDCM();
        String departmentName = currentDCM.getDepartment().getName();
        
        Map<String, Object> stats = new HashMap<>();
        
        // Get DCM-specific statistics (not all department forms)
        List<FormAssignment> dcmAssignments = formAssignmentRepository
                .findActiveAssignmentsByReviewer(currentDCM)
                .stream()
                .filter(assignment -> "DCM_REVIEW".equals(assignment.getAssignmentType()))
                .collect(Collectors.toList());
        
        if (academicYear != null) {
            dcmAssignments = dcmAssignments.stream()
                    .filter(assignment -> academicYear.equals(assignment.getAppraisalForm().getAcademicYear()))
                    .collect(Collectors.toList());
        }
        
        long totalForms = dcmAssignments.size();
        long reviewedForms = reviewRepository.countByReviewerAndLevel(currentDCM, ReviewLevel.DEPARTMENT_REVIEW);
        long pendingForms = Math.max(0, totalForms - reviewedForms);
        
        stats.put("department", departmentName);
        stats.put("academicYear", academicYear);
        stats.put("totalFormsAssigned", totalForms);
        stats.put("formsReviewed", reviewedForms);
        stats.put("pendingReviews", pendingForms);
        stats.put("completionRate", totalForms > 0 ? (double) reviewedForms / totalForms * 100 : 0.0);
        
        return stats;
    }

    @Override
    public void requestReassignment(UUID formId, String reason) {
        // Implementation for DCM to request form reassignment
        log.info("DCM requested reassignment for form {} with reason: {}", formId, reason);
        // This could trigger a notification to HOD or admin
    }

    // Helper methods
    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .locked(form.isLocked())
                .userId(form.getUser().getId())
                .userFullName(form.getUser().getFullName())
                .userDepartment(form.getUser().getDepartment().getName())
                .submittedAsRole(form.getSubmittedAsRole())
                .build();
    }

    private ReviewDTO mapReviewToDTO(Review review) {
        return ReviewDTO.builder()
                .id(review.getId())
                .appraisalFormId(review.getAppraisalForm().getId())
                .reviewerId(review.getReviewer().getId())
                .reviewerName(review.getReviewer().getFullName())
                .reviewerDepartment(review.getReviewer().getDepartment().getName())
                .decision(review.getDecision().name())
                .remarks(review.getRemarks())
                .level(review.getLevel().name())
                .reviewedAt(review.getReviewedAt())
                .build();
    }

    private List<AppraisalFormDTO> applySorting(List<AppraisalFormDTO> dtoList, Pageable pageable) {
        // Apply sorting based on pageable requirements
        if (pageable.getSort().isSorted()) {
            // Implement sorting logic based on sort criteria
            return dtoList.stream()
                    .sorted((a, b) -> {
                        // Default sort by submission date descending
                        if (a.getSubmittedDate() == null && b.getSubmittedDate() == null) return 0;
                        if (a.getSubmittedDate() == null) return 1;
                        if (b.getSubmittedDate() == null) return -1;
                        return b.getSubmittedDate().compareTo(a.getSubmittedDate());
                    })
                    .collect(Collectors.toList());
        }
        return dtoList;
    }
} 