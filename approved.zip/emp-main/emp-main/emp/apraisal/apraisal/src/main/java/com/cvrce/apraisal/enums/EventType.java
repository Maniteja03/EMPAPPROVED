package com.cvrce.apraisal.enums;

public enum EventType {
    ORGANIZED,
    ATTENDED
}
