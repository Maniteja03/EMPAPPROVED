package com.cvrce.apraisal.exception;

import lombok.Getter;

@Getter
public class AppraisalBusinessException extends RuntimeException {
    
    private final String errorCode;
    private final Object[] args;
    
    public AppraisalBusinessException(String message) {
        super(message);
        this.errorCode = "BUSINESS_ERROR";
        this.args = new Object[0];
    }
    
    public AppraisalBusinessException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
        this.args = new Object[0];
    }
    
    public AppraisalBusinessException(String message, String errorCode, Object... args) {
        super(message);
        this.errorCode = errorCode;
        this.args = args;
    }
    
    public AppraisalBusinessException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "BUSINESS_ERROR";
        this.args = new Object[0];
    }
    
    public AppraisalBusinessException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.args = new Object[0];
    }
}

// Specific business exception classes
class FormSubmissionException extends AppraisalBusinessException {
    public FormSubmissionException(String message) {
        super(message, "FORM_SUBMISSION_ERROR");
    }
}

class ReviewWorkflowException extends AppraisalBusinessException {
    public ReviewWorkflowException(String message) {
        super(message, "REVIEW_WORKFLOW_ERROR");
    }
}

class DeadlineViolationException extends AppraisalBusinessException {
    public DeadlineViolationException(String message) {
        super(message, "DEADLINE_VIOLATION");
    }
}

class UnauthorizedAccessException extends AppraisalBusinessException {
    public UnauthorizedAccessException(String message) {
        super(message, "UNAUTHORIZED_ACCESS");
    }
}

class InvalidAppraisalStateException extends AppraisalBusinessException {
    public InvalidAppraisalStateException(String message) {
        super(message, "INVALID_STATE");
    }
}

class DuplicateReviewException extends AppraisalBusinessException {
    public DuplicateReviewException(String message) {
        super(message, "DUPLICATE_REVIEW");
    }
}

class FileProcessingException extends AppraisalBusinessException {
    public FileProcessingException(String message) {
        super(message, "FILE_PROCESSING_ERROR");
    }
    
    public FileProcessingException(String message, Throwable cause) {
        super(message, "FILE_PROCESSING_ERROR", cause);
    }
}

class DataValidationException extends AppraisalBusinessException {
    public DataValidationException(String message) {
        super(message, "DATA_VALIDATION_ERROR");
    }
}

class InsufficientPermissionsException extends AppraisalBusinessException {
    public InsufficientPermissionsException(String message) {
        super(message, "INSUFFICIENT_PERMISSIONS");
    }
} 