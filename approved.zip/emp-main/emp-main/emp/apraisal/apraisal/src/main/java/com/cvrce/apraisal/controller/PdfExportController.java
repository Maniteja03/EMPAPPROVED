package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.service.AppraisalFormService;
import com.cvrce.apraisal.service.PdfExportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping("/api/pdf")
@RequiredArgsConstructor
@Slf4j
public class PdfExportController {

    private final PdfExportService pdfExportService;
    private final AppraisalFormService appraisalFormService;

    @GetMapping("/download/{formId}")
    @PreAuthorize("hasRole('STAFF') or hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<Resource> downloadAppraisalPdf(@PathVariable UUID formId) throws IOException {
        log.info("Downloading PDF for form ID: {}", formId);

        // Critical security fix: Check ownership before allowing PDF download
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized PDF download attempt for form {} by user {}", formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        String filePath = pdfExportService.generateAppraisalPdf(formId);
        File file = new File(filePath);

        if (!file.exists()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        FileSystemResource resource = new FileSystemResource(file);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename(file.getName())
                .build());
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentLength(file.length());

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }
}
