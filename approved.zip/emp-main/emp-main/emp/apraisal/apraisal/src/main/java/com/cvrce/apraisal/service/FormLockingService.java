package com.cvrce.apraisal.service;

import com.cvrce.apraisal.entity.FormLock;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.ReviewLevel;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface FormLockingService {
    
    /**
     * Attempt to lock a form for review by a specific reviewer
     * @param formId The form to lock
     * @param reviewer The user attempting to lock the form
     * @param reviewLevel The level of review (COMMITTEE_REVIEW, etc.)
     * @return FormLock if successful, empty if form is already locked by someone else
     */
    Optional<FormLock> lockForm(UUID formId, User reviewer, ReviewLevel reviewLevel);
    
    /**
     * Release a form lock (when review is completed or cancelled)
     * @param formId The form to unlock
     * @param reviewer The user releasing the lock
     * @return true if lock was successfully released
     */
    boolean unlockForm(UUID formId, User reviewer);
    
    /**
     * Check if a form is currently locked
     * @param formId The form to check
     * @return true if form is locked by any reviewer
     */
    boolean isFormLocked(UUID formId);
    
    /**
     * Check if a form is locked by a specific reviewer
     * @param formId The form to check
     * @param reviewer The user to check
     * @return true if form is locked by this specific reviewer
     */
    boolean isFormLockedByReviewer(UUID formId, User reviewer);
    
    /**
     * Get the current lock for a form (if any)
     * @param formId The form to check
     * @return FormLock if form is locked, empty otherwise
     */
    Optional<FormLock> getCurrentLock(UUID formId);
    
    /**
     * Get all active locks for a specific reviewer
     * @param reviewer The reviewer to check
     * @return List of active locks for this reviewer
     */
    List<FormLock> getActiveLocksByReviewer(User reviewer);
    
    /**
     * Clean up expired locks (called periodically)
     * @return Number of expired locks that were cleaned up
     */
    int cleanupExpiredLocks();
    
    /**
     * Extend lock expiry time (when reviewer is actively working)
     * @param formId The form lock to extend
     * @param reviewer The reviewer requesting extension
     * @param additionalMinutes Minutes to add to current expiry
     * @return true if lock was successfully extended
     */
    boolean extendLock(UUID formId, User reviewer, int additionalMinutes);
    
    /**
     * Force unlock a form (admin function)
     * @param formId The form to force unlock
     * @return true if unlock was successful
     */
    boolean forceUnlock(UUID formId);
    
    /**
     * Get reviewer's current workload (number of active locks)
     * @param reviewer The reviewer to check
     * @return Number of forms currently locked by this reviewer
     */
    long getReviewerWorkload(User reviewer);
    
    /**
     * Check if reviewer can take more work (workload limit check)
     * @param reviewer The reviewer to check
     * @param maxWorkload Maximum allowed concurrent locks
     * @return true if reviewer can take more forms for review
     */
    boolean canReviewerTakeMoreWork(User reviewer, int maxWorkload);
} 