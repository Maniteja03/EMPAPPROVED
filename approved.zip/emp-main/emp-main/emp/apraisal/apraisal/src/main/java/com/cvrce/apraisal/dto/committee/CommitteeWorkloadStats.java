package com.cvrce.apraisal.dto.committee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeWorkloadStats {
    private String academicYear;
    private int totalCommitteeMembers;
    private double averageWorkloadPerMember;
    private int totalFormsUnderCommitteeReview;
    private int totalFormsCompleted;
    private double overallCompletionRate;
    private List<DepartmentStats> departmentStats;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DepartmentStats {
        private String departmentName;
        private int committeeMembers;
        private int formsAssigned;
        private int formsCompleted;
        private double departmentCompletionRate;
    }
    
    // Setters for backward compatibility
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public void setTotalCommitteeMembers(int totalCommitteeMembers) { this.totalCommitteeMembers = totalCommitteeMembers; }
    public void setAverageWorkloadPerMember(double averageWorkloadPerMember) { this.averageWorkloadPerMember = averageWorkloadPerMember; }
    public void setTotalFormsUnderCommitteeReview(int totalFormsUnderCommitteeReview) { this.totalFormsUnderCommitteeReview = totalFormsUnderCommitteeReview; }
    public void setTotalFormsCompleted(int totalFormsCompleted) { this.totalFormsCompleted = totalFormsCompleted; }
    public void setDepartmentStats(List<DepartmentStats> departmentStats) { this.departmentStats = departmentStats; }
} 