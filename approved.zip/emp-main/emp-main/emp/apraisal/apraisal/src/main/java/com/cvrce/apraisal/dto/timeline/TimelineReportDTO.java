package com.cvrce.apraisal.dto.timeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimelineReportDTO {
    private UUID timelineId;
    private String academicYear;
    private String currentPhase;
    private double completionPercentage;
    private long totalDurationDays;
    private long daysElapsed;
    private long daysRemaining;
    private int totalStaffCount;
    private int staffSubmitted;
    private int departmentsCompleted;
    private int committeeReviewsCompleted;
    private boolean isOnTrack;
    private List<String> upcomingDeadlines;
    private List<String> overdueItems;
} 