package com.cvrce.apraisal.dto.timeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimelineSetupDTO {
    
    @NotBlank(message = "Academic year is required")
    private String academicYear; // e.g., "2024-25"
    
    @NotNull(message = "Staff upload start date is required")
    @Future(message = "Staff upload start date must be in the future")
    private LocalDate staffUploadStartDate;
    
    @NotNull(message = "Staff upload deadline is required")
    @Future(message = "Staff upload deadline must be in the future")
    private LocalDate staffUploadDeadline;
    
    @NotNull(message = "HOD DCM assignment deadline is required")
    @Future(message = "HOD DCM assignment deadline must be in the future")
    private LocalDate hodDcmAssignmentDeadline;
    
    @NotNull(message = "DCM review deadline is required")
    @Future(message = "DCM review deadline must be in the future")
    private LocalDate dcmReviewDeadline;
    
    @NotNull(message = "HOD review deadline is required")
    @Future(message = "HOD review deadline must be in the future")
    private LocalDate hodReviewDeadline;
    
    @NotNull(message = "Committee review deadline is required")
    @Future(message = "Committee review deadline must be in the future")
    private LocalDate committeeReviewDeadline;
    
    @NotNull(message = "Chairperson review deadline is required")
    @Future(message = "Chairperson review deadline must be in the future")
    private LocalDate chairpersonReviewDeadline;
    
    @NotNull(message = "Principal bulk submission date is required")
    @Future(message = "Principal bulk submission date must be in the future")
    private LocalDate principalBulkSubmissionDate;
    
    // Optional settings
    private String timelineDescription;
    
    @Builder.Default
    private boolean sendDeadlineReminders = true;
    
    @Min(value = 1, message = "Reminder days must be at least 1")
    @Max(value = 14, message = "Reminder days cannot exceed 14")
    @Builder.Default
    private int reminderDaysBeforeDeadline = 3;
    
    // Statistics (will be auto-calculated)
    private Integer totalStaffCount;
    private Integer totalDepartmentsCount;
    
    // Helper methods for validation
    public boolean isValidSequence() {
        return staffUploadStartDate.isBefore(staffUploadDeadline) &&
               staffUploadDeadline.isBefore(hodDcmAssignmentDeadline) &&
               hodDcmAssignmentDeadline.isBefore(dcmReviewDeadline) &&
               dcmReviewDeadline.isBefore(hodReviewDeadline) &&
               hodReviewDeadline.isBefore(committeeReviewDeadline) &&
               committeeReviewDeadline.isBefore(chairpersonReviewDeadline) &&
               chairpersonReviewDeadline.isBefore(principalBulkSubmissionDate);
    }
    
    public long getTotalTimelineDurationDays() {
        if (staffUploadStartDate != null && principalBulkSubmissionDate != null) {
            return staffUploadStartDate.until(principalBulkSubmissionDate).getDays();
        }
        return 0;
    }
    
    public String getTimelineSummary() {
        return String.format("Academic Year %s: %d days from %s to %s", 
                academicYear, getTotalTimelineDurationDays(), 
                staffUploadStartDate, principalBulkSubmissionDate);
    }
} 