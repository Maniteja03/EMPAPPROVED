package com.cvrce.apraisal.dto.timeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppraisalTimelineDTO {
    
    private UUID id;
    private String academicYear;
    private UUID createdByChairpersonId;
    private String createdByChairpersonName;
    
    // All phase deadlines
    private LocalDate staffUploadStartDate;
    private LocalDate staffUploadDeadline;
    private LocalDate hodDcmAssignmentDeadline;
    private LocalDate dcmReviewDeadline;
    private LocalDate hodReviewDeadline;
    private LocalDate committeeReviewDeadline;
    private LocalDate chairpersonReviewDeadline;
    private LocalDate principalBulkSubmissionDate;
    
    // Timeline status
    private boolean isActive;
    private String currentPhase;
    private String timelineDescription;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime finalizedAt;
    
    // Notification settings
    private boolean sendDeadlineReminders;
    private int reminderDaysBeforeDeadline;
    
    // Statistics
    private Integer totalStaffCount;
    private Integer totalDepartmentsCount;
    
    // Calculated fields
    private long totalDurationDays;
    private double completionPercentage;
    private long daysRemainingForCurrentPhase;
    private boolean isOverdue;
    private boolean isFinalized;
    
    // Progress tracking
    private int staffSubmissionCount;
    private int dcmAssignmentCount;
    private int hodReviewCount;
    private int committeeReviewCount;
    private int chairpersonReviewCount;
    
    // Helper methods
    public String getCurrentPhaseDescription() {
        return switch (currentPhase) {
            case "TIMELINE_SET" -> "Timeline has been set, waiting for staff upload phase to begin";
            case "STAFF_UPLOAD" -> "Staff Upload Phase - Staff members can submit their appraisals";
            case "HOD_DCM_ASSIGNMENT" -> "HOD DCM Assignment Phase - HODs must assign DCM members";
            case "DCM_REVIEW" -> "DCM Review Phase - DCM members reviewing staff appraisals";
            case "HOD_REVIEW" -> "HOD Review Phase - HODs reviewing DCM-approved appraisals";
            case "COMMITTEE_REVIEW" -> "Committee Review Phase - College committee reviewing appraisals";
            case "CHAIRPERSON_REVIEW" -> "Chairperson Review Phase - Chairperson reviewing committee-approved appraisals";
            case "PRINCIPAL_REVIEW" -> "Principal Review Phase - Principal preparing for bulk submission";
            case "COMPLETED" -> "Timeline completed - All appraisals processed";
            default -> "Unknown phase";
        };
    }
    
    public String getTimelineStatus() {
        if (!isActive) return "INACTIVE";
        if (isOverdue) return "OVERDUE";
        if (isFinalized) return "FINALIZED";
        return "ACTIVE";
    }
    
    public LocalDate getCurrentPhaseDeadline() {
        return switch (currentPhase) {
            case "STAFF_UPLOAD" -> staffUploadDeadline;
            case "HOD_DCM_ASSIGNMENT" -> hodDcmAssignmentDeadline;
            case "DCM_REVIEW" -> dcmReviewDeadline;
            case "HOD_REVIEW" -> hodReviewDeadline;
            case "COMMITTEE_REVIEW" -> committeeReviewDeadline;
            case "CHAIRPERSON_REVIEW" -> chairpersonReviewDeadline;
            case "PRINCIPAL_REVIEW" -> principalBulkSubmissionDate;
            default -> null;
        };
    }
    
    public boolean canBeModified() {
        return isActive && !isFinalized && 
               LocalDate.now().isBefore(staffUploadStartDate);
    }
    
    public String getProgressSummary() {
        return String.format("Phase: %s | %.1f%% Complete | %d days remaining", 
                currentPhase, completionPercentage, daysRemainingForCurrentPhase);
    }
} 