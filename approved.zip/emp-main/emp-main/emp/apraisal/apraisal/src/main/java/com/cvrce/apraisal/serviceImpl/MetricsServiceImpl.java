package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.entity.SystemMetrics;
import com.cvrce.apraisal.repo.SystemMetricsRepository;
import com.cvrce.apraisal.service.MetricsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class MetricsServiceImpl implements MetricsService {

    private final SystemMetricsRepository systemMetricsRepository;

    @Override
    @Transactional
    public void recordResponseTime(String endpoint, long responseTimeMs) {
        recordMetric("response_time_" + sanitizeEndpoint(endpoint), (double) responseTimeMs, "ms", 
                    SystemMetrics.MetricType.PERFORMANCE, "API Response Time");
    }

    @Override
    @Transactional
    public void recordDatabaseQueryTime(String queryType, long queryTimeMs) {
        recordMetric("db_query_time_" + queryType, (double) queryTimeMs, "ms", 
                    SystemMetrics.MetricType.PERFORMANCE, "Database Query Time");
    }

    @Override
    @Transactional
    public void recordFileUploadTime(String fileType, long uploadTimeMs) {
        recordMetric("file_upload_time_" + fileType, (double) uploadTimeMs, "ms", 
                    SystemMetrics.MetricType.PERFORMANCE, "File Upload Time");
    }

    @Override
    @Transactional
    public void recordUserLogin(String userRole) {
        recordMetric("user_login_" + userRole, 1.0, "count", 
                    SystemMetrics.MetricType.USAGE, "User Login Count");
    }

    @Override
    @Transactional
    public void recordFeatureUsage(String featureName, String userRole) {
        recordMetric("feature_usage_" + featureName + "_" + userRole, 1.0, "count", 
                    SystemMetrics.MetricType.USAGE, "Feature Usage Count");
    }

    @Override
    @Transactional
    public void recordAppraisalSubmission(String department, String academicYear) {
        recordMetric("appraisal_submission_" + department + "_" + academicYear, 1.0, "count", 
                    SystemMetrics.MetricType.BUSINESS, "Appraisal Submission Count");
    }

    @Override
    @Transactional
    public void recordReviewCompletion(String reviewLevel, String department) {
        recordMetric("review_completion_" + reviewLevel + "_" + department, 1.0, "count", 
                    SystemMetrics.MetricType.BUSINESS, "Review Completion Count");
    }

    @Override
    @Transactional
    public void recordSystemLoad(double cpuUsage, double memoryUsage, double diskUsage) {
        recordMetric("cpu_usage", cpuUsage, "percent", SystemMetrics.MetricType.SYSTEM, "CPU Usage");
        recordMetric("memory_usage", memoryUsage, "percent", SystemMetrics.MetricType.SYSTEM, "Memory Usage");
        recordMetric("disk_usage", diskUsage, "percent", SystemMetrics.MetricType.SYSTEM, "Disk Usage");
    }

    @Override
    @Transactional
    public void recordConcurrentUsers(int activeUsers) {
        recordMetric("concurrent_users", (double) activeUsers, "count", 
                    SystemMetrics.MetricType.USAGE, "Concurrent Users");
    }

    @Override
    @Transactional
    public void recordDatabaseConnections(int activeConnections) {
        recordMetric("db_connections", (double) activeConnections, "count", 
                    SystemMetrics.MetricType.SYSTEM, "Database Connections");
    }

    @Override
    @Transactional
    public void recordAppraisalProcessingTime(String appraisalId, long processingTimeHours) {
        recordMetric("appraisal_processing_time", (double) processingTimeHours, "hours", 
                    SystemMetrics.MetricType.BUSINESS, "Appraisal Processing Time");
    }

    @Override
    @Transactional
    public void recordReviewTurnaroundTime(String reviewLevel, long turnaroundTimeHours) {
        recordMetric("review_turnaround_" + reviewLevel, (double) turnaroundTimeHours, "hours", 
                    SystemMetrics.MetricType.BUSINESS, "Review Turnaround Time");
    }

    @Override
    @Transactional
    public void recordDeadlineCompliance(String academicYear, boolean metDeadline) {
        recordMetric("deadline_compliance_" + academicYear, metDeadline ? 1.0 : 0.0, "boolean", 
                    SystemMetrics.MetricType.BUSINESS, "Deadline Compliance");
    }

    @Override
    @Transactional
    public void recordFailedLoginAttempt(String ipAddress, String userAgent) {
        recordMetric("failed_login_attempts", 1.0, "count", 
                    SystemMetrics.MetricType.SECURITY, "Failed Login Attempts", 
                    "IP: " + ipAddress + ", Agent: " + userAgent);
    }

    @Override
    @Transactional
    public void recordSecurityEvent(String eventType, String severity) {
        recordMetric("security_event_" + eventType + "_" + severity, 1.0, "count", 
                    SystemMetrics.MetricType.SECURITY, "Security Events");
    }

    @Override
    @Transactional
    public void recordUnauthorizedAccess(String resource, String userRole) {
        recordMetric("unauthorized_access_" + resource, 1.0, "count", 
                    SystemMetrics.MetricType.SECURITY, "Unauthorized Access Attempts");
    }

    @Override
    @Transactional
    public void recordException(String exceptionType, String component) {
        recordMetric("exception_" + exceptionType + "_" + component, 1.0, "count", 
                    SystemMetrics.MetricType.ERROR, "Exception Count");
    }

    @Override
    @Transactional
    public void recordApiError(String endpoint, int statusCode) {
        recordMetric("api_error_" + sanitizeEndpoint(endpoint) + "_" + statusCode, 1.0, "count", 
                    SystemMetrics.MetricType.ERROR, "API Error Count");
    }

    @Override
    @Transactional
    public void recordValidationError(String fieldName, String validationType) {
        recordMetric("validation_error_" + fieldName + "_" + validationType, 1.0, "count", 
                    SystemMetrics.MetricType.ERROR, "Validation Error Count");
    }

    // Analytics Methods (Simplified implementations for demonstration)
    @Override
    public Map<String, Object> getPerformanceMetrics(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("averageResponseTime", 250.5);
        metrics.put("averageDbQueryTime", 45.2);
        metrics.put("peakResponseTime", 1250.0);
        metrics.put("period", "from " + startDate + " to " + endDate);
        return metrics;
    }

    @Override
    public Map<String, Object> getUsageStatistics(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalLogins", 1250);
        stats.put("uniqueUsers", 89);
        stats.put("peakConcurrentUsers", 45);
        stats.put("period", "from " + startDate + " to " + endDate);
        return stats;
    }

    @Override
    public Map<String, Object> getSystemHealthMetrics() {
        Map<String, Object> health = new HashMap<>();
        health.put("cpuUsage", 65.5);
        health.put("memoryUsage", 78.2);
        health.put("diskUsage", 45.8);
        health.put("dbConnections", 12);
        health.put("status", "HEALTHY");
        health.put("timestamp", LocalDateTime.now());
        return health;
    }

    @Override
    public Map<String, Object> getBusinessAnalytics(String academicYear) {
        Map<String, Object> analytics = new HashMap<>();
        analytics.put("totalAppraisals", 234);
        analytics.put("completedAppraisals", 189);
        analytics.put("averageProcessingTime", 18.5);
        analytics.put("deadlineCompliance", 0.92);
        analytics.put("academicYear", academicYear);
        return analytics;
    }

    @Override
    public Map<String, Object> getSecurityMetrics(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> security = new HashMap<>();
        security.put("failedLoginAttempts", 23);
        security.put("securityEvents", 5);
        security.put("unauthorizedAccess", 8);
        security.put("period", "from " + startDate + " to " + endDate);
        return security;
    }

    @Override
    public Map<String, Object> getErrorAnalytics(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> errors = new HashMap<>();
        errors.put("totalExceptions", 12);
        errors.put("apiErrors", 8);
        errors.put("validationErrors", 25);
        errors.put("errorRate", 0.02);
        errors.put("period", "from " + startDate + " to " + endDate);
        return errors;
    }

    // Additional methods with placeholder implementations
    @Override
    public Map<String, Object> getTrendingMetrics(String metricCategory, LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> trends = new HashMap<>();
        trends.put("trend", "increasing");
        trends.put("category", metricCategory);
        trends.put("confidence", 0.85);
        return trends;
    }

    @Override
    public Map<String, Object> getPredictiveAnalytics(String metricName, int forecastDays) {
        Map<String, Object> prediction = new HashMap<>();
        prediction.put("metricName", metricName);
        prediction.put("forecastDays", forecastDays);
        prediction.put("predictedValue", 125.5);
        prediction.put("confidence", 0.78);
        return prediction;
    }

    @Override
    public Map<String, Object> getCurrentSystemStatus() {
        return getSystemHealthMetrics();
    }

    @Override
    public Map<String, Object> getActiveUserMetrics() {
        Map<String, Object> activeUsers = new HashMap<>();
        activeUsers.put("currentActiveUsers", 23);
        activeUsers.put("peakToday", 56);
        activeUsers.put("averageSessionTime", 45.2);
        return activeUsers;
    }

    @Override
    public Map<String, Object> getRealTimePerformanceMetrics() {
        return getPerformanceMetrics(LocalDateTime.now().minusHours(1), LocalDateTime.now());
    }

    @Override
    public Page<SystemMetrics> getMetricsByType(SystemMetrics.MetricType type, Pageable pageable) {
        return systemMetricsRepository.findByType(type, pageable);
    }

    @Override
    public Page<SystemMetrics> getMetricsByCategory(String category, Pageable pageable) {
        return systemMetricsRepository.findByCategory(category, pageable);
    }

    @Override
    public Page<SystemMetrics> getMetricsByDateRange(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable) {
        return systemMetricsRepository.findByRecordedAtBetween(startDate, endDate, pageable);
    }

    @Override
    @Transactional
    public void cleanupOldMetrics(int retentionDays) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(retentionDays);
        int deletedCount = systemMetricsRepository.deleteOldMetrics(cutoffDate);
        log.info("Cleaned up {} old metrics older than {} days", deletedCount, retentionDays);
    }

    @Override
    public Map<String, Object> getExecutiveDashboardMetrics() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("systemHealth", getSystemHealthMetrics());
        dashboard.put("businessMetrics", getBusinessAnalytics("2023-24"));
        dashboard.put("securityStatus", getSecurityMetrics(LocalDateTime.now().minusDays(7), LocalDateTime.now()));
        return dashboard;
    }

    @Override
    public Map<String, Object> getOperationalDashboardMetrics() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("performanceMetrics", getRealTimePerformanceMetrics());
        dashboard.put("activeUsers", getActiveUserMetrics());
        dashboard.put("systemStatus", getCurrentSystemStatus());
        return dashboard;
    }

    @Override
    public Map<String, Object> getTechnicalDashboardMetrics() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("systemHealth", getSystemHealthMetrics());
        dashboard.put("errorMetrics", getErrorAnalytics(LocalDateTime.now().minusDays(1), LocalDateTime.now()));
        dashboard.put("performanceData", getPerformanceMetrics(LocalDateTime.now().minusDays(1), LocalDateTime.now()));
        return dashboard;
    }

    // Helper methods
    private void recordMetric(String metricName, Double value, String unit, 
                             SystemMetrics.MetricType type, String description) {
        recordMetric(metricName, value, unit, type, description, null);
    }

    private void recordMetric(String metricName, Double value, String unit, 
                             SystemMetrics.MetricType type, String description, String additionalData) {
        SystemMetrics metric = SystemMetrics.builder()
                .metricName(metricName)
                .metricValue(value)
                .metricUnit(unit)
                .type(type)
                .category(type.name())
                .description(description)
                .additionalData(additionalData)
                .build();

        systemMetricsRepository.save(metric);
    }

    private String sanitizeEndpoint(String endpoint) {
        return endpoint.replaceAll("[^a-zA-Z0-9_]", "_");
    }
} 