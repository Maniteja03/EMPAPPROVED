package com.cvrce.apraisal.dto.committee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeDashboardDTO {
    private String committeeMemberName;
    private String departmentName;
    private String academicYear;
    private int totalFormsAssigned;
    private int formsCompleted;
    private int formsPending;
    private int formsAvailableForReview;
    private int ownDepartmentFormsCount;
    private double completionRate;
    private String currentWorkloadStatus;
    private int activeLocks;
    private String nextDeadline;
    private long daysUntilDeadline;
} 