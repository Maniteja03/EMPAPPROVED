package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.partc.EBoxTrainingDTO;
import com.cvrce.apraisal.service.PartC_EBoxTrainingService;
import com.cvrce.apraisal.service.AppraisalFormService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/partc/ebox-training")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
public class PartC_EBoxTrainingController {

    private final PartC_EBoxTrainingService eboxService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping
    public ResponseEntity<EBoxTrainingDTO> add(@RequestBody EBoxTrainingDTO dto) {
        // SECURITY FIX: Validate ownership before allowing data modification
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized E-Box training creation attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Adding E-Box Training for form {} by authorized user {}", dto.getAppraisalFormId(), currentUserEmail);
        return new ResponseEntity<>(eboxService.addEBoxTraining(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<EBoxTrainingDTO>> getByForm(@PathVariable UUID formId) {
        // SECURITY FIX: Validate access before allowing data retrieval
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized E-Box training access attempt on form {} by user {}", 
                    formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Fetching E-Box training records for form {} by authorized user {}", formId, currentUserEmail);
        return ResponseEntity.ok(eboxService.getEBoxTrainingsByFormId(formId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EBoxTrainingDTO> update(@PathVariable UUID id, @RequestBody EBoxTrainingDTO dto) {
        // SECURITY FIX: Validate ownership before allowing updates
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized E-Box training update attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Updating E-Box training record with ID {} by authorized user {}", id, currentUserEmail);
        return ResponseEntity.ok(eboxService.updateEBoxTraining(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        // SECURITY FIX: Validate ownership before allowing deletion
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            eboxService.deleteEBoxTraining(id, currentUserEmail);
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            log.warn("Unauthorized E-Box training deletion attempt for ID {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}
