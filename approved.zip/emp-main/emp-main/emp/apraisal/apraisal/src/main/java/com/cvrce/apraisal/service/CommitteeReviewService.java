package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.dto.committee.CommitteeDashboardDTO;
import com.cvrce.apraisal.dto.committee.CommitteeWorkloadDTO;
import com.cvrce.apraisal.entity.FormLock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Service for committee members to review appraisal forms
 */
public interface CommitteeReviewService {
    
    /**
     * Get committee member dashboard with statistics and tasks
     * @param committeeEmail The committee member's email
     * @param academicYear The academic year
     * @return Dashboard data
     */
    CommitteeDashboardDTO getCommitteeDashboard(String committeeEmail, String academicYear);
    
    /**
     * Get forms available for committee review (excludes own department)
     * @param committeeEmail The committee member's email
     * @param academicYear The academic year
     * @param pageable Pagination information
     * @return Page of forms available for review
     */
    Page<AppraisalFormDTO> getAvailableFormsForReview(String committeeEmail, String academicYear, Pageable pageable);
    
    /**
     * Get forms from own department (VIEW ONLY - no review actions allowed)
     * @param committeeEmail The committee member's email
     * @param academicYear The academic year
     * @param pageable Pagination information
     * @return Page of own department forms
     */
    Page<AppraisalFormDTO> getOwnDepartmentForms(String committeeEmail, String academicYear, Pageable pageable);
    
    /**
     * Start reviewing a form (attempt to lock it)
     * @param formId The form ID to review
     * @param committeeEmail The committee member's email
     * @return FormLock if successful, empty if form is already locked
     */
    Optional<FormLock> startFormReview(UUID formId, String committeeEmail);
    
    /**
     * Get form details for committee review (with lock check)
     * @param formId The form ID
     * @param committeeEmail The committee member's email
     * @return Form details if accessible
     */
    AppraisalFormDTO getFormForReview(UUID formId, String committeeEmail);
    
    /**
     * Submit committee review (approve or reject)
     * @param reviewDTO The review details
     * @param committeeEmail The committee member's email
     * @return Submitted review
     */
    ReviewDTO submitCommitteeReview(ReviewDTO reviewDTO, String committeeEmail);
    
    /**
     * Cancel form review and release lock
     * @param formId The form ID
     * @param committeeEmail The committee member's email
     * @return true if lock was released
     */
    boolean cancelFormReview(UUID formId, String committeeEmail);
    
    /**
     * Get forms currently locked by this committee member
     * @param committeeEmail The committee member's email
     * @return List of forms currently being reviewed by this member
     */
    List<AppraisalFormDTO> getMyActiveReviews(String committeeEmail);
    
    /**
     * Get committee review history for this member
     * @param committeeEmail The committee member's email
     * @param academicYear The academic year
     * @param pageable Pagination information
     * @return Page of completed reviews
     */
    Page<ReviewDTO> getMyReviewHistory(String committeeEmail, String academicYear, Pageable pageable);
    
    /**
     * Extend form review lock (when actively working)
     * @param formId The form ID
     * @param committeeEmail The committee member's email
     * @param additionalMinutes Minutes to extend
     * @return true if extended successfully
     */
    boolean extendReviewLock(UUID formId, String committeeEmail, int additionalMinutes);
    
    /**
     * Get committee member's workload statistics
     * @param committeeEmail The committee member's email
     * @param academicYear The academic year
     * @return Workload statistics
     */
    CommitteeWorkloadDTO getMyWorkloadStats(String committeeEmail, String academicYear);
    
    /**
     * Check if committee member can review forms from a specific department
     * @param committeeEmail The committee member's email
     * @param departmentName The department name to check
     * @return true if can review (i.e., not their own department)
     */
    boolean canReviewDepartmentForms(String committeeEmail, String departmentName);
} 