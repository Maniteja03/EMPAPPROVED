package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.enums.AppraisalStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.List;
import java.util.UUID;
import com.cvrce.apraisal.entity.User;

public interface AppraisalFormRepository extends JpaRepository<AppraisalForm, UUID> {
    List<AppraisalForm> findByUserId(UUID userId);
    Optional<AppraisalForm> findByUserIdAndAcademicYear(UUID userId, String academicYear);

    List<AppraisalForm> findByStatus(AppraisalStatus status);
    List<AppraisalForm> findByAcademicYear(String academicYear);
    long countByStatus(AppraisalStatus status);
    long countByAcademicYear(String academicYear);

    @Query("SELECT f FROM AppraisalForm f WHERE f.status = :status AND f.user.department.name = :departmentName")
    List<AppraisalForm> findByStatusAndUserDepartmentName(@Param("status") AppraisalStatus status, @Param("departmentName") String departmentName);

    @Query("SELECT f FROM AppraisalForm f WHERE f.status = :status AND f.user.department.name != :excludeDepartmentName")
    List<AppraisalForm> findByStatusAndUserDepartmentNameNot(@Param("status") AppraisalStatus status, @Param("excludeDepartmentName") String excludeDepartmentName);

    @Query("SELECT f FROM AppraisalForm f WHERE f.user.department.name = :departmentName AND f.academicYear = :academicYear")
    List<AppraisalForm> findByUserDepartmentNameAndAcademicYear(@Param("departmentName") String departmentName, @Param("academicYear") String academicYear);

    @Query("SELECT COUNT(f) FROM AppraisalForm f WHERE f.status = :status AND f.user.department.name = :departmentName")
    long countByStatusAndDepartment(@Param("status") AppraisalStatus status, @Param("departmentName") String departmentName);

    @Query("SELECT f FROM AppraisalForm f WHERE f.status IN :statuses AND f.user.department.name = :departmentName AND f.academicYear = :academicYear")
    List<AppraisalForm> findByStatusInAndDepartmentAndYear(@Param("statuses") List<AppraisalStatus> statuses, @Param("departmentName") String departmentName, @Param("academicYear") String academicYear);

    // Efficient paginated queries to replace findAll() calls
    @Query("SELECT f FROM AppraisalForm f WHERE " +
           "(:academicYear IS NULL OR f.academicYear = :academicYear) AND " +
           "(:status IS NULL OR f.status = :status)")
    Page<AppraisalForm> findAllWithFilters(@Param("academicYear") String academicYear, 
                                          @Param("status") AppraisalStatus status, 
                                          Pageable pageable);

    // Search query for appraisals
    @Query("SELECT f FROM AppraisalForm f WHERE " +
           "LOWER(f.user.fullName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(f.academicYear) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(f.user.employeeId) LIKE LOWER(CONCAT('%', :query, '%'))")
    Page<AppraisalForm> searchAppraisals(@Param("query") String query, Pageable pageable);

    // Paginated methods for backward compatibility
    @Query("SELECT f FROM AppraisalForm f WHERE f.userId = :userId")
    Page<AppraisalForm> findByUserId(@Param("userId") UUID userId, Pageable pageable);

    @Query("SELECT f FROM AppraisalForm f WHERE f.status = :status")
    Page<AppraisalForm> findByStatus(@Param("status") AppraisalStatus status, Pageable pageable);
    
    // Efficient queries for scheduler
    @Query("SELECT f FROM AppraisalForm f WHERE f.academicYear = :academicYear AND f.status IN :statuses")
    List<AppraisalForm> findByAcademicYearAndStatusIn(@Param("academicYear") String academicYear, 
                                                     @Param("statuses") List<AppraisalStatus> statuses);

    // Check if user has submitted appraisal for academic year
    @Query("SELECT COUNT(f) > 0 FROM AppraisalForm f WHERE f.user = :user AND f.academicYear = :academicYear")
    boolean existsByUserAndAcademicYear(@Param("user") User user, @Param("academicYear") String academicYear);
}
