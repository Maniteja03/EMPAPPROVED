package com.cvrce.apraisal.dto.timeline;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class TimelineValidationResult {
    private boolean isValid;
    private List<String> errorMessages;
    private List<String> warningMessages;
    private List<String> suggestionMessages;
    
    public TimelineValidationResult(boolean isValid) {
        this.isValid = isValid;  
        this.errorMessages = new ArrayList<>();
        this.warningMessages = new ArrayList<>();
        this.suggestionMessages = new ArrayList<>();
    }
    
    public void addError(String error) { this.errorMessages.add(error); }
    public void addWarning(String warning) { this.warningMessages.add(warning); }
    public void addSuggestion(String suggestion) { this.suggestionMessages.add(suggestion); }
} 