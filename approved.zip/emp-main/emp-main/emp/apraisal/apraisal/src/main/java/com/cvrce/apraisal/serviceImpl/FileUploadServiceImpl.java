package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.document.UploadedDocument;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.UploadedDocumentRepository;
import com.cvrce.apraisal.service.FileUploadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileUploadServiceImpl implements FileUploadService {

    @Value("${file.upload.directory:C:/temp/uploads}")
    private String baseUploadDir;
    
    // Security: Define allowed file types
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
        ".pdf", ".jpg", ".jpeg", ".png", ".doc", ".docx", ".xls", ".xlsx"
    );
    
    // Security: Define allowed MIME types
    private static final Set<String> ALLOWED_MIME_TYPES = Set.of(
        "application/pdf",
        "image/jpeg", "image/jpg", "image/png",
        "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    private static final Pattern SAFE_FILENAME_PATTERN = Pattern.compile("^[a-zA-Z0-9._-]+$");

    private final UploadedDocumentRepository documentRepo;
    private final AppraisalFormRepository appraisalFormRepo;

    @Override
    public String uploadProofFile(String section, UUID formId, MultipartFile file) throws IOException {
        
        // Security validations
        validateFile(file);
        
        String safeSection = sanitizeSection(section);
        String uploadDir = createSecureUploadPath(formId, safeSection);
        
        // Create directory if it doesn't exist
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new IOException("Failed to create upload directory: " + uploadDir);
            }
        }

        String secureFileName = generateSecureFileName(file.getOriginalFilename());
        Path filePath = Paths.get(uploadDir, secureFileName);
        
        // Prevent path traversal attacks
        if (!filePath.normalize().startsWith(Paths.get(uploadDir).normalize())) {
            throw new SecurityException("Invalid file path detected");
        }
        
        try {
            Files.write(filePath, file.getBytes(), StandardOpenOption.CREATE_NEW);
        } catch (FileAlreadyExistsException e) {
            throw new IOException("File with this name already exists");
        }

        String relativePath = filePath.toString().replace(baseUploadDir, "");

        // Save file metadata in DB
        AppraisalForm form = appraisalFormRepo.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("AppraisalForm not found with ID: " + formId));

        UploadedDocument document = UploadedDocument.builder()
                .fileName(file.getOriginalFilename())
                .filePath(relativePath)
                .fileSize(file.getSize())
                .contentType(file.getContentType())
                .section(section)
                .appraisalForm(form)
                .uploadedAt(LocalDateTime.now())
                .build();

        documentRepo.save(document);

        log.info("File uploaded successfully: {} for form: {}", secureFileName, formId);
        return relativePath;
    }
    
    private void validateFile(MultipartFile file) {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be empty");
        }
        
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("File size exceeds maximum allowed size of 10MB");
        }
        
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            throw new IllegalArgumentException("File name cannot be empty");
        }
        
        // Validate file extension
        String extension = getFileExtension(originalFilename).toLowerCase();
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new IllegalArgumentException("File type not allowed. Allowed types: " + ALLOWED_EXTENSIONS);
        }
        
        // Validate MIME type
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_MIME_TYPES.contains(contentType)) {
            throw new IllegalArgumentException("Invalid file format. Please upload a valid document or image file.");
        }
        
        // Check for malicious file names
        if (originalFilename.contains("..") || originalFilename.contains("/") || originalFilename.contains("\\")) {
            throw new IllegalArgumentException("Invalid file name detected");
        }
    }
    
    private String sanitizeSection(String section) {
        if (section == null || section.trim().isEmpty()) {
            throw new IllegalArgumentException("Section cannot be empty");
        }
        return section.toUpperCase().replaceAll("[^A-Z0-9_]", "_");
    }
    
    private String createSecureUploadPath(UUID formId, String safeSection) {
        return baseUploadDir + File.separator + formId + File.separator + safeSection;
    }
    
    private String generateSecureFileName(String originalFilename) {
        String extension = getFileExtension(originalFilename);
        String baseName = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        
        // Sanitize base name
        baseName = baseName.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (baseName.length() > 50) {
            baseName = baseName.substring(0, 50);
        }
        
        return System.currentTimeMillis() + "_" + baseName + extension;
    }
    
    private String getFileExtension(String filename) {
        int lastDotIndex = filename.lastIndexOf('.');
        return lastDotIndex > 0 ? filename.substring(lastDotIndex) : "";
    }
}
