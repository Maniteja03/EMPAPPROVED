package com.cvrce.apraisal.dto;

import lombok.Data;

@Data
public class FormAssignmentStats {
    private String academicYear;
    private int totalFormsAwaitingAssignment;
    private int totalFormsAssigned;
    private int totalAvailableCommitteeMembers;
    private double averageWorkloadPerMember;
    private String mostBusyCommitteeMember;
    private String leastBusyCommitteeMember;
} 