package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "form_assignments")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormAssignment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_form_id", nullable = false)
    private AppraisalForm appraisalForm;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_reviewer_id", nullable = false)
    private User assignedReviewer;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "committee_assignment_id", nullable = true)
    private CommitteeAssignment committeeAssignment;
    
    @Column(name = "assigned_at", nullable = false)
    @CreationTimestamp
    private LocalDateTime assignedAt;
    
    @Column(name = "completed_at")
    private LocalDateTime completedAt;
    
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private boolean isActive = true;
    
    @Column(name = "assignment_type", nullable = false)
    private String assignmentType; // "DCM_REVIEW", "COMMITTEE_REVIEW", etc.
    
    @Column(name = "notes")
    private String notes;
} 