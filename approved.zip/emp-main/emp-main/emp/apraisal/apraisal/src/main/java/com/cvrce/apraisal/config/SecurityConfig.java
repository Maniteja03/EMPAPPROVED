package com.cvrce.apraisal.config;

import com.cvrce.apraisal.security.JwtAuthEntryPoint;
import com.cvrce.apraisal.security.JwtAuthFilter;
import com.cvrce.apraisal.serviceImpl.CustomUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.*;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.*;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;
import java.util.Arrays;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

	private final JwtAuthFilter jwtAuthFilter;
	private final JwtAuthEntryPoint authEntryPoint;
	private final CustomUserDetailsService userDetailsService;

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable())
			.cors(cors -> cors.configurationSource(corsConfigurationSource()))
			.exceptionHandling(ex -> ex.authenticationEntryPoint(authEntryPoint))
			.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
			.authorizeHttpRequests(auth -> auth
				// Public endpoints
				.requestMatchers(
					"/api/auth/**",
					"/api/init/**",  // Allow initialization endpoints
					"/v3/api-docs/**", 
					"/swagger-ui/**", 
					"/swagger-ui.html",
					"/actuator/health"
				).permitAll()
				
				// Admin only endpoints
				.requestMatchers("/api/auth/register").hasRole("ADMIN")
				
				// Role-based access
				.requestMatchers("/api/dashboard/hod/**").hasAnyRole("HOD", "ADMIN")
				.requestMatchers("/api/dashboard/committee/**").hasAnyRole("COMMITTEE", "CHAIRPERSON", "ADMIN")
				.requestMatchers("/api/dashboard/principal/**").hasAnyRole("PRINCIPAL", "ADMIN")
				
				// Staff can access their own data
				.requestMatchers("/api/appraisal/**").hasAnyRole("STAFF", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL", "ADMIN")
				.requestMatchers("/api/review/**").hasAnyRole("DCM", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL", "ADMIN")
				
				// All authenticated users
				.anyRequest().authenticated());

		http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
		return http.build();
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOriginPatterns(Arrays.asList("http://localhost:3000", "http://localhost:5173", "https://your-frontend-domain.com"));
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		configuration.setAllowedHeaders(Arrays.asList("*"));
		configuration.setAllowCredentials(true);
		
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/api/**", configuration);
		return source;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
