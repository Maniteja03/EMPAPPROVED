package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.committee.CommitteeAssignmentDTO;
import com.cvrce.apraisal.dto.FormAssignmentStats;
import com.cvrce.apraisal.entity.AppraisalForm;

import java.util.UUID;

public interface FormAssignmentService {
    
    /**
     * Auto-assign form to available committee member (excludes form's department)
     * Called when form reaches COMMITTEE_REVIEW status
     * @param form The appraisal form to assign
     * @return Assigned committee member, null if no one available
     */
    CommitteeAssignmentDTO autoAssignToCommitteeMember(AppraisalForm form);
    
    /**
     * Assign form to specific committee member
     * @param formId The form ID
     * @param committeeAssignmentId The committee member assignment ID
     * @return true if successfully assigned
     */
    boolean assignToSpecificCommitteeMember(UUID formId, UUID committeeAssignmentId);
    
    /**
     * Reassign rejected form to the same committee member who originally reviewed it
     * Called when form reaches HOD_UPDATED status
     * @param form The appraisal form to reassign
     * @return Original committee member, null if not found
     */
    CommitteeAssignmentDTO reassignToSameCommitteeMember(AppraisalForm form);
    
    /**
     * Release form assignment when review is completed or cancelled
     * @param formId The form ID
     * @param committeeAssignmentId The committee member assignment ID
     */
    void releaseFormAssignment(UUID formId, UUID committeeAssignmentId);
    
    /**
     * Get committee member assigned to a form
     * @param formId The form ID
     * @return Committee member if assigned, null otherwise
     */
    CommitteeAssignmentDTO getAssignedCommitteeMember(UUID formId);
    
    /**
     * Handle form status change and auto-assignment
     * Called by workflow service when status changes
     * @param formId The form ID
     * @param newStatus The new status
     */
    void handleFormStatusChange(UUID formId, String newStatus);
    
    /**
     * Get assignment statistics
     * @param academicYear The academic year
     * @return Assignment statistics
     */
    FormAssignmentStats getAssignmentStats(String academicYear);
} 