package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.DeadlineConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DeadlineConfigRepository extends JpaRepository<DeadlineConfig, UUID> {
    
    // Efficient query for deadline reminders
    @Query("SELECT d FROM DeadlineConfig d WHERE d.deadlineDate BETWEEN :startDate AND :endDate")
    List<DeadlineConfig> findByDeadlineDateBetween(@Param("startDate") LocalDate startDate, 
                                                   @Param("endDate") LocalDate endDate);
    
    // Find active deadlines
    @Query("SELECT d FROM DeadlineConfig d WHERE d.deadlineDate >= CURRENT_DATE")
    List<DeadlineConfig> findActiveDeadlines();
    
    // Find by academic year - returns list for bulk operations
    List<DeadlineConfig> findByAcademicYear(String academicYear);
    
    // Find single deadline by academic year - returns Optional for service operations
    Optional<DeadlineConfig> findFirstByAcademicYear(String academicYear);
}
