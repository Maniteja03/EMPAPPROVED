package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Map;
import java.util.UUID;

public interface ChairpersonService {
    
    Map<String, Object> getChairpersonDashboard();
    
    Page<AppraisalFormDTO> getPendingEvaluations(Pageable pageable, String department, String priority);
    
    ReviewDTO submitChairpersonEvaluation(ReviewDTO evaluationDTO, String currentUserEmail);
    
    Map<String, Object> getComprehensiveEvaluationSummary(UUID formId);
    
    void overridePreviousDecision(UUID formId, String newDecision, String justification);
    
    void requestExpertReview(UUID formId, String expertArea, String specificExpertId, String reason);
    
    Map<String, Object> getInstitutionalPerformanceOverview(String academicYear, String groupBy);
    
    Map<String, Object> generatePolicyRecommendations(String academicYear);
    
    void scheduleReviewMeeting(Map<String, Object> meetingDetails);
    
    byte[] generateAnnualAppraisalReport(String academicYear, String format);
    
    void updateEvaluationCriteria(Map<String, Object> criteriaConfig);
    
    Map<String, Object> analyzeReviewerPerformance(String academicYear, String reviewerRole);
} 