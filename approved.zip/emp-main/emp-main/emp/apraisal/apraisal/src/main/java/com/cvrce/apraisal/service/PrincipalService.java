package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface PrincipalService {
    
    List<AppraisalFormDTO> getPendingFinalApprovals();
    
    AppraisalFormDTO getAppraisalForFinalReview(UUID formId);
    
    void provideFinalDecision(UUID formId, String decision, String comments);
    
    Map<String, Object> getPrincipalDashboard();
    
    void bulkApprove(List<UUID> formIds);
    
    Map<String, Object> getAppraisalStatistics(String academicYear);
} 