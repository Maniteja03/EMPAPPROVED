package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.service.CollegeCommitteeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.security.core.context.SecurityContextHolder;

@RestController
@RequestMapping("/api/committee")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('COMMITTEE')")
public class CollegeCommitteeController {

    private final CollegeCommitteeService committeeService;

    // Get College Committee dashboard
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getCommitteeDashboard() {
        log.info("Fetching College Committee dashboard data");
        return ResponseEntity.ok(committeeService.getCommitteeDashboard());
    }

    // Get appraisals pending committee review
    @GetMapping("/pending-reviews")
    public ResponseEntity<Page<AppraisalFormDTO>> getPendingReviews(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String department) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> pendingReviews = committeeService.getPendingReviews(pageable, department);
        return ResponseEntity.ok(pendingReviews);
    }

    // Submit committee review decision
    @PostMapping("/review")
    public ResponseEntity<ReviewDTO> submitCommitteeReview(@Valid @RequestBody ReviewDTO reviewDTO) {
        // SECURITY FIX: Get current authenticated user email
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee submitting review for appraisal: {} by authenticated user: {}", 
                reviewDTO.getAppraisalFormId(), currentUserEmail);
        
        ReviewDTO submittedReview = committeeService.submitCommitteeReview(reviewDTO, currentUserEmail);
        return ResponseEntity.ok(submittedReview);
    }

    // Get comprehensive appraisal view for committee review
    @GetMapping("/appraisal-details/{formId}")
    public ResponseEntity<Map<String, Object>> getAppraisalDetails(@PathVariable UUID formId) {
        log.info("Committee accessing detailed view of appraisal: {}", formId);
        Map<String, Object> appraisalDetails = committeeService.getComprehensiveAppraisalView(formId);
        return ResponseEntity.ok(appraisalDetails);
    }

    // Get all previous reviews for an appraisal
    @GetMapping("/review-trail/{formId}")
    public ResponseEntity<List<ReviewDTO>> getReviewTrail(@PathVariable UUID formId) {
        log.info("Fetching review trail for appraisal: {}", formId);
        List<ReviewDTO> reviewTrail = committeeService.getAppraisalReviewTrail(formId);
        return ResponseEntity.ok(reviewTrail);
    }

    // Generate committee meeting agenda
    @PostMapping("/generate-agenda")
    public ResponseEntity<Map<String, Object>> generateMeetingAgenda(
            @RequestParam String meetingDate,
            @RequestParam(required = false) String department) {
        log.info("Generating committee meeting agenda for date: {}", meetingDate);
        Map<String, Object> agenda = committeeService.generateMeetingAgenda(meetingDate, department);
        return ResponseEntity.ok(agenda);
    }

    // Bulk review processing
    @PostMapping("/bulk-review")
    public ResponseEntity<String> processBulkReviews(@RequestBody Map<UUID, String> formDecisions) {
        log.info("Processing bulk reviews for {} appraisals", formDecisions.size());
        committeeService.processBulkReviews(formDecisions);
        return ResponseEntity.ok("Bulk reviews processed successfully");
    }

    // Get cross-departmental statistics
    @GetMapping("/cross-department-stats")
    public ResponseEntity<Map<String, Object>> getCrossDepartmentStatistics(
            @RequestParam(required = false) String academicYear) {
        Map<String, Object> stats = committeeService.getCrossDepartmentStatistics(academicYear);
        return ResponseEntity.ok(stats);
    }

    // Export committee review summary
    @GetMapping("/export-summary")
    public ResponseEntity<byte[]> exportCommitteeReviewSummary(
            @RequestParam String academicYear,
            @RequestParam(defaultValue = "PDF") String format) {
        log.info("Exporting committee review summary for year: {} in format: {}", academicYear, format);
        byte[] exportData = committeeService.exportReviewSummary(academicYear, format);
        
        String contentType = format.equalsIgnoreCase("PDF") ? "application/pdf" : "application/vnd.ms-excel";
        String filename = "committee_review_summary_" + academicYear + "." + format.toLowerCase();
        
        return ResponseEntity.ok()
                .header("Content-Type", contentType)
                .header("Content-Disposition", "attachment; filename=" + filename)
                .body(exportData);
    }

    // Flag appraisal for special attention
    @PostMapping("/flag-appraisal/{formId}")
    public ResponseEntity<String> flagAppraisalForAttention(
            @PathVariable UUID formId,
            @RequestParam String flagReason,
            @RequestParam(defaultValue = "HIGH") String priority) {
        log.info("Flagging appraisal {} for special attention: {}", formId, flagReason);
        committeeService.flagAppraisalForSpecialAttention(formId, flagReason, priority);
        return ResponseEntity.ok("Appraisal flagged successfully");
    }
} 