package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.UploadedDocumentDTO;
import com.cvrce.apraisal.service.AppraisalFormService;
import com.cvrce.apraisal.service.FileUploadService;
import com.cvrce.apraisal.service.UploadedDocumentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;
import java.util.Map;

@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
@Slf4j
public class FileUploadController {

    private final FileUploadService fileUploadService;
    private final UploadedDocumentService documentService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping("/upload-proof")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    // Rate limiting: Max 50 file uploads per hour per user to prevent spam
    public ResponseEntity<Map<String, Object>> uploadProofFile(
            @RequestParam("formId") UUID formId,
            @RequestParam("section") String section,
            @RequestParam("file") MultipartFile file
    ) {
        try {
            // Critical security fix: Check ownership before allowing file upload
            String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
            
            if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
                log.warn("Unauthorized file upload attempt to form {} by user {}", formId, currentUserEmail);
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(Map.of("error", "You can only upload files to your own appraisal forms"));
            }
            
            log.info("Uploading file for form {} in section {} by user {}", formId, section, currentUserEmail);
            String filePath = fileUploadService.uploadProofFile(section, formId, file);
            return ResponseEntity.ok(Map.of("message", "File uploaded and linked at: " + filePath, "filePath", filePath));
        } catch (Exception e) {
            log.error("File upload failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "File upload failed: " + e.getMessage()));
        }
    }
    

    @GetMapping("/metadata")
    @PreAuthorize("hasRole('STAFF') or hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<List<UploadedDocumentDTO>> getFileMetadataByFormId(@RequestParam UUID formId) {
        // Security check: Ensure user can access the form before showing file metadata
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized file metadata access attempt for form {} by user {}", formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        List<UploadedDocumentDTO> documents = documentService.getDocuments(formId, null);
        return ResponseEntity.ok(documents);
    }
}
