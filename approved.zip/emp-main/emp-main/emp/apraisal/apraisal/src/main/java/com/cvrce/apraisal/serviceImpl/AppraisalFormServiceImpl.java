package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.AppraisalVersion;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.AppraisalVersionRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.AppraisalFormService;
import com.cvrce.apraisal.service.DeadlineService;
import com.cvrce.apraisal.service.FormAssignmentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.Set;
import com.cvrce.apraisal.entity.Role;

@Service
@RequiredArgsConstructor
@Slf4j
public class AppraisalFormServiceImpl implements AppraisalFormService {

    private final AppraisalFormRepository formRepository;
    private final AppraisalVersionRepository versionRepo;
    private final UserRepository userRepository;
    private final DeadlineService deadlineService;
    private final FormAssignmentService formAssignmentService;
    private final ObjectMapper objectMapper;

    @Override
    public AppraisalFormDTO createDraftForm(String academicYear, UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Optional<AppraisalForm> existing = formRepository.findByUserIdAndAcademicYear(userId, academicYear);
        if (existing.isPresent()) {
            throw new IllegalStateException("Form already exists for year");
        }

        AppraisalForm form = AppraisalForm.builder()
                .academicYear(academicYear)
                .status(AppraisalStatus.DRAFT)
                .user(user)
                .locked(false)
                .submittedAsRole(determinePrimaryRole(user.getRoles())) // FIXED: Proper multi-role handling
                .build();

        AppraisalForm saved = formRepository.save(form);
        return mapToDTO(saved);
    }

    @Override
    public List<AppraisalFormDTO> getMySubmissions(UUID userId) {
        return formRepository.findByUserId(userId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Page<AppraisalFormDTO> getMySubmissions(UUID userId, Pageable pageable) {
        List<AppraisalForm> allForms = formRepository.findByUserId(userId);
        List<AppraisalFormDTO> dtoList = allForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Manual pagination since repository doesn't have pageable method
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    public List<AppraisalFormDTO> filterByStatus(AppraisalStatus status) {
        return formRepository.findByStatus(status).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Page<AppraisalFormDTO> filterByStatus(AppraisalStatus status, Pageable pageable) {
        List<AppraisalForm> allForms = formRepository.findByStatus(status);
        List<AppraisalFormDTO> dtoList = allForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Apply sorting and pagination manually
        dtoList = applySorting(dtoList, pageable);
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    public Page<AppraisalFormDTO> getAllAppraisals(Pageable pageable, String academicYear, AppraisalStatus status) {
        // Use efficient database query instead of loading all forms
        Page<AppraisalForm> formPage = formRepository.findAllWithFilters(academicYear, status, pageable);
        
        List<AppraisalFormDTO> dtoList = formPage.getContent().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return new PageImpl<>(dtoList, pageable, formPage.getTotalElements());
    }

    @Override
    public Page<AppraisalFormDTO> searchAppraisals(String query, Pageable pageable) {
        // Use efficient database query instead of loading all forms
        Page<AppraisalForm> formPage = formRepository.searchAppraisals(query, pageable);
        
        List<AppraisalFormDTO> dtoList = formPage.getContent().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return new PageImpl<>(dtoList, pageable, formPage.getTotalElements());
    }

    private List<AppraisalFormDTO> applySorting(List<AppraisalFormDTO> list, Pageable pageable) {
        if (pageable.getSort().isSorted()) {
            pageable.getSort().forEach(order -> {
                String property = order.getProperty();
                boolean ascending = order.isAscending();
                
                list.sort((a, b) -> {
                    int comparison = 0;
                    switch (property) {
                        case "submittedDate":
                            comparison = compareLocalDates(a.getSubmittedDate(), b.getSubmittedDate());
                            break;
                        case "academicYear":
                            comparison = a.getAcademicYear().compareTo(b.getAcademicYear());
                            break;
                        case "status":
                            comparison = a.getStatus().compareTo(b.getStatus());
                            break;
                        case "totalScore":
                            comparison = Double.compare(a.getTotalScore(), b.getTotalScore());
                            break;
                        default:
                            comparison = 0;
                    }
                    return ascending ? comparison : -comparison;
                });
            });
        }
        return list;
    }

    private int compareLocalDates(LocalDate a, LocalDate b) {
        if (a == null && b == null) return 0;
        if (a == null) return -1;
        if (b == null) return 1;
        return a.compareTo(b);
    }

    @Override
    public AppraisalFormDTO submit(UUID formId) {
        AppraisalForm form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found"));

        if (form.isLocked()) {
            throw new IllegalStateException("Form is already locked");
        }

        // DEADLINE VALIDATION: Check if submission is still open for the academic year
        if (!deadlineService.isSubmissionOpen(form.getAcademicYear())) {
            throw new IllegalStateException(
                "Submission deadline has passed for academic year: " + form.getAcademicYear());
        }

        form.setStatus(AppraisalStatus.DEPARTMENT_REVIEW);
        form.setSubmittedDate(LocalDate.now());
        form.setLocked(true);

        AppraisalForm saved = formRepository.save(form);
        
        // CRITICAL FIX: Auto-assign form to DCM with load balancing
        try {
            formAssignmentService.handleFormStatusChange(saved.getId(), AppraisalStatus.DEPARTMENT_REVIEW.name());
            log.info("Auto-assigned form {} to DCM for department review", formId);
        } catch (Exception e) {
            log.error("Failed to auto-assign form {} to DCM: {}", formId, e.getMessage());
            // Don't fail the submission, but log the error
        }
        
        log.info("Appraisal form {} submitted for academic year {} - deadline validation passed", 
                formId, form.getAcademicYear());
        
        return mapToDTO(saved);
    }

    @Override
    public AppraisalFormDTO getById(UUID formId) {
        AppraisalForm form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found"));
        return mapToDTO(form);
    }

    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .locked(form.isLocked())
                .userId(form.getUser().getId())
                .userFullName(form.getUser().getFullName())
                .submittedAsRole(form.getSubmittedAsRole())
                .build();
    }
    
    @Override
    public boolean canUserAccessForm(UUID formId, String currentUserEmail) {
        try {
            // Get the appraisal form
            AppraisalForm form = formRepository.findById(formId)
                    .orElse(null);
            
            if (form == null) {
                return false;
            }
            
            // Get current user
            User currentUser = userRepository.findByEmail(currentUserEmail)
                    .orElse(null);
                    
            if (currentUser == null) {
                return false;
            }
            
            // Check if user owns the form
            if (form.getUser().getId().equals(currentUser.getId())) {
                return true;
            }
            
            // Check if user has reviewer/admin roles
            Set<String> userRoles = currentUser.getRoles().stream()
                    .map(role -> role.getName())
                    .collect(Collectors.toSet());
            
            boolean hasReviewerRole = userRoles.stream()
                    .anyMatch(role -> Set.of("DCM", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL", "ADMIN")
                            .contains(role));
            
            if (hasReviewerRole) {
                return true;
            }
            
            log.warn("Unauthorized access attempt to form {} by user {}", formId, currentUserEmail);
            return false;
            
        } catch (Exception e) {
            log.error("Error checking form access for form {} by user {}", formId, currentUserEmail, e);
            return false;
        }
    }

    /**
     * SECURITY FIX: Determines the primary role from multiple roles based on hierarchy
     * Higher priority roles take precedence for form submission
     */
    private String determinePrimaryRole(Set<Role> roles) {
        // Define role hierarchy (higher index = higher priority)
        List<String> roleHierarchy = List.of(
            "STAFF",           // Lowest priority - most common submission role
            "DCM", 
            "HOD", 
            "COMMITTEE", 
            "CHAIRPERSON", 
            "PRINCIPAL", 
            "ADMIN"           // Highest priority - but unlikely to submit forms
        );
        
        // Find the highest priority role
        return roles.stream()
                .map(role -> role.getName())
                .filter(roleHierarchy::contains)
                .max((role1, role2) -> Integer.compare(
                    roleHierarchy.indexOf(role1), 
                    roleHierarchy.indexOf(role2)
                ))
                .orElse("STAFF"); // Default fallback
    }
}
