package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Map;
import java.util.UUID;

public interface HODService {
    
    /**
     * Get HOD dashboard with pending approvals and statistics
     */
    Map<String, Object> getHODDashboard();
    
    /**
     * Get appraisals pending HOD approval (status = HOD_APPROVED needed)
     */
    Page<AppraisalFormDTO> getPendingApprovals(Pageable pageable, String department);
    
    /**
     * Submit HOD approval/rejection for an appraisal
     */
    ReviewDTO submitHODDecision(ReviewDTO reviewDTO, String currentUserEmail);
    
    /**
     * Get specific appraisal for HOD review
     */
    AppraisalFormDTO getAppraisalForHODReview(UUID formId);
    
    /**
     * Get HOD's review history
     */
    Page<ReviewDTO> getHODReviewHistory(Pageable pageable, String academicYear);
    
    /**
     * Get department statistics for HOD
     */
    Map<String, Object> getDepartmentStatistics(String academicYear, String department);
    
    /**
     * Get staff performance overview for the department
     */
    Map<String, Object> getStaffPerformanceOverview(String academicYear, String department);
} 