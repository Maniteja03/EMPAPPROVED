package com.cvrce.apraisal.enums;

public enum PublicationType {
    JOURNAL,
    CONFERENCE,
    BOOK_CHAPTER,
    OTHER
}
