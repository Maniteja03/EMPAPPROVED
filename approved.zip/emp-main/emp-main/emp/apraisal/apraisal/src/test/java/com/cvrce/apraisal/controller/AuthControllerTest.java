package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.auth.LoginRequestDTO;
import com.cvrce.apraisal.dto.auth.LoginResponseDTO;
import com.cvrce.apraisal.dto.user.UserCreateDTO;
import com.cvrce.apraisal.service.AuthService;
import com.cvrce.apraisal.service.OtpService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AuthService authService;

    @MockBean
    private OtpService otpService;

    @MockBean
    private PasswordEncoder passwordEncoder;

    private LoginRequestDTO validLoginRequest;
    private UserCreateDTO validUserCreateRequest;

    @BeforeEach
    void setUp() {
        validLoginRequest = new LoginRequestDTO();
        validLoginRequest.setEmail("john.doe@university.edu");
        validLoginRequest.setPassword("password123");

        validUserCreateRequest = new UserCreateDTO();
        validUserCreateRequest.setEmployeeId("EMP001");
        validUserCreateRequest.setFullName("John Doe");
        validUserCreateRequest.setEmail("john.doe@university.edu");
        validUserCreateRequest.setPassword("SecurePass123!");
        validUserCreateRequest.setDepartmentId(1L);
        validUserCreateRequest.setDateOfJoining(LocalDate.now());
        validUserCreateRequest.setRoles(Set.of("STAFF"));
    }

    @Test
    void login_Success() throws Exception {
        // Given
        LoginResponseDTO expectedResponse = LoginResponseDTO.builder()
                .token("jwt-token")
                .userId("user-id")
                .email("john.doe@university.edu")
                .role("STAFF")
                .build();

        when(authService.login(any(LoginRequestDTO.class))).thenReturn(expectedResponse);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(validLoginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.email").value("john.doe@university.edu"))
                .andExpect(jsonPath("$.role").value("STAFF"));

        verify(authService).login(any(LoginRequestDTO.class));
    }

    @Test
    void login_InvalidCredentials() throws Exception {
        // Given
        when(authService.login(any(LoginRequestDTO.class)))
                .thenThrow(new BadCredentialsException("Invalid credentials"));

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(validLoginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Invalid email or password"));

        verify(authService).login(any(LoginRequestDTO.class));
    }

    @Test
    void login_UserNotFound() throws Exception {
        // Given
        when(authService.login(any(LoginRequestDTO.class)))
                .thenThrow(new UsernameNotFoundException("User not found"));

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(validLoginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("User not found"));

        verify(authService).login(any(LoginRequestDTO.class));
    }

    @Test
    void login_ValidationError_EmptyEmail() throws Exception {
        // Given
        LoginRequestDTO invalidRequest = new LoginRequestDTO();
        invalidRequest.setEmail("");
        invalidRequest.setPassword("password123");

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());

        verify(authService, never()).login(any());
    }

    @Test
    void login_ValidationError_InvalidEmailFormat() throws Exception {
        // Given
        LoginRequestDTO invalidRequest = new LoginRequestDTO();
        invalidRequest.setEmail("invalid-email");
        invalidRequest.setPassword("password123");

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());

        verify(authService, never()).login(any());
    }

    @Test
    void register_Success() throws Exception {
        // Given
        doNothing().when(authService).register(any(UserCreateDTO.class));

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(validUserCreateRequest)))
                .andExpect(status().isOk())
                .andExpect(content().string("User registered successfully"));

        verify(authService).register(any(UserCreateDTO.class));
    }

    @Test
    void register_ValidationError_WeakPassword() throws Exception {
        // Given
        UserCreateDTO invalidRequest = new UserCreateDTO();
        invalidRequest.setEmployeeId("EMP001");
        invalidRequest.setFullName("John Doe");
        invalidRequest.setEmail("john.doe@university.edu");
        invalidRequest.setPassword("weak"); // Weak password
        invalidRequest.setDepartmentId(1L);
        invalidRequest.setDateOfJoining(LocalDate.now());
        invalidRequest.setRoles(Set.of("STAFF"));

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());

        verify(authService, never()).register(any());
    }

    @Test
    void register_ValidationError_EmptyFullName() throws Exception {
        // Given
        UserCreateDTO invalidRequest = new UserCreateDTO();
        invalidRequest.setEmployeeId("EMP001");
        invalidRequest.setFullName(""); // Empty name
        invalidRequest.setEmail("john.doe@university.edu");
        invalidRequest.setPassword("SecurePass123!");
        invalidRequest.setDepartmentId(1L);
        invalidRequest.setDateOfJoining(LocalDate.now());
        invalidRequest.setRoles(Set.of("STAFF"));

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());

        verify(authService, never()).register(any());
    }

    @Test
    void register_ValidationError_FutureDateOfJoining() throws Exception {
        // Given
        UserCreateDTO invalidRequest = new UserCreateDTO();
        invalidRequest.setEmployeeId("EMP001");
        invalidRequest.setFullName("John Doe");
        invalidRequest.setEmail("john.doe@university.edu");
        invalidRequest.setPassword("SecurePass123!");
        invalidRequest.setDepartmentId(1L);
        invalidRequest.setDateOfJoining(LocalDate.now().plusDays(1)); // Future date
        invalidRequest.setRoles(Set.of("STAFF"));

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());

        verify(authService, never()).register(any());
    }

    @Test
    void requestOtp_Success() throws Exception {
        // Given
        String email = "john.doe@university.edu";
        String otp = "123456";
        when(otpService.generateOtp(email)).thenReturn(otp);

        // When & Then
        mockMvc.perform(post("/api/auth/request-otp")
                .param("email", email))
                .andExpect(status().isOk())
                .andExpect(content().string("OTP sent to your email: " + otp));

        verify(otpService).generateOtp(email);
    }

    @Test
    void requestOtp_UserNotFound() throws Exception {
        // Given
        String email = "nonexistent@university.edu";

        // When & Then
        mockMvc.perform(post("/api/auth/request-otp")
                .param("email", email))
                .andExpect(status().isNotFound())
                .andExpect(content().string("User not found"));

        verify(otpService, never()).generateOtp(anyString());
    }

    @Test
    void login_InternalServerError() throws Exception {
        // Given
        when(authService.login(any(LoginRequestDTO.class)))
                .thenThrow(new RuntimeException("Database connection error"));

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(validLoginRequest)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Something went wrong: Database connection error"));

        verify(authService).login(any(LoginRequestDTO.class));
    }
} 