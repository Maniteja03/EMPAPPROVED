package com.cvrce.apraisal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.BucketLocationConstraint;
import software.amazon.awssdk.services.s3.model.CreateBucketConfiguration;
import software.amazon.awssdk.services.s3.model.CreateBucketRequest;
import software.amazon.awssdk.services.s3.model.HeadBucketRequest;
import software.amazon.awssdk.services.s3.model.NoSuchBucketException;

import jakarta.annotation.PostConstruct;

@Configuration
@Profile("production")
public class S3Config {

    @Value("${aws.access-key-id}")
    private String accessKeyId;

    @Value("${aws.secret-access-key}")
    private String secretAccessKey;

    @Value("${aws.s3.region:ap-south-1}")
    private String region;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Bean
    public S3Client s3Client() {
        AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(accessKeyId, secretAccessKey);
        
        return S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
                .build();
    }

    @PostConstruct
    public void initializeBucket() {
        S3Client s3Client = s3Client();
        
        try {
            // Check if bucket exists
            s3Client.headBucket(HeadBucketRequest.builder()
                    .bucket(bucketName)
                    .build());
            
            System.out.println("S3 bucket '" + bucketName + "' already exists in region " + region);
            
        } catch (NoSuchBucketException e) {
            // Create bucket if it doesn't exist
            CreateBucketConfiguration bucketConfiguration = CreateBucketConfiguration.builder()
                    .locationConstraint(BucketLocationConstraint.fromValue(region))
                    .build();
            
            CreateBucketRequest createBucketRequest = CreateBucketRequest.builder()
                    .bucket(bucketName)
                    .createBucketConfiguration(bucketConfiguration)
                    .build();
            
            s3Client.createBucket(createBucketRequest);
            System.out.println("Created S3 bucket '" + bucketName + "' in region " + region);
        }
    }
} 