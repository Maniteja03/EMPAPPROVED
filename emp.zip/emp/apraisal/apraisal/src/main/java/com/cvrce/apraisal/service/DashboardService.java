package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.DashboardSummaryDTO;
import java.util.List;
import java.util.Map;

public interface DashboardService {
    DashboardSummaryDTO getDashboardSummary();
    
    // Missing methods called by DashboardController
    Map<String, Object> getStaffStats();
    List<Map<String, Object>> getMyNotifications(int limit, boolean unreadOnly);
    Map<String, Object> getRoleBasedTasks();
    List<Map<String, Object>> getWorkflowProgress(String formId);
    Map<String, Object> getDashboardConfig();
    Map<String, String> updateDashboardPreferences(Map<String, Object> preferences);
}
