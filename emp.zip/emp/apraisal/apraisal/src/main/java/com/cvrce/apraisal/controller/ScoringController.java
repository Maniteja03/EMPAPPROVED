package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.scoring.ComponentScoreBreakdown;
import com.cvrce.apraisal.dto.scoring.ScoringCalculationResult;
import com.cvrce.apraisal.service.ScoringCalculationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/scoring")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class ScoringController {
    
    private final ScoringCalculationService scoringCalculationService;
    
    // Get complete scoring calculation for an appraisal form
    @GetMapping("/calculate/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<ScoringCalculationResult> calculateCompleteScoring(@PathVariable UUID formId) {
        log.info("Calculating complete scoring for form: {}", formId);
        ScoringCalculationResult result = scoringCalculationService.calculateCompleteScoring(formId);
        return ResponseEntity.ok(result);
    }
    
    // Get detailed score breakdown
    @GetMapping("/breakdown/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<ComponentScoreBreakdown>> getDetailedScoreBreakdown(@PathVariable UUID formId) {
        log.info("Getting detailed score breakdown for form: {}", formId);
        List<ComponentScoreBreakdown> breakdown = scoringCalculationService.getDetailedScoreBreakdown(formId);
        return ResponseEntity.ok(breakdown);
    }
    
    // Recalculate scoring after updates
    @PostMapping("/recalculate/{formId}")
    @PreAuthorize("hasAnyRole('DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<ScoringCalculationResult> recalculateScoring(@PathVariable UUID formId) {
        log.info("Recalculating scoring for form: {}", formId);
        scoringCalculationService.recalculateScoring(formId);
        ScoringCalculationResult result = scoringCalculationService.calculateCompleteScoring(formId);
        return ResponseEntity.ok(result);
    }
    
    // Apply manual override to specific component
    @PostMapping("/manual-override/{formId}")
    @PreAuthorize("hasAnyRole('DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, String>> applyManualOverride(
            @PathVariable UUID formId,
            @RequestBody ManualOverrideRequest request) {
        
        log.info("Applying manual override for form: {}, component: {}, score: {}", 
                formId, request.getComponentType(), request.getOverrideScore());
        
        scoringCalculationService.applyManualOverride(
                formId, 
                request.getComponentType(), 
                request.getOverrideScore(), 
                request.getReason()
        );
        
        return ResponseEntity.ok(Map.of("message", "Manual override applied successfully"));
    }
    
    // Get Part A scoring
    @GetMapping("/part-a/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<BigDecimal> getPartAScoring(@PathVariable UUID formId) {
        log.info("Getting Part A scoring for form: {}", formId);
        // Implementation would get scoring and calculate Part A
        return ResponseEntity.ok(BigDecimal.ZERO); // Placeholder
    }
    
    // Get Part B scoring
    @GetMapping("/part-b/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<BigDecimal> getPartBScoring(@PathVariable UUID formId) {
        log.info("Getting Part B scoring for form: {}", formId);
        // Implementation would get scoring and calculate Part B
        return ResponseEntity.ok(BigDecimal.ZERO); // Placeholder
    }
    
    // Get Part C scoring
    @GetMapping("/part-c/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<BigDecimal> getPartCScoring(@PathVariable UUID formId) {
        log.info("Getting Part C scoring for form: {}", formId);
        // Implementation would get scoring and calculate Part C
        return ResponseEntity.ok(BigDecimal.ZERO); // Placeholder
    }
    
    // Validate scoring against designation limits
    @GetMapping("/validate/{formId}")
    @PreAuthorize("hasAnyRole('DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> validateScoring(@PathVariable UUID formId) {
        log.info("Validating scoring for form: {}", formId);
        // Implementation would validate scoring limits
        return ResponseEntity.ok(Map.of(
                "isValid", true,
                "validationErrors", List.of(),
                "warnings", List.of()
        ));
    }
    
    // DTO for manual override requests
    public static class ManualOverrideRequest {
        private String componentType;
        private BigDecimal overrideScore;
        private String reason;
        
        // Getters and setters
        public String getComponentType() { return componentType; }
        public void setComponentType(String componentType) { this.componentType = componentType; }
        public BigDecimal getOverrideScore() { return overrideScore; }
        public void setOverrideScore(BigDecimal overrideScore) { this.overrideScore = overrideScore; }
        public String getReason() { return reason; }
        public void setReason(String reason) { this.reason = reason; }
    }
} 