package com.cvrce.apraisal.dto.scoring;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScoringCalculationResult {
    
    private UUID appraisalFormId;
    private String facultyName;
    private String employeeId;
    private String academicYear;
    private String designationType;
    
    // Part Scores
    private BigDecimal partARawScore;
    private BigDecimal partAMaxRaw;
    private BigDecimal partAFinalScore; // Scaled to 40
    
    private BigDecimal partBRawScore;
    private BigDecimal partBMaxRaw;
    private BigDecimal partBFinalScore; // Scaled to 60
    
    private BigDecimal partCScore; // Max 25
    
    // Total Score
    private BigDecimal totalScore; // Max 125
    private BigDecimal maxPossibleScore;
    private BigDecimal scorePercentage;
    
    // Component Breakdowns
    private List<ComponentScoreBreakdown> componentBreakdowns;
    
    // Calculation Metadata
    private boolean isAutoCalculated;
    private boolean hasManualOverrides;
    private LocalDateTime calculatedAt;
    private String calculationNotes;
    
    // H&S Faculty Special Logic
    private boolean isHSFaculty;
    private BigDecimal hsOrganizingEventsScore;
    
    // Validation Results
    private boolean isValid;
    private List<String> validationErrors;
    private List<String> warnings;
} 