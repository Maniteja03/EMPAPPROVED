package com.cvrce.apraisal.enums;

public enum ProjectStatus {
    APPLIED,
    SANCTIONED,
    ONGOING,
    COMPLETED
}
