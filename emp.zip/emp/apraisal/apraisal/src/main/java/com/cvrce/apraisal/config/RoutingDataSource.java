package com.cvrce.apraisal.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Routing DataSource for Master-Slave Database Configuration
 * Automatically routes read operations to read replicas and write operations to master
 */
public class RoutingDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        // Check if current transaction is read-only
        if (TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
            // Route to read replica based on load balancing
            return determineReadDataSource();
        } else {
            // Route to master for write operations
            return DatabaseConfig.DatabaseType.MASTER;
        }
    }

    /**
     * Load balance between read replicas
     * Simple round-robin implementation
     */
    private DatabaseConfig.DatabaseType determineReadDataSource() {
        // Get thread ID for simple load balancing
        long threadId = Thread.currentThread().getId();
        
        // Simple round-robin between read replicas
        if (threadId % 2 == 0) {
            return DatabaseConfig.DatabaseType.READ1;
        } else {
            return DatabaseConfig.DatabaseType.READ2;
        }
    }

    /**
     * Force routing to master database
     * Used for operations that require immediate consistency
     */
    public static void routeToMaster() {
        DatabaseContextHolder.setDatabaseType(DatabaseConfig.DatabaseType.MASTER);
    }

    /**
     * Force routing to specific read replica
     */
    public static void routeToRead1() {
        DatabaseContextHolder.setDatabaseType(DatabaseConfig.DatabaseType.READ1);
    }

    /**
     * Force routing to specific read replica
     */
    public static void routeToRead2() {
        DatabaseContextHolder.setDatabaseType(DatabaseConfig.DatabaseType.READ2);
    }

    /**
     * Clear routing context
     */
    public static void clearRouting() {
        DatabaseContextHolder.clear();
    }
}

/**
 * Thread-local context holder for database routing
 */
class DatabaseContextHolder {
    private static final ThreadLocal<DatabaseConfig.DatabaseType> contextHolder = new ThreadLocal<>();

    public static void setDatabaseType(DatabaseConfig.DatabaseType databaseType) {
        contextHolder.set(databaseType);
    }

    public static DatabaseConfig.DatabaseType getDatabaseType() {
        return contextHolder.get();
    }

    public static void clear() {
        contextHolder.remove();
    }
} 