package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.parta.ConsultancyDTO;
import com.cvrce.apraisal.service.PartA_ConsultancyService;
import com.cvrce.apraisal.service.AppraisalFormService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/parta/consultancies")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
public class PartA_ConsultancyController {

    private final PartA_ConsultancyService consultancyService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping
    public ResponseEntity<ConsultancyDTO> add(@Valid @RequestBody ConsultancyDTO dto) {
        // SECURITY FIX: Validate ownership before allowing data modification
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized consultancy creation attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Adding consultancy to form {} by authorized user {}", dto.getAppraisalFormId(), currentUserEmail);
        return new ResponseEntity<>(consultancyService.addConsultancy(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<ConsultancyDTO>> getByForm(@PathVariable UUID formId) {
        // SECURITY FIX: Validate access before allowing data retrieval
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized consultancy access attempt on form {} by user {}", 
                    formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Fetching consultancies for form {} by authorized user {}", formId, currentUserEmail);
        return ResponseEntity.ok(consultancyService.getConsultanciesByFormId(formId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConsultancyDTO> update(@PathVariable UUID id, @Valid @RequestBody ConsultancyDTO dto) {
        // SECURITY FIX: Validate ownership before allowing updates
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized consultancy update attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Updating consultancy {} by authorized user {}", id, currentUserEmail);
        return ResponseEntity.ok(consultancyService.updateConsultancy(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        // SECURITY FIX: Validate ownership before allowing deletion
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            consultancyService.deleteConsultancy(id, currentUserEmail);
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            log.warn("Unauthorized consultancy deletion attempt for ID {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}
