package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.timeline.AppraisalTimelineDTO;
import com.cvrce.apraisal.dto.timeline.TimelineSetupDTO;
import com.cvrce.apraisal.dto.timeline.TimelineStatusDTO;
import com.cvrce.apraisal.dto.timeline.TimelineStatisticsDTO;
import com.cvrce.apraisal.dto.timeline.TimelineValidationResult;
import com.cvrce.apraisal.dto.timeline.TimelineReportDTO;
import com.cvrce.apraisal.service.ChairpersonTimelineService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/chairperson/timeline")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('CHAIRPERSON')")
public class ChairpersonTimelineController {
    
    private final ChairpersonTimelineService timelineService;
    
    /**
     * Create new appraisal timeline for academic year
     */
    @PostMapping("/create")
    public ResponseEntity<AppraisalTimelineDTO> createAppraisalTimeline(
            @Valid @RequestBody TimelineSetupDTO timelineSetup) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} creating timeline for academic year {}", 
                chairpersonEmail, timelineSetup.getAcademicYear());
        
        try {
            AppraisalTimelineDTO timeline = timelineService.createAppraisalTimeline(chairpersonEmail, timelineSetup);
            return ResponseEntity.ok(timeline);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid timeline setup by chairperson {}: {}", chairpersonEmail, e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (IllegalStateException e) {
            log.warn("Timeline creation failed for chairperson {}: {}", chairpersonEmail, e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
    
    /**
     * Update existing timeline (only if not finalized)
     */
    @PutMapping("/{timelineId}")
    public ResponseEntity<AppraisalTimelineDTO> updateAppraisalTimeline(
            @PathVariable UUID timelineId,
            @Valid @RequestBody TimelineSetupDTO timelineSetup) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} updating timeline {}", chairpersonEmail, timelineId);
        
        try {
            AppraisalTimelineDTO timeline = timelineService.updateAppraisalTimeline(
                    chairpersonEmail, timelineId, timelineSetup);
            return ResponseEntity.ok(timeline);
        } catch (SecurityException e) {
            log.warn("Unauthorized timeline update attempt by {}: {}", chairpersonEmail, e.getMessage());
            return ResponseEntity.status(403).build();
        } catch (IllegalStateException e) {
            log.warn("Timeline update failed: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }
    
    /**
     * Get active timeline for academic year
     */
    @GetMapping("/active/{academicYear}")
    public ResponseEntity<AppraisalTimelineDTO> getActiveTimelineForYear(
            @PathVariable String academicYear) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting active timeline for {}", chairpersonEmail, academicYear);
        
        AppraisalTimelineDTO timeline = timelineService.getActiveTimelineForYear(academicYear);
        
        if (timeline != null) {
            return ResponseEntity.ok(timeline);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Get all timelines created by this chairperson
     */
    @GetMapping("/my-timelines")
    public ResponseEntity<List<AppraisalTimelineDTO>> getMyTimelines() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting their created timelines", chairpersonEmail);
        
        List<AppraisalTimelineDTO> timelines = timelineService.getTimelinesCreatedByChairperson(chairpersonEmail);
        
        return ResponseEntity.ok(timelines);
    }
    
    /**
     * Get all active timelines across all academic years
     */
    @GetMapping("/all-active")
    public ResponseEntity<List<AppraisalTimelineDTO>> getAllActiveTimelines() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting all active timelines", chairpersonEmail);
        
        List<AppraisalTimelineDTO> timelines = timelineService.getAllActiveTimelines();
        
        return ResponseEntity.ok(timelines);
    }
    
    /**
     * Get current timeline status
     */
    @GetMapping("/status/{academicYear}")
    public ResponseEntity<TimelineStatusDTO> getCurrentTimelineStatus(
            @PathVariable String academicYear) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting timeline status for {}", chairpersonEmail, academicYear);
        
        TimelineStatusDTO status = timelineService.getCurrentTimelineStatus(academicYear);
        
        return ResponseEntity.ok(status);
    }
    
    /**
     * Get currently active timeline (auto-detect by date)
     */
    @GetMapping("/current")
    public ResponseEntity<AppraisalTimelineDTO> getCurrentActiveTimeline() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting current active timeline", chairpersonEmail);
        
        AppraisalTimelineDTO timeline = timelineService.getCurrentActiveTimeline();
        
        if (timeline != null) {
            return ResponseEntity.ok(timeline);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Finalize timeline (lock it from further changes)
     */
    @PostMapping("/{timelineId}/finalize")
    public ResponseEntity<Void> finalizeTimeline(@PathVariable UUID timelineId) {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} finalizing timeline {}", chairpersonEmail, timelineId);
        
        try {
            boolean finalized = timelineService.finalizeTimeline(chairpersonEmail, timelineId);
            
            if (finalized) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().build();
            }
        } catch (SecurityException e) {
            return ResponseEntity.status(403).build();
        }
    }
    
    /**
     * Deactivate timeline
     */
    @PostMapping("/{timelineId}/deactivate")
    public ResponseEntity<Void> deactivateTimeline(@PathVariable UUID timelineId) {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} deactivating timeline {}", chairpersonEmail, timelineId);
        
        try {
            boolean deactivated = timelineService.deactivateTimeline(chairpersonEmail, timelineId);
            
            if (deactivated) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().build();
            }
        } catch (SecurityException e) {
            return ResponseEntity.status(403).build();
        }
    }
    
    /**
     * Check if specific action is allowed
     */
    @GetMapping("/action-allowed/{academicYear}/{action}")
    public ResponseEntity<Boolean> isActionAllowed(
            @PathVariable String academicYear,
            @PathVariable String action) {
        
        boolean allowed = timelineService.isActionAllowed(academicYear, action);
        
        return ResponseEntity.ok(allowed);
    }
    
    /**
     * Get timeline template (suggested dates)
     */
    @GetMapping("/template/{academicYear}")
    public ResponseEntity<TimelineSetupDTO> getTimelineTemplate(
            @PathVariable String academicYear,
            @RequestParam(required = false) LocalDate startDate) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting timeline template for {}", chairpersonEmail, academicYear);
        
        LocalDate templateStartDate = startDate != null ? startDate : LocalDate.now().plusDays(7);
        TimelineSetupDTO template = timelineService.getTimelineTemplate(academicYear, templateStartDate);
        
        return ResponseEntity.ok(template);
    }
    
    /**
     * Clone timeline from previous year
     */
    @PostMapping("/clone")
    public ResponseEntity<AppraisalTimelineDTO> cloneTimelineFromPreviousYear(
            @RequestParam String sourceAcademicYear,
            @RequestParam String targetAcademicYear,
            @RequestParam(defaultValue = "365") int dayOffset) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} cloning timeline from {} to {} with {} day offset", 
                chairpersonEmail, sourceAcademicYear, targetAcademicYear, dayOffset);
        
        try {
            AppraisalTimelineDTO clonedTimeline = timelineService.cloneTimelineFromPreviousYear(
                    chairpersonEmail, sourceAcademicYear, targetAcademicYear, dayOffset);
            
            return ResponseEntity.ok(clonedTimeline);
        } catch (IllegalArgumentException e) {
            log.warn("Timeline cloning failed: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }
    
    /**
     * Get timeline statistics
     */
    @GetMapping("/statistics")
    public ResponseEntity<TimelineStatisticsDTO> getTimelineStatistics() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting timeline statistics", chairpersonEmail);
        
        TimelineStatisticsDTO statistics = timelineService.getTimelineStatistics(chairpersonEmail);
        
        return ResponseEntity.ok(statistics);
    }
    
    /**
     * Validate timeline dates
     */
    @PostMapping("/validate")
    public ResponseEntity<TimelineValidationResult> validateTimelineDates(
            @RequestBody TimelineSetupDTO timelineSetup) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} validating timeline dates", chairpersonEmail);
        
        TimelineValidationResult validation = timelineService.validateTimelineDates(timelineSetup);
        
        return ResponseEntity.ok(validation);
    }
    
    /**
     * Get overdue timelines
     */
    @GetMapping("/overdue")
    public ResponseEntity<List<AppraisalTimelineDTO>> getOverdueTimelines() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting overdue timelines", chairpersonEmail);
        
        List<AppraisalTimelineDTO> overdueTimelines = timelineService.getOverdueTimelines();
        
        return ResponseEntity.ok(overdueTimelines);
    }
    
    /**
     * Force complete timeline (emergency action)
     */
    @PostMapping("/{timelineId}/force-complete")
    public ResponseEntity<Void> forceCompleteTimeline(
            @PathVariable UUID timelineId,
            @RequestParam String reason) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.warn("Chairperson {} force completing timeline {} - Reason: {}", 
                chairpersonEmail, timelineId, reason);
        
        try {
            boolean completed = timelineService.forceCompleteTimeline(chairpersonEmail, timelineId, reason);
            
            if (completed) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().build();
            }
        } catch (SecurityException e) {
            return ResponseEntity.status(403).build();
        }
    }
    
    /**
     * Generate timeline report
     */
    @GetMapping("/{timelineId}/report")
    public ResponseEntity<TimelineReportDTO> generateTimelineReport(@PathVariable UUID timelineId) {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} requesting timeline report for {}", chairpersonEmail, timelineId);
        
        try {
            TimelineReportDTO report = timelineService.generateTimelineReport(timelineId);
            return ResponseEntity.ok(report);
        } catch (SecurityException e) {
            return ResponseEntity.status(403).build();
        }
    }
    
    /**
     * Manual phase update (admin override)
     */
    @PostMapping("/update-phases")
    public ResponseEntity<Integer> updateTimelinePhases() {
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} manually triggering timeline phase updates", chairpersonEmail);
        
        int updatedCount = timelineService.updateTimelinePhases();
        
        return ResponseEntity.ok(updatedCount);
    }
    
    /**
     * Send deadline reminders manually
     */
    @PostMapping("/send-reminders")
    public ResponseEntity<Integer> sendDeadlineReminders(
            @RequestParam(defaultValue = "3") int daysBeforeDeadline) {
        
        String chairpersonEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson {} manually sending deadline reminders ({} days before)", 
                chairpersonEmail, daysBeforeDeadline);
        
        int remindersSent = timelineService.sendDeadlineReminders(daysBeforeDeadline);
        
        return ResponseEntity.ok(remindersSent);
    }
} 