package com.cvrce.apraisal.service;

import java.util.UUID;

import com.cvrce.apraisal.dto.user.*;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface UserService {
    UserResponseDTO getUserById(UUID id);
    UserResponseDTO getUserByEmail(String email);
    UserResponseDTO createUser(UserCreateDTO dto);
    UserResponseDTO updateUser(UUID id, UserUpdateDTO dto);
    void softDeleteUser(UUID id);
    void setUserEnabled(UUID id, boolean enabled);
    
    // Get users by department (non-paginated)
    List<UserResponseDTO> getUsersByDepartment(Long deptId);
    
    // Get users by department (paginated)  
    Page<UserResponseDTO> getUsersByDepartment(Long deptId, Pageable pageable);
    
    // Paginated methods
    Page<UserResponseDTO> getAllUsers(Pageable pageable, String search, Long departmentId, Boolean enabled);
    Page<UserResponseDTO> searchUsers(String query, Pageable pageable);
    Page<UserResponseDTO> getUsersByRole(String roleName, Pageable pageable);
    
    // Security validation methods
    boolean isUserAllowedToViewProfile(UUID userId, String currentUserEmail);
    boolean isCurrentUser(UUID userId, String currentUserEmail);
    
    // Missing methods called by UserController
    User getCurrentUser();
    User updateCurrentUser(UserUpdateDTO updateData);
    String updateProfilePicture(MultipartFile file);
    UserResponseDTO convertToResponseDTO(User user);
}
