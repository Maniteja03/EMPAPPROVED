package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.service.DashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import com.cvrce.apraisal.dto.DashboardSummaryDTO;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Slf4j
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/staff/stats")
    @PreAuthorize("hasRole('STAFF')")
    public ResponseEntity<Map<String, Object>> getStaffStats() {
        Map<String, Object> stats = dashboardService.getStaffStats();
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/notifications")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getMyNotifications(@RequestParam(defaultValue = "10") int limit,
                                                                         @RequestParam(defaultValue = "false") boolean unreadOnly) {
        List<Map<String, Object>> notifications = dashboardService.getMyNotifications(limit, unreadOnly);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/role-tasks")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> getRoleBasedTasks() {
        Map<String, Object> tasks = dashboardService.getRoleBasedTasks();
        return ResponseEntity.ok(tasks);
    }

    @GetMapping("/workflow/{formId}")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getWorkflowProgress(@PathVariable String formId) {
        List<Map<String, Object>> workflow = dashboardService.getWorkflowProgress(formId);
        return ResponseEntity.ok(workflow);
    }

    @GetMapping("/config")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> getDashboardConfig() {
        Map<String, Object> config = dashboardService.getDashboardConfig();
        return ResponseEntity.ok(config);
    }

    @PutMapping("/preferences")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, String>> updateDashboardPreferences(@RequestBody Map<String, Object> preferences) {
        Map<String, String> response = dashboardService.updateDashboardPreferences(preferences);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/summary")
    public ResponseEntity<DashboardSummaryDTO> getDashboardSummary() {
        DashboardSummaryDTO summary = dashboardService.getDashboardSummary();
        return ResponseEntity.ok(summary);
    }
}
