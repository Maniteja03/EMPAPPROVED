package com.cvrce.apraisal.dto.appraisal;

import lombok.Data;
import lombok.Builder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.cvrce.apraisal.enums.AppraisalStatus;

@Data
@Builder
public class AppraisalFormDTO {
    private UUID id;
    private String academicYear;
    private double totalScore;
    private String status; // String representation of AppraisalStatus
    private boolean locked;
    private LocalDate submittedDate;
    private UUID userId;
    private String userName;
    private String userFullName;
    private String userDepartment; // Add department info
    private String submittedAsRole;
    
    // Additional fields for committee review
    private boolean readOnly; // For own department forms (view only)
    private LocalDateTime lockExpiresAt; // When form lock expires
    private String lockStatus; // "LOCKED", "AVAILABLE", "LOCKED_BY_ME"
    private String assignedCommitteeMember; // Who is reviewing this form
}

