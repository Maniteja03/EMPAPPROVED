package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "publication_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PublicationScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Publication Details
    @Column(name = "title", nullable = false, columnDefinition = "TEXT")
    private String title;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "publication_type", nullable = false)
    private PublicationType publicationType;
    
    @Column(name = "journal_name", columnDefinition = "TEXT")
    private String journalName;
    
    @Column(name = "year_of_publication", nullable = false)
    private Integer yearOfPublication;
    
    @Column(name = "doi_link", columnDefinition = "TEXT")
    private String doiLink;
    
    @Column(name = "issn_isbn", length = 50)
    private String issnIsbn;
    
    @Column(name = "scopus_author_id", length = 100)
    private String scopusAuthorId;
    
    @Column(name = "orcid_link", columnDefinition = "TEXT")
    private String orcidLink;
    
    @Column(name = "irins_link", columnDefinition = "TEXT")
    private String irinsLink;
    
    // CVR Faculty Authors
    @Column(name = "total_cvr_authors", nullable = false)
    @Builder.Default
    private Integer totalCVRAuthors = 1;
    
    @Column(name = "faculty_author_position", nullable = false)
    @Builder.Default
    private Integer facultyAuthorPosition = 1; // Position of this faculty in author list
    
    @Column(name = "cvr_author_names", columnDefinition = "TEXT")
    private String cvrAuthorNames; // Comma-separated list
    
    // Scoring
    @Column(name = "max_points_for_type", precision = 10, scale = 2)
    private BigDecimal maxPointsForType; // Based on publication type and designation
    
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // Verification and Proof
    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private Boolean isVerified = false;
    
    @Column(name = "verification_source", length = 100)
    private String verificationSource; // Scopus, WoS, etc.
    
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    @Column(name = "first_page_proof_path", columnDefinition = "TEXT")
    private String firstPageProofPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points based on publication type and author count
    public void calculatePoints() {
        if (publicationType != null && totalCVRAuthors != null && totalCVRAuthors > 0) {
            BigDecimal basePoints = getBasePointsForType();
            this.autoCalculatedPoints = calculatePointsBasedOnAuthors(basePoints, totalCVRAuthors);
            
            if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
                this.pointsClaimed = autoCalculatedPoints;
            }
        }
    }
    
    private BigDecimal getBasePointsForType() {
        return switch (publicationType) {
            case JOURNAL_SCI_SCIE -> new BigDecimal("10.0");
            case JOURNAL_SCOPUS_WOS_ESCI -> new BigDecimal("7.5");
            case CONFERENCE_PROCEEDINGS_BOOK -> new BigDecimal("5.0");
        };
    }
    
    private BigDecimal calculatePointsBasedOnAuthors(BigDecimal basePoints, int authorCount) {
        // Points distribution based on Table 2 from Annexure I
        return switch (authorCount) {
            case 1 -> basePoints; // Full points
            case 2 -> basePoints.multiply(new BigDecimal("0.5")); // 50%
            case 3 -> basePoints.multiply(new BigDecimal("0.333")); // 33.3%
            case 4 -> basePoints.multiply(new BigDecimal("0.25")); // 25%
            default -> basePoints.multiply(new BigDecimal("0.2")); // 20% for 5+ authors
        };
    }
    
    // Validation helper
    public boolean isValidForScoring() {
        return title != null && !title.trim().isEmpty() &&
               publicationType != null &&
               yearOfPublication != null &&
               totalCVRAuthors != null && totalCVRAuthors > 0;
    }
}

enum PublicationType {
    JOURNAL_SCI_SCIE("Journal (SCI/SCIE)", new BigDecimal("10.0")),
    JOURNAL_SCOPUS_WOS_ESCI("Journal (Scopus/WoS-ESCI)", new BigDecimal("7.5")),
    CONFERENCE_PROCEEDINGS_BOOK("Conference Proceedings/Book Series/Book Chapter", new BigDecimal("5.0"));
    
    private final String displayName;
    private final BigDecimal maxPoints;
    
    PublicationType(String displayName, BigDecimal maxPoints) {
        this.displayName = displayName;
        this.maxPoints = maxPoints;
    }
    
    public String getDisplayName() { return displayName; }
    public BigDecimal getMaxPoints() { return maxPoints; }
} 