package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.NotificationDTO;
import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.entity.SummaryEvaluation;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.SummaryEvaluationRepository;
import com.cvrce.apraisal.service.NotificationService;
import com.cvrce.apraisal.service.PrincipalService;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrincipalServiceImpl implements PrincipalService {

    private final AppraisalFormRepository formRepository;
    private final SummaryEvaluationRepository summaryEvaluationRepository;
    private final NotificationService notificationService;
    private final AppraisalWorkflowService workflowService;

    @Override
    public List<AppraisalFormDTO> getPendingFinalApprovals() {
        List<AppraisalForm> pendingForms = formRepository.findByStatus(AppraisalStatus.COLLEGE_REVIEW);
        
        return pendingForms.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AppraisalFormDTO getAppraisalForFinalReview(UUID formId) {
        AppraisalForm form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (!AppraisalStatus.COLLEGE_REVIEW.equals(form.getStatus())) {
            throw new IllegalStateException("Appraisal is not ready for final review");
        }
        
        return convertToDTO(form);
    }

    @Override
    @Transactional
    public void provideFinalDecision(UUID formId, String decision, String comments) {
        AppraisalForm form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));

        if (!AppraisalStatus.COLLEGE_REVIEW.equals(form.getStatus())) {
            throw new IllegalStateException("Appraisal is not in correct status for final decision");
        }

        ReviewDecision reviewDecision;
        AppraisalStatus newStatus;
        
        try {
            // Map user input to available enum values
            if ("APPROVED".equalsIgnoreCase(decision) || "APPROVE".equalsIgnoreCase(decision)) {
                reviewDecision = ReviewDecision.APPROVED;
            } else if ("REJECTED".equalsIgnoreCase(decision) || "REUPLOAD".equalsIgnoreCase(decision)) {
                reviewDecision = ReviewDecision.REJECTED;
            } else {
                throw new IllegalArgumentException("Invalid decision. Must be APPROVED or REJECTED");
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid decision. Must be APPROVED or REJECTED");
        }

        // Update or create summary evaluation
        Optional<SummaryEvaluation> existingEvaluation = summaryEvaluationRepository.findByAppraisalFormId(formId);
        SummaryEvaluation finalEvaluation;
        
        if (existingEvaluation.isPresent()) {
            finalEvaluation = existingEvaluation.get();
            finalEvaluation.setFinalRecommendation(reviewDecision.name());
            finalEvaluation.setRemarks(comments != null ? comments : "");
            finalEvaluation.setReviewedByRole("PRINCIPAL");
        } else {
            finalEvaluation = SummaryEvaluation.builder()
                    .appraisalForm(form)
                    .finalRecommendation(reviewDecision.name())
                    .remarks(comments != null ? comments : "")
                    .reviewedByRole("PRINCIPAL")
                    .totalPointsClaimed(0.0f)
                    .totalPointsAwarded(0.0f)
                    .build();
        }

        summaryEvaluationRepository.save(finalEvaluation);

        // Update form status using workflow service
        newStatus = workflowService.transitionToNextStage(
            formId, 
            form.getStatus(), 
            decision
        );
        
        if (newStatus == AppraisalStatus.COMPLETED) {
            log.info("Appraisal {} finally approved by Principal", formId);
        } else {
            log.info("Appraisal {} rejected by Principal", formId);
        }

        form.setStatus(newStatus);
        formRepository.save(form);

        // Send notification to staff member
        String notificationMessage = ReviewDecision.APPROVED.equals(reviewDecision) 
            ? "Your appraisal has been finally approved by the Principal"
            : "Your appraisal requires modifications. Please check comments and resubmit";
            
        NotificationDTO notification = NotificationDTO.builder()
                .userId(form.getUser().getId())
                .title("Final Appraisal Decision")
                .message(notificationMessage)
                .read(false)
                .timestamp(java.time.LocalDateTime.now())
                .build();
        notificationService.sendNotification(notification);
    }

    @Override
    public Map<String, Object> getPrincipalDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        
        // Get counts for different statuses
        List<AppraisalForm> allForms = formRepository.findAll();
        long pendingApprovals = allForms.stream()
                .mapToLong(form -> AppraisalStatus.COLLEGE_REVIEW.equals(form.getStatus()) ? 1 : 0)
                .sum();
        long completedApprovals = allForms.stream()
                .mapToLong(form -> AppraisalStatus.COMPLETED.equals(form.getStatus()) ? 1 : 0)
                .sum();
        long totalSubmissions = allForms.size();
        
        dashboard.put("pendingFinalApprovals", pendingApprovals);
        dashboard.put("completedApprovals", completedApprovals);
        dashboard.put("totalSubmissions", totalSubmissions);
        dashboard.put("approvalRate", totalSubmissions > 0 ? (completedApprovals * 100.0 / totalSubmissions) : 0);
        
        // Get recent activities (last 10)
        List<AppraisalForm> recentSubmissions = allForms.stream()
                .sorted((a, b) -> b.getUpdatedAt().compareTo(a.getUpdatedAt()))
                .limit(10)
                .collect(Collectors.toList());
        dashboard.put("recentActivities", recentSubmissions.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList()));
        
        return dashboard;
    }

    @Override
    @Transactional
    public void bulkApprove(List<UUID> formIds) {
        List<AppraisalForm> forms = formRepository.findAllById(formIds);
        
        for (AppraisalForm form : forms) {
            if (AppraisalStatus.PRINCIPAL_REVIEW.equals(form.getStatus())) {
                provideFinalDecision(form.getId(), "APPROVED", "Bulk approved by Principal");
            }
        }
        
        log.info("Bulk approved {} appraisals", forms.size());
    }

    @Override
    public Map<String, Object> getAppraisalStatistics(String academicYear) {
        Map<String, Object> stats = new HashMap<>();
        
        List<AppraisalForm> yearForms = formRepository.findByAcademicYear(academicYear);
        
        Map<AppraisalStatus, Long> statusCounts = yearForms.stream()
                .collect(Collectors.groupingBy(
                    AppraisalForm::getStatus,
                    Collectors.counting()
                ));
        
        stats.put("totalFormsSubmitted", yearForms.size());
        stats.put("statusBreakdown", statusCounts);
        stats.put("completionRate", calculateCompletionRate(yearForms));
        stats.put("averageProcessingTime", calculateAverageProcessingTime(yearForms));
        
        return stats;
    }
    
    private AppraisalFormDTO convertToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .userId(form.getUser().getId())
                .userFullName(form.getUser().getFullName())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .locked(form.isLocked())
                .build();
    }
    
    private double calculateCompletionRate(List<AppraisalForm> forms) {
        if (forms.isEmpty()) return 0.0;
        
        long completed = forms.stream()
                .mapToLong(form -> AppraisalStatus.COMPLETED.equals(form.getStatus()) ? 1 : 0)
                .sum();
        
        return (completed * 100.0) / forms.size();
    }
    
    private double calculateAverageProcessingTime(List<AppraisalForm> forms) {
        // Simplified calculation - you might want to track actual processing times
        return forms.stream()
                .filter(form -> form.getSubmittedDate() != null && form.getUpdatedAt() != null)
                .mapToDouble(form -> java.time.temporal.ChronoUnit.DAYS.between(
                    form.getSubmittedDate(), form.getUpdatedAt()))
                .average()
                .orElse(0.0);
    }

    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        
        // Use efficient queries instead of findAll()
        long totalForms = formRepository.count();
        long completedForms = formRepository.countByStatus(AppraisalStatus.COMPLETED);
        long pendingForms = formRepository.countByStatus(AppraisalStatus.COLLEGE_REVIEW);
        
        double completionRate = totalForms > 0 ? (double) completedForms / totalForms * 100 : 0.0;
        
        stats.put("totalForms", totalForms);
        stats.put("completedForms", completedForms);
        stats.put("pendingForms", pendingForms);
        stats.put("completionRate", completionRate);
        
        return stats;
    }
} 