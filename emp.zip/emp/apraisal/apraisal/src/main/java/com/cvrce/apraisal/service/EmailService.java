package com.cvrce.apraisal.service;

public interface EmailService {
    
    /**
     * Send OTP email for password reset
     * @param email User's email address
     * @param otp Generated OTP
     * @param userName User's full name
     */
    void sendOtpEmail(String email, String otp, String userName);
    
    /**
     * Send welcome email with login credentials when admin creates account
     * @param email User's email address
     * @param userName User's full name
     * @param temporaryPassword Temporary password
     * @param employeeId Employee ID
     */
    void sendWelcomeEmail(String email, String userName, String temporaryPassword, String employeeId);
    
    /**
     * Send general notification email
     * @param email User's email address
     * @param subject Email subject
     * @param message Email message
     */
    void sendNotificationEmail(String email, String subject, String message);
} 