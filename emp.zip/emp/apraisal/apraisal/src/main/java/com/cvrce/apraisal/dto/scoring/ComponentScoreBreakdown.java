package com.cvrce.apraisal.dto.scoring;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComponentScoreBreakdown {
    
    private String componentName; // e.g., "Publications", "Citations", etc.
    private String annexureReference; // e.g., "Annexure I", "Annexure II", etc.
    private String partName; // "Part A", "Part B", "Part C"
    
    // Scoring Details
    private BigDecimal maxPossibleScore;
    private BigDecimal claimedScore;
    private BigDecimal awardedScore;
    private BigDecimal autoCalculatedScore;
    
    // Calculation Details
    private String calculationFormula;
    private String calculationNotes;
    
    // Individual Items
    private List<ComponentItemBreakdown> items;
    
    // Override Information
    private boolean hasManualOverride;
    private String overrideReason;
    private BigDecimal originalScore;
    
    // Verification Status
    private boolean isVerified;
    private String verificationSource;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ComponentItemBreakdown {
        private String itemTitle;
        private String itemType; // "Publication", "Patent", "Conference", etc.
        private BigDecimal itemScore;
        private String calculationDetails;
        private boolean isVerified;
        private String proofStatus;
    }
} 