package com.cvrce.apraisal.service;

import java.util.List;
import java.util.Map;

public interface AdminService {
    
    /**
     * Get system statistics from database
     */
    Map<String, Object> getSystemStats();
    
    /**
     * Get department overview with real data
     */
    List<Map<String, Object>> getDepartmentOverview();
    
    /**
     * Get system alerts from database
     */
    List<Map<String, Object>> getSystemAlerts();
    
    /**
     * Get recent activity from audit logs
     */
    List<Map<String, Object>> getRecentActivity(int limit);
    
    /**
     * Get system health metrics
     */
    Map<String, Object> getSystemHealth();
    
    /**
     * Create new user
     */
    Map<String, String> createUser(Map<String, Object> userData);
    
    /**
     * Get users with pagination
     */
    List<Map<String, Object>> getUsers(int page, int size);
    
    /**
     * Update existing user
     */
    Map<String, String> updateUser(String userId, Map<String, Object> userData);
    
    /**
     * Delete user
     */
    Map<String, String> deleteUser(String userId);
    
    /**
     * Reset user password
     */
    Map<String, String> resetUserPassword(String userId);
    
    /**
     * Toggle user active status
     */
    Map<String, String> toggleUserStatus(String userId);
    
    /**
     * Export system data in specified format
     */
    byte[] exportSystemData(String format);
} 