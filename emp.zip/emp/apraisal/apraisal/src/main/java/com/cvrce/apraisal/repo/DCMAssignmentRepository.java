package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.DCMAssignment;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DCMAssignmentRepository extends JpaRepository<DCMAssignment, UUID> {
    
    // Find active DCM assignments for a department in current academic year
    @Query("SELECT da FROM DCMAssignment da WHERE da.department = :department AND da.academicYear = :academicYear AND da.isActive = true")
    List<DCMAssignment> findActiveDCMsByDepartmentAndYear(@Param("department") Department department, @Param("academicYear") String academicYear);
    
    // Check if a staff member is currently a DCM for their department
    @Query("SELECT da FROM DCMAssignment da WHERE da.staffMember = :staffMember AND da.academicYear = :academicYear AND da.isActive = true")
    Optional<DCMAssignment> findActiveDCMAssignmentByStaffAndYear(@Param("staffMember") User staffMember, @Param("academicYear") String academicYear);
    
    // Get all staff members who are DCMs in a specific department
    @Query("SELECT da.staffMember FROM DCMAssignment da WHERE da.department = :department AND da.academicYear = :academicYear AND da.isActive = true")
    List<User> findDCMStaffByDepartmentAndYear(@Param("department") Department department, @Param("academicYear") String academicYear);
    
    // Find DCM assignments made by a specific HOD
    @Query("SELECT da FROM DCMAssignment da WHERE da.assignedByHod = :hod AND da.academicYear = :academicYear AND da.isActive = true")
    List<DCMAssignment> findAssignmentsByHODAndYear(@Param("hod") User hod, @Param("academicYear") String academicYear);
    
    // Deactivate all DCM assignments for a department in a specific year (when reassigning)
    @Modifying
    @Query("UPDATE DCMAssignment da SET da.isActive = false, da.deactivatedAt = CURRENT_TIMESTAMP WHERE da.department = :department AND da.academicYear = :academicYear AND da.isActive = true")
    int deactivateAllDCMsForDepartmentAndYear(@Param("department") Department department, @Param("academicYear") String academicYear);
    
    // Deactivate specific DCM assignment
    @Modifying
    @Query("UPDATE DCMAssignment da SET da.isActive = false, da.deactivatedAt = CURRENT_TIMESTAMP WHERE da.id = :assignmentId")
    int deactivateDCMAssignment(@Param("assignmentId") UUID assignmentId);
    
    // Count active DCMs in a department
    @Query("SELECT COUNT(da) FROM DCMAssignment da WHERE da.department = :department AND da.academicYear = :academicYear AND da.isActive = true")
    long countActiveDCMsByDepartmentAndYear(@Param("department") Department department, @Param("academicYear") String academicYear);
    
    // Check if staff member can be assigned as DCM (not already a DCM, not HOD, etc.)
    @Query("SELECT COUNT(da) = 0 FROM DCMAssignment da WHERE da.staffMember = :staffMember AND da.academicYear = :academicYear AND da.isActive = true")
    boolean canStaffBeAssignedAsDCM(@Param("staffMember") User staffMember, @Param("academicYear") String academicYear);
    
    // Get DCM assignment history for a staff member
    @Query("SELECT da FROM DCMAssignment da WHERE da.staffMember = :staffMember ORDER BY da.assignedAt DESC")
    List<DCMAssignment> findDCMAssignmentHistory(@Param("staffMember") User staffMember);
    
    // Find all active DCM assignments across all departments for current year
    @Query("SELECT da FROM DCMAssignment da WHERE da.academicYear = :academicYear AND da.isActive = true")
    List<DCMAssignment> findAllActiveDCMsForYear(@Param("academicYear") String academicYear);
} 