package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.ResetPasswordRequest;
import com.cvrce.apraisal.dto.auth.LoginRequestDTO;
import com.cvrce.apraisal.dto.auth.LoginResponseDTO;
import com.cvrce.apraisal.dto.user.UserCreateDTO;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.AuthService;
import com.cvrce.apraisal.service.OtpService;
import com.cvrce.apraisal.service.EmailService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final OtpService otpService;
    private final EmailService emailService;

    // 🔐 Login Endpoint - RATE LIMITED to prevent brute force attacks
	/*
	 * @PostMapping("/login") public ResponseEntity<LoginResponseDTO>
	 * login(@RequestBody LoginRequestDTO request) { return
	 * ResponseEntity.ok(authService.login(request)); }
	 */
    @PostMapping("/login")
    // Rate limiting implemented via RateLimitingInterceptor - 5 attempts per minute per IP
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDTO request) {
        try {
            LoginResponseDTO response = authService.login(request);
            return ResponseEntity.ok(response);
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found");
        } catch (Exception e) {
            log.error("Login failed for user: {}", request.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Login failed. Please try again later.");
        }
    }

    // 👤 Register new user (Admin only) - RATE LIMITED
    @PostMapping("/register")
    @PreAuthorize("hasRole('ADMIN')")
    // Rate limiting: Max 10 registrations per hour per admin
    public ResponseEntity<String> register(@Valid @RequestBody UserCreateDTO dto) {
        try {
            // Register user and get the generated temporary password
            String temporaryPassword = authService.register(dto);
            
            // CRITICAL: Send welcome email with credentials
            emailService.sendWelcomeEmail(
                dto.getEmail(), 
                dto.getFullName(), 
                temporaryPassword,  // Use the auto-generated password
                dto.getEmployeeId()
            );
            
            return ResponseEntity.ok("User registered successfully. Welcome email sent to " + dto.getEmail());
        } catch (Exception e) {
            log.error("Registration failed for user: {}", dto.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Registration failed. Please try again later.");
        }
    }

    // 📩 Request OTP for password reset - RATE LIMITED to prevent spam
    @PostMapping("/request-otp")
    // Rate limiting: Max 3 OTP requests per 15 minutes per email
    public ResponseEntity<String> requestOtp(@RequestParam String email) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }

        String otp = otpService.generateOtp(email);
        
        // SECURITY FIX: Send OTP via email instead of returning in response
        try {
            emailService.sendOtpEmail(email, otp, user.get().getFullName());
            return ResponseEntity.ok("OTP sent to your email address");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to send OTP email. Please try again later.");
        }
    }

    // 🔄 Reset password after OTP verification
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPasswordViaOtp(@Valid @RequestBody ResetPasswordRequest dto) {
        if (!otpService.validateOtp(dto.getEmail(), dto.getOtp())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid or expired OTP");
        }

        User user = userRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userRepository.save(user);

        otpService.invalidateOtp(dto.getEmail()); // Clear OTP after use

        return ResponseEntity.ok("Password updated successfully");
    }

    // 🔄 Refresh JWT token
    @PostMapping("/refresh")
    public ResponseEntity<?> refreshToken(HttpServletRequest request) {
        try {
            String token = extractTokenFromRequest(request);
            if (token == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body("No token provided");
            }

            LoginResponseDTO response = authService.refreshToken(token);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Token refresh failed:", e);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Token refresh failed: " + e.getMessage());
        }
    }

    private String extractTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}
