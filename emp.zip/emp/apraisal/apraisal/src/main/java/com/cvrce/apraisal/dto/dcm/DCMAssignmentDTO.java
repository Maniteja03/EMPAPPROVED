package com.cvrce.apraisal.dto.dcm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DCMAssignmentDTO {
    
    private UUID assignmentId;
    private UUID staffMemberId;
    private String staffFullName;
    private String staffEmail;
    private String staffEmployeeId;
    private String departmentName;
    private String academicYear;
    private boolean isActive;
    private LocalDateTime assignedAt;
    private LocalDateTime deactivatedAt;
    private UUID assignedByHodId;
    private String assignedByHodName;
    
    // Statistics
    private int formsReviewed;
    private int formsApproved;
    private int formsRejected;
    private double approvalRate;
    
    // Status information
    private String status; // "ACTIVE", "INACTIVE", "PENDING"
    private int currentWorkload; // Number of forms currently assigned for review
    
    // Helper methods
    public boolean isCurrentlyActive() {
        return isActive && deactivatedAt == null;
    }
    
    public String getDisplayInfo() {
        return staffFullName + " (" + staffEmployeeId + ") - " + 
               (isCurrentlyActive() ? "Active DCM" : "Inactive");
    }
    
    public String getWorkloadInfo() {
        return "Reviewed: " + formsReviewed + ", Current: " + currentWorkload;
    }
} 