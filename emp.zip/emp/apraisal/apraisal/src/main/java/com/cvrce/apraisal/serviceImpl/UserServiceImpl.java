package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.user.*;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserResponseDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return mapToDTO(user);
    }

    @Override
    public UserResponseDTO getUserById(UUID id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return mapToDTO(user);
    }

    @Override
    public List<UserResponseDTO> getUsersByDepartment(Long deptId) {
        return userRepository.findByDepartmentId(deptId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Page<UserResponseDTO> getUsersByDepartment(Long deptId, Pageable pageable) {
        List<User> allUsers = userRepository.findByDepartmentId(deptId);
        List<UserResponseDTO> dtoList = allUsers.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Apply sorting and pagination manually
        dtoList = applySorting(dtoList, pageable);
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<UserResponseDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    public Page<UserResponseDTO> getAllUsers(Pageable pageable, String search, Long departmentId, Boolean enabled) {
        Page<User> userPage;
        
        // Use efficient database queries based on filters
        if (search != null) {
            userPage = userRepository.searchUsers(search, pageable);
        } else if (departmentId != null) {
            userPage = userRepository.findByDepartmentId(departmentId, pageable);
        } else {
            userPage = userRepository.findAllActive(pageable);
        }
        
        // Apply remaining filters if needed (for complex combinations)
        List<User> filteredUsers = userPage.getContent();
        if (enabled != null) {
            filteredUsers = filteredUsers.stream()
                    .filter(user -> user.isEnabled() == enabled)
                    .collect(Collectors.toList());
        }
        
        List<UserResponseDTO> dtoList = filteredUsers.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return new PageImpl<>(dtoList, pageable, userPage.getTotalElements());
    }

    @Override
    public Page<UserResponseDTO> searchUsers(String query, Pageable pageable) {
        // Use efficient database query instead of loading all users
        Page<User> userPage = userRepository.searchUsers(query, pageable);
        
        List<UserResponseDTO> dtoList = userPage.getContent().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return new PageImpl<>(dtoList, pageable, userPage.getTotalElements());
    }

    @Override
    public Page<UserResponseDTO> getUsersByRole(String roleName, Pageable pageable) {
        // Use efficient database query instead of loading all users
        Page<User> userPage = userRepository.findByRoleName(roleName, pageable);
        
        List<UserResponseDTO> dtoList = userPage.getContent().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return new PageImpl<>(dtoList, pageable, userPage.getTotalElements());
    }

    private List<UserResponseDTO> applySorting(List<UserResponseDTO> list, Pageable pageable) {
        if (pageable.getSort().isSorted()) {
            pageable.getSort().forEach(order -> {
                String property = order.getProperty();
                boolean ascending = order.isAscending();
                
                list.sort((a, b) -> {
                    int comparison = 0;
                    switch (property) {
                        case "fullName":
                            comparison = a.getFullName().compareTo(b.getFullName());
                            break;
                        case "email":
                            comparison = a.getEmail().compareTo(b.getEmail());
                            break;
                        case "employeeId":
                            comparison = a.getEmployeeId().compareTo(b.getEmployeeId());
                            break;
                        case "dateOfJoining":
                            comparison = a.getDateOfJoining().compareTo(b.getDateOfJoining());
                            break;
                        default:
                            comparison = 0;
                    }
                    return ascending ? comparison : -comparison;
                });
            });
        }
        return list;
    }

    @Override
    public boolean isUserAllowedToViewProfile(UUID userId, String currentUserEmail) {
        try {
            // Get current user
            User currentUser = userRepository.findByEmail(currentUserEmail)
                    .orElse(null);
            
            if (currentUser == null) {
                return false;
            }
            
            // ADMIN and HOD can view any profile
            boolean isAdminOrHod = currentUser.getRoles().stream()
                    .anyMatch(role -> "ADMIN".equals(role.getName()) || "HOD".equals(role.getName()));
            
            if (isAdminOrHod) {
                return true;
            }
            
            // Users can view their own profile
            return currentUser.getId().equals(userId);
            
        } catch (Exception e) {
            log.error("Error checking profile access for user {} by {}", userId, currentUserEmail, e);
            return false;
        }
    }

    @Override
    public boolean isCurrentUser(UUID userId, String currentUserEmail) {
        try {
            User currentUser = userRepository.findByEmail(currentUserEmail)
                    .orElse(null);
            
            if (currentUser == null) {
                return false;
            }
            
            return currentUser.getId().equals(userId);
            
        } catch (Exception e) {
            log.error("Error checking current user {} by {}", userId, currentUserEmail, e);
            return false;
        }
    }

    @Override
    public User getCurrentUser() {
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current user not found"));
    }

    @Override
    public User updateCurrentUser(UserUpdateDTO updateData) {
        User currentUser = getCurrentUser();
        
        if (updateData.getFullName() != null) {
            currentUser.setFullName(updateData.getFullName());
        }
        if (updateData.getDepartmentId() != null) {
            Department dept = departmentRepository.findById(updateData.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
            currentUser.setDepartment(dept);
        }
        if (updateData.getDateOfJoining() != null) {
            currentUser.setDateOfJoining(updateData.getDateOfJoining());
        }
        if (updateData.getLastPromotionDate() != null) {
            currentUser.setLastPromotionDate(updateData.getLastPromotionDate());
        }
        
        return userRepository.save(currentUser);
    }

    @Override
    public String updateProfilePicture(MultipartFile file) {
        User currentUser = getCurrentUser();
        
        // Placeholder implementation - integrate with file storage service
        String profilePictureUrl = "/uploads/profiles/" + currentUser.getId() + "_" + file.getOriginalFilename();
        
        // In real implementation, save file to storage and update user profile
        log.info("Profile picture updated for user: {}", currentUser.getEmail());
        
        return profilePictureUrl;
    }

    @Override
    public UserResponseDTO convertToResponseDTO(User user) {
        return mapToDTO(user);
    }

    @Override
    public UserResponseDTO createUser(UserCreateDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }

        Department dept = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Invalid department"));

        Set<Role> roles = dto.getRoles().stream()
            .map(name -> roleRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid role: " + name)))
            .collect(Collectors.toSet());

        User user = User.builder()
                .email(dto.getEmail())
                .employeeId(dto.getEmployeeId())
                .password(passwordEncoder.encode(dto.getPassword()))
                .fullName(dto.getFullName())
                .department(dept)
                .enabled(true)
                .deleted(false)
                .dateOfJoining(dto.getDateOfJoining())
                .lastPromotionDate(dto.getLastPromotionDate())
                .roles(roles) 
                .build();

        return mapToDTO(userRepository.save(user));
    }

    @Override
    public UserResponseDTO updateUser(UUID id, UserUpdateDTO dto) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (dto.getFullName() != null) {
            user.setFullName(dto.getFullName());
        }

        if (dto.getDepartmentId() != null) {
            Department dept = departmentRepository.findById(dto.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Invalid department"));
            user.setDepartment(dept);
        }

        if (dto.getDateOfJoining() != null) {
            user.setDateOfJoining(dto.getDateOfJoining());
        }

        if (dto.getLastPromotionDate() != null) {
            user.setLastPromotionDate(dto.getLastPromotionDate());
        }

        return mapToDTO(userRepository.save(user));
    }

    @Override
    public void setUserEnabled(UUID userId, boolean enabled) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setEnabled(enabled);
        userRepository.save(user);
    }

    @Override
    public void softDeleteUser(UUID id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setDeleted(true);
        user.setEnabled(false);
        userRepository.save(user);
    }

    private UserResponseDTO mapToDTO(User user) {
        Set<String> roleNames = user.getRoles().stream()
                .map(role -> role.getName())
                .collect(Collectors.toSet());

        return UserResponseDTO.builder()
                .id(user.getId())
                .employeeId(user.getEmployeeId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .dateOfJoining(user.getDateOfJoining())
                .lastPromotionDate(user.getLastPromotionDate())
                .enabled(user.isEnabled())
                .deleted(user.isDeleted())
                .departmentId(user.getDepartment() != null ? user.getDepartment().getId() : null)
                .roles(roleNames)
                .build();
    }
}
