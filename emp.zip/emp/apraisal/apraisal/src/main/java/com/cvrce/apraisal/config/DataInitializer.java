package com.cvrce.apraisal.config;

import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.RoleRepository;
import com.cvrce.apraisal.repo.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Collections;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        log.info("🚀 Starting database initialization...");
        
        try {
            createRolesIfNotExist();
            createDepartmentsIfNotExist();
            createAdminIfNotExist();
            log.info("✅ Database initialization completed successfully!");
        } catch (Exception e) {
            log.error("❌ Database initialization failed: {}", e.getMessage(), e);
        }
    }

    private void createRolesIfNotExist() {
        String[] roleNames = {"ADMIN", "STAFF", "DCM", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL"};
        
        for (String roleName : roleNames) {
            if (!roleRepository.existsByName(roleName)) {
                Role role = Role.builder()
                        .name(roleName)
                        .build();
                roleRepository.save(role);
                log.info("✅ Created role: {}", roleName);
            }
        }
    }

    private void createDepartmentsIfNotExist() {
        String[] departments = {
            "Computer Science Engineering",
            "Mechanical Engineering", 
            "Electrical Engineering",
            "Civil Engineering",
            "Electronics and Communication",
            "Information Science",
            "Administration",
            "Management"
        };
        
        for (String deptName : departments) {
            if (!departmentRepository.existsByName(deptName)) {
                Department department = Department.builder()
                        .name(deptName)
                        .build();
                departmentRepository.save(department);
                log.info("✅ Created department: {}", deptName);
            }
        }
    }

    private void createAdminIfNotExist() {
        String adminEmail = "manitej03@gmail.com";
        String adminPassword = "Maniteja12345";
        
        if (!userRepository.existsByEmail(adminEmail)) {
            // Get Admin role and Administration department
            Role adminRole = roleRepository.findByName("ADMIN")
                    .orElseThrow(() -> new RuntimeException("Admin role not found"));
            
            Department adminDept = departmentRepository.findByName("Administration")
                    .orElseThrow(() -> new RuntimeException("Administration department not found"));
            
            // Create Admin user with hardcoded credentials
            User admin = User.builder()
                    .id(UUID.randomUUID())
                    .employeeId("ADMIN001")
                    .fullName("System Administrator")
                    .email(adminEmail)
                    .password(passwordEncoder.encode(adminPassword))
                    .enabled(true)
                    .deleted(false)
                    .dateOfJoining(LocalDate.now())
                    .department(adminDept)
                    .roles(Collections.singleton(adminRole))
                    .build();
            
            userRepository.save(admin);
            
            log.info("🎯 ADMIN CREATED SUCCESSFULLY!");
            log.info("📧 Email: {}", adminEmail);
            log.info("✅ Admin account is ready for use!");
            
        } else {
            log.info("ℹ️  Admin already exists. Skipping creation.");
        }
    }
} 