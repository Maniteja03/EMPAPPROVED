package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.TeachingPerformanceScoring;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Repository
public interface TeachingPerformanceScoringRepository extends JpaRepository<TeachingPerformanceScoring, UUID> {
    
    List<TeachingPerformanceScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT tps FROM TeachingPerformanceScoring tps WHERE tps.appraisalScoring.id = :scoringId ORDER BY tps.academicYear DESC, tps.semester")
    List<TeachingPerformanceScoring> findByAppraisalScoringIdOrderBySemester(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT tps FROM TeachingPerformanceScoring tps WHERE tps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<TeachingPerformanceScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT tps FROM TeachingPerformanceScoring tps WHERE tps.isExternalExamination = true")
    List<TeachingPerformanceScoring> findExternalExaminationSubjects();
    
    @Query("SELECT AVG(tps.passPercentage) FROM TeachingPerformanceScoring tps WHERE tps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    BigDecimal getAveragePassPercentageByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT tps FROM TeachingPerformanceScoring tps WHERE tps.passPercentage >= :threshold")
    List<TeachingPerformanceScoring> findByPassPercentageGreaterThan(@Param("threshold") BigDecimal threshold);
} 