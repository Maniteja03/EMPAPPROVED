package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.RoleRepository;
import com.cvrce.apraisal.repo.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/init")
@RequiredArgsConstructor
@Slf4j
public class InitializationController {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Value("${app.initialization.enabled:true}")
    private boolean initializationEnabled;

    /**
     * POST /api/init/create-admin
     * Creates the initial admin user for the system
     * This is a one-time initialization endpoint
     * 
     * @param request Contains admin credentials
     * @return Success/failure response
     */
    @PostMapping("/create-admin")
    public ResponseEntity<?> createAdmin(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String password = request.get("password");
            String fullName = request.get("fullName");
            
            if (email == null || password == null || fullName == null) {
                return ResponseEntity.badRequest()
                        .body("Missing required fields: email, password, fullName");
            }
            
            // Check if admin already exists
            if (userRepository.existsByEmail(email)) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Admin user already exists");
            }
            
            // Get Admin role
            Role adminRole = roleRepository.findByName("ADMIN")
                    .orElseThrow(() -> new RuntimeException("Admin role not found"));
            
            // Get Administration department
            Department adminDept = departmentRepository.findByName("Administration")
                    .orElse(null);
            
            if (adminDept == null) {
                // Create Administration department if it doesn't exist
                adminDept = Department.builder()
                        .name("Administration")
                        .build();
                adminDept = departmentRepository.save(adminDept);
            }
            
            // Create Admin user
            User admin = User.builder()
                    .id(UUID.randomUUID())
                    .employeeId("ADMIN001")
                    .fullName(fullName)
                    .email(email)
                    .password(passwordEncoder.encode(password))
                    .enabled(true)
                    .deleted(false)
                    .dateOfJoining(LocalDate.now())
                    .department(adminDept)
                    .roles(Collections.singleton(adminRole))
                    .build();
            
            userRepository.save(admin);
            
            return ResponseEntity.ok()
                    .body("Admin user created successfully");
            
        } catch (Exception e) {
            log.error("Failed to create admin user: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create admin user: " + e.getMessage());
        }
    }
    
    /**
     * Check initialization status
     */
    @GetMapping("/status")
    public ResponseEntity<?> getInitializationStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("initializationEnabled", initializationEnabled);
        status.put("adminExists", userRepository.existsByEmail("admin@college.edu"));
        status.put("rolesCount", roleRepository.count());
        status.put("departmentsCount", departmentRepository.count());
        status.put("usersCount", userRepository.count());
        
        return ResponseEntity.ok(status);
    }
    
    private void initializeRolesAndDepartments() {
        // Create roles if not exist
        String[] roleNames = {"ADMIN", "STAFF", "DCM", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL"};
        for (String roleName : roleNames) {
            if (!roleRepository.existsByName(roleName)) {
                roleRepository.save(Role.builder().name(roleName).build());
            }
        }
        
        // Create departments if not exist
        String[] departments = {
            "Computer Science Engineering",
            "Administration"
        };
        for (String deptName : departments) {
            if (!departmentRepository.existsByName(deptName)) {
                departmentRepository.save(Department.builder()
                        .name(deptName).build());
            }
        }
    }
} 