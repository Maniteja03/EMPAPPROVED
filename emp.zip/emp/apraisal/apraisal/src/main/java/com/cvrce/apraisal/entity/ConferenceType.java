package com.cvrce.apraisal.entity;

public enum ConferenceType {
    INTERNATIONAL_CONFERENCE("International Conference"),
    FDP_WORKSHOP_STTP("FDP/Workshop/STTP/Skill Development"),
    NPTEL_SWAYAM("NPTEL/SWAYAM Course");
    
    private final String displayName;
    
    ConferenceType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() { return displayName; }
} 