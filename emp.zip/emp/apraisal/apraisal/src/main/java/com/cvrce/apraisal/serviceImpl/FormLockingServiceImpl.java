package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.entity.FormLock;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.repo.FormLockRepository;
import com.cvrce.apraisal.service.FormLockingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class FormLockingServiceImpl implements FormLockingService {
    
    private final FormLockRepository formLockRepository;
    
    @Override
    @Transactional
    public Optional<FormLock> lockForm(UUID formId, User reviewer, ReviewLevel reviewLevel) {
        LocalDateTime now = LocalDateTime.now();
        
        // Check if form is already locked by someone else
        Optional<FormLock> existingLock = formLockRepository.findActiveLockByFormId(formId, now);
        if (existingLock.isPresent()) {
            FormLock lock = existingLock.get();
            
            // If locked by same reviewer, extend the lock
            if (lock.belongsTo(reviewer)) {
                lock.setExpiresAt(now.plusMinutes(30));
                FormLock savedLock = formLockRepository.save(lock);
                log.info("Extended existing lock for form {} by reviewer {} ({})", 
                        formId, reviewer.getFullName(), reviewer.getId());
                return Optional.of(savedLock);
            } else {
                // Form is locked by someone else
                log.warn("Form {} is already locked by {} until {}", 
                        formId, lock.getReviewer().getFullName(), lock.getExpiresAt());
                return Optional.empty();
            }
        }
        
        // Create new lock
        FormLock newLock = FormLock.createLock(formId, reviewer, reviewLevel);
        FormLock savedLock = formLockRepository.save(newLock);
        
        log.info("Created new lock for form {} by reviewer {} ({}) at level {}, expires at {}", 
                formId, reviewer.getFullName(), reviewer.getId(), reviewLevel, savedLock.getExpiresAt());
        
        return Optional.of(savedLock);
    }
    
    @Override
    @Transactional
    public boolean unlockForm(UUID formId, User reviewer) {
        LocalDateTime now = LocalDateTime.now();
        
        Optional<FormLock> lockOpt = formLockRepository.findActiveLockByFormId(formId, now);
        if (lockOpt.isEmpty()) {
            log.warn("No active lock found for form {} by reviewer {}", formId, reviewer.getFullName());
            return false;
        }
        
        FormLock lock = lockOpt.get();
        if (!lock.belongsTo(reviewer)) {
            log.warn("Cannot unlock form {} - locked by different reviewer {} vs requesting reviewer {}", 
                    formId, lock.getReviewer().getFullName(), reviewer.getFullName());
            return false;
        }
        
        // Deactivate the lock
        int updated = formLockRepository.deactivateLock(lock.getId());
        if (updated > 0) {
            log.info("Successfully unlocked form {} by reviewer {} ({})", 
                    formId, reviewer.getFullName(), reviewer.getId());
            return true;
        } else {
            log.error("Failed to deactivate lock for form {} by reviewer {}", formId, reviewer.getFullName());
            return false;
        }
    }
    
    @Override
    public boolean isFormLocked(UUID formId) {
        LocalDateTime now = LocalDateTime.now();
        return formLockRepository.isFormLocked(formId, now);
    }
    
    @Override
    public boolean isFormLockedByReviewer(UUID formId, User reviewer) {
        LocalDateTime now = LocalDateTime.now();
        return formLockRepository.isFormLockedByReviewer(formId, reviewer, now);
    }
    
    @Override
    public Optional<FormLock> getCurrentLock(UUID formId) {
        LocalDateTime now = LocalDateTime.now();
        return formLockRepository.findActiveLockByFormId(formId, now);
    }
    
    @Override
    public List<FormLock> getActiveLocksByReviewer(User reviewer) {
        LocalDateTime now = LocalDateTime.now();
        return formLockRepository.findActiveLocksByReviewer(reviewer, now);
    }
    
    @Override
    @Transactional
    @Scheduled(fixedRate = 300000) // Run every 5 minutes
    public int cleanupExpiredLocks() {
        LocalDateTime now = LocalDateTime.now();
        int cleanedUp = formLockRepository.deactivateExpiredLocks(now);
        
        if (cleanedUp > 0) {
            log.info("Cleaned up {} expired form locks", cleanedUp);
        }
        
        return cleanedUp;
    }
    
    @Override
    @Transactional
    public boolean extendLock(UUID formId, User reviewer, int additionalMinutes) {
        LocalDateTime now = LocalDateTime.now();
        
        Optional<FormLock> lockOpt = formLockRepository.findActiveLockByFormId(formId, now);
        if (lockOpt.isEmpty()) {
            log.warn("No active lock found to extend for form {} by reviewer {}", formId, reviewer.getFullName());
            return false;
        }
        
        FormLock lock = lockOpt.get();
        if (!lock.belongsTo(reviewer)) {
            log.warn("Cannot extend lock for form {} - belongs to different reviewer", formId);
            return false;
        }
        
        // Extend the lock
        lock.setExpiresAt(lock.getExpiresAt().plusMinutes(additionalMinutes));
        formLockRepository.save(lock);
        
        log.info("Extended lock for form {} by {} minutes, new expiry: {}", 
                formId, additionalMinutes, lock.getExpiresAt());
        
        return true;
    }
    
    @Override
    @Transactional
    public boolean forceUnlock(UUID formId) {
        LocalDateTime now = LocalDateTime.now();
        
        Optional<FormLock> lockOpt = formLockRepository.findActiveLockByFormId(formId, now);
        if (lockOpt.isEmpty()) {
            log.warn("No active lock found to force unlock for form {}", formId);
            return false;
        }
        
        FormLock lock = lockOpt.get();
        int updated = formLockRepository.deactivateLock(lock.getId());
        
        if (updated > 0) {
            log.warn("FORCE UNLOCKED form {} - was locked by reviewer {} ({})", 
                    formId, lock.getReviewer().getFullName(), lock.getReviewer().getId());
            return true;
        } else {
            log.error("Failed to force unlock form {}", formId);
            return false;
        }
    }
    
    @Override
    public long getReviewerWorkload(User reviewer) {
        LocalDateTime now = LocalDateTime.now();
        return formLockRepository.getReviewerWorkload(reviewer, now);
    }
    
    @Override
    public boolean canReviewerTakeMoreWork(User reviewer, int maxWorkload) {
        long currentWorkload = getReviewerWorkload(reviewer);
        return currentWorkload < maxWorkload;
    }
} 