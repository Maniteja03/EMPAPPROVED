package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.NotificationDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Async service for handling peak load operations during busy periods
 * Processes heavy operations in background to maintain system responsiveness
 */
public interface AsyncAppraisalService {
    
    /**
     * Async form submission processing for peak periods
     * Handles: validation, scoring, auto-assignment, notifications
     */
    CompletableFuture<Void> processFormSubmissionAsync(UUID formId, String userEmail);
    
    /**
     * Async auto-assignment processing
     * Handles: DCM assignment, committee assignment, load balancing
     */
    CompletableFuture<Void> processAutoAssignmentAsync(UUID formId, String assignmentType);
    
    /**
     * Async notification processing
     * Handles: bulk email sending, system notifications
     */
    CompletableFuture<Void> processNotificationsAsync(List<NotificationDTO> notifications);
    
    /**
     * Async file processing
     * Handles: file uploads to S3, PDF generation, document processing
     */
    CompletableFuture<String> processFileUploadAsync(byte[] fileData, String fileName, UUID formId);
    
    /**
     * Async dashboard calculations for analytics
     * Handles: complex statistics, reports, department analytics
     */
    CompletableFuture<Void> updateDashboardCacheAsync(String userEmail, String role);
    
    /**
     * Async deadline reminder processing
     * Handles: bulk reminder calculations and sending
     */
    CompletableFuture<Void> processDeadlineRemindersAsync(String academicYear);
    
    /**
     * Async scoring recalculation for multiple forms
     * Handles: bulk scoring updates, designation changes
     */
    CompletableFuture<Void> recalculateScoresAsync(List<UUID> formIds);
    
    /**
     * Async audit log processing
     * Handles: bulk audit entries, security logs
     */
    CompletableFuture<Void> processAuditLogsAsync(List<String> auditEntries);
} 