package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.committee.CommitteeAssignmentDTO;
import com.cvrce.apraisal.dto.FormAssignmentStats;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.FormAssignment;
import com.cvrce.apraisal.entity.CommitteeAssignment;
import com.cvrce.apraisal.entity.DCMAssignment;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.service.FormAssignmentService;
import com.cvrce.apraisal.service.CommitteeManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class FormAssignmentServiceImpl implements FormAssignmentService {
    
    private final AppraisalFormRepository appraisalFormRepository;
    private final CommitteeAssignmentRepository committeeAssignmentRepository;
    private final FormAssignmentRepository formAssignmentRepository;
    private final DCMAssignmentRepository dcmAssignmentRepository;
    private final CommitteeManagementService committeeManagementService;
    
    @Override
    public CommitteeAssignmentDTO autoAssignToCommitteeMember(AppraisalForm form) {
        String excludeDepartment = form.getUser().getDepartment().getName();
        String academicYear = form.getAcademicYear();
        
        log.info("Auto-assigning committee member for form {} from {} department", 
                form.getId(), excludeDepartment);
        
        // Get available committee member
        CommitteeAssignmentDTO availableMember = committeeManagementService
                .getAvailableCommitteeMemberForAssignment(academicYear, excludeDepartment);
        
        if (availableMember == null) {
            log.warn("No available committee members for form {} from {} department", 
                    form.getId(), excludeDepartment);
            return null;
        }
        
        // Create form assignment
        CommitteeAssignment committeeAssignment = committeeAssignmentRepository
                .findById(availableMember.getAssignmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Committee assignment not found"));
        
        FormAssignment assignment = FormAssignment.builder()
                .appraisalForm(form)
                .assignedReviewer(committeeAssignment.getCommitteeMember())
                .committeeAssignment(committeeAssignment)
                .assignmentType("COMMITTEE_REVIEW")
                .isActive(true)
                .build();
        
        formAssignmentRepository.save(assignment);
        
        // Update committee member workload
        committeeManagementService.assignFormToCommitteeMember(
                availableMember.getAssignmentId(), form.getId());
        
        log.info("Assigned form {} to committee member {} ({})", 
                form.getId(), availableMember.getMemberFullName(), 
                availableMember.getMemberDepartmentName());
        
        return availableMember;
    }
    
    @Override
    @Transactional
    public boolean assignToSpecificCommitteeMember(UUID formId, UUID committeeAssignmentId) {
        AppraisalForm form = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found: " + formId));
        
        CommitteeAssignment committeeAssignment = committeeAssignmentRepository
                .findById(committeeAssignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Committee assignment not found"));
        
        // Check if committee member is from different department
        String formDepartment = form.getUser().getDepartment().getName();
        String memberDepartment = committeeAssignment.getCommitteeMember().getDepartment().getName();
        
        if (formDepartment.equals(memberDepartment)) {
            log.warn("Cannot assign form {} to committee member from same department ({})", 
                    formId, formDepartment);
            return false;
        }
        
        // Deactivate any existing assignments for this form
        formAssignmentRepository.deactivateAssignmentsByFormId(formId);
        
        // Create new assignment
        FormAssignment assignment = FormAssignment.builder()
                .appraisalForm(form)
                .assignedReviewer(committeeAssignment.getCommitteeMember())
                .committeeAssignment(committeeAssignment)
                .assignmentType("COMMITTEE_REVIEW")
                .isActive(true)
                .build();
        
        formAssignmentRepository.save(assignment);
        
        // Update workload
        committeeManagementService.assignFormToCommitteeMember(committeeAssignmentId, formId);
        
        log.info("Manually assigned form {} to committee member {} from {} department", 
                formId, committeeAssignment.getCommitteeMember().getFullName(), memberDepartment);
        
        return true;
    }
    
    @Override
    public CommitteeAssignmentDTO reassignToSameCommitteeMember(AppraisalForm form) {
        // Find previous assignment for this form
        Optional<FormAssignment> previousAssignment = formAssignmentRepository
                .findActiveAssignmentByFormId(form.getId());
        
        if (previousAssignment.isEmpty()) {
            log.warn("No previous assignment found for form {} - using auto-assignment", form.getId());
            return autoAssignToCommitteeMember(form);
        }
        
        FormAssignment prevAssignment = previousAssignment.get();
        if (prevAssignment.getCommitteeAssignment() == null) {
            log.warn("Previous assignment was not a committee assignment for form {}", form.getId());
            return autoAssignToCommitteeMember(form);
        }
        
        // Reassign to same committee member
        CommitteeAssignment sameCommitteeMember = prevAssignment.getCommitteeAssignment();
        
        // Create new assignment (reactivate)
        FormAssignment newAssignment = FormAssignment.builder()
                .appraisalForm(form)
                .assignedReviewer(sameCommitteeMember.getCommitteeMember())
                .committeeAssignment(sameCommitteeMember)
                .assignmentType("COMMITTEE_REVIEW")
                .notes("Reassigned after HOD update")
                .isActive(true)
                .build();
        
        formAssignmentRepository.save(newAssignment);
        
        // Update workload
        committeeManagementService.assignFormToCommitteeMember(
                sameCommitteeMember.getId(), form.getId());
        
        log.info("Reassigned form {} to same committee member {} after HOD update", 
                form.getId(), sameCommitteeMember.getCommitteeMember().getFullName());
        
        return createCommitteeAssignmentDTO(sameCommitteeMember);
    }
    
    @Override
    @Transactional
    public void releaseFormAssignment(UUID formId, UUID committeeAssignmentId) {
        // Find and deactivate assignment
        Optional<FormAssignment> assignment = formAssignmentRepository
                .findActiveAssignmentByFormId(formId);
        
        if (assignment.isPresent()) {
            FormAssignment fa = assignment.get();
            fa.setActive(false);
            fa.setCompletedAt(LocalDateTime.now());
            formAssignmentRepository.save(fa);
            
            // Update committee member workload
            committeeManagementService.completeFormReviewByCommitteeMember(
                    committeeAssignmentId, formId);
            
            log.info("Released form assignment for form {} from committee member {}", 
                    formId, committeeAssignmentId);
        }
    }
    
    @Override
    public CommitteeAssignmentDTO getAssignedCommitteeMember(UUID formId) {
        Optional<FormAssignment> assignment = formAssignmentRepository
                .findActiveAssignmentByFormId(formId);
        
        if (assignment.isEmpty() || assignment.get().getCommitteeAssignment() == null) {
            return null;
        }
        
        CommitteeAssignment committeeAssignment = assignment.get().getCommitteeAssignment();
        return createCommitteeAssignmentDTO(committeeAssignment);
    }
    
    @Override
    @Transactional
    public void handleFormStatusChange(UUID formId, String newStatus) {
        AppraisalForm form = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found: " + formId));
        
        AppraisalStatus status = AppraisalStatus.valueOf(newStatus);
        
        switch (status) {
            case DEPARTMENT_REVIEW -> {
                // Auto-assign to DCM with load balancing
                User assignedDCM = autoAssignToDCM(form);
                if (assignedDCM == null) {
                    log.error("Failed to auto-assign form {} to DCM", formId);
                }
            }
            case HOD_APPROVED -> {
                // Auto-assign to committee member
                CommitteeAssignmentDTO assigned = autoAssignToCommitteeMember(form);
                if (assigned == null) {
                    log.error("Failed to auto-assign form {} to committee member", formId);
                }
            }
            case HOD_UPDATED -> {
                // Reassign to same committee member who originally reviewed it
                CommitteeAssignmentDTO reassigned = reassignToSameCommitteeMember(form);
                if (reassigned == null) {
                    log.error("Failed to reassign form {} to same committee member", formId);
                }
            }
            default -> {
                // No assignment needed for other statuses
                log.debug("No assignment action needed for form {} with status {}", formId, newStatus);
            }
        }
    }
    
    @Override
    public FormAssignmentStats getAssignmentStats(String academicYear) {
        FormAssignmentStats stats = new FormAssignmentStats();
        stats.setAcademicYear(academicYear);
        
        // Get forms awaiting assignment (HOD_APPROVED status)
        List<AppraisalForm> awaitingAssignment = appraisalFormRepository
                .findByStatus(AppraisalStatus.HOD_APPROVED);
        
        if (academicYear != null) {
            awaitingAssignment = awaitingAssignment.stream()
                    .filter(form -> academicYear.equals(form.getAcademicYear()))
                    .toList();
        }
        
        stats.setTotalFormsAwaitingAssignment(awaitingAssignment.size());
        stats.setTotalFormsAssigned((int) formAssignmentRepository.countActiveCommitteeAssignments());
        
        // Get committee member stats
        List<CommitteeAssignment> activeMembers = committeeAssignmentRepository
                .findActiveCommitteeMembersForYear(academicYear != null ? academicYear : "2023-24");
        
        stats.setTotalAvailableCommitteeMembers(activeMembers.size());
        
        if (!activeMembers.isEmpty()) {
            double totalWorkload = activeMembers.stream()
                    .mapToInt(CommitteeAssignment::getWorkloadCount)
                    .sum();
            stats.setAverageWorkloadPerMember(totalWorkload / activeMembers.size());
            
            // Find busiest and least busy members
            CommitteeAssignment busiest = activeMembers.stream()
                    .max((a, b) -> Integer.compare(a.getWorkloadCount(), b.getWorkloadCount()))
                    .orElse(null);
            CommitteeAssignment leastBusy = activeMembers.stream()
                    .min((a, b) -> Integer.compare(a.getWorkloadCount(), b.getWorkloadCount()))
                    .orElse(null);
            
            if (busiest != null) {
                stats.setMostBusyCommitteeMember(busiest.getCommitteeMember().getFullName());
            }
            if (leastBusy != null) {
                stats.setLeastBusyCommitteeMember(leastBusy.getCommitteeMember().getFullName());
            }
        }
        
        return stats;
    }
    
    private CommitteeAssignmentDTO createCommitteeAssignmentDTO(CommitteeAssignment assignment) {
        return CommitteeAssignmentDTO.builder()
                .assignmentId(assignment.getId())
                .memberFullName(assignment.getCommitteeMember().getFullName())
                .memberEmail(assignment.getCommitteeMember().getEmail())
                .memberDepartmentName(assignment.getDepartment().getName())
                .academicYear(assignment.getAcademicYear())
                .currentWorkload(assignment.getWorkloadCount())
                .completedReviews(assignment.getCompletedReviews())
                .maxWorkloadCapacity(15) // Default max capacity
                .isActive(assignment.getIsActive())
                .assignedAt(assignment.getAssignedAt())
                .build();
    }
    
    /**
     * CRITICAL FIX: Auto-assign form to DCM with load balancing
     */
    private User autoAssignToDCM(AppraisalForm form) {
        String departmentName = form.getUser().getDepartment().getName();
        String academicYear = form.getAcademicYear();
        
        log.info("Auto-assigning DCM for form {} from {} department", 
                form.getId(), departmentName);
        
        // Get active DCMs from the same department
        List<DCMAssignment> departmentDCMs = dcmAssignmentRepository
                .findActiveDCMsByDepartmentAndYear(form.getUser().getDepartment(), academicYear);
        
        if (departmentDCMs.isEmpty()) {
            log.warn("No DCMs assigned for department {} in academic year {}", departmentName, academicYear);
            return null;
        }
        
        // Find DCM with least workload
        DCMAssignment selectedDCM = departmentDCMs.stream()
                .min((a, b) -> Integer.compare(
                        getCurrentDCMWorkload(a.getStaffMember()),
                        getCurrentDCMWorkload(b.getStaffMember())
                ))
                .orElse(departmentDCMs.get(0));
        
        // Create form assignment
        FormAssignment assignment = FormAssignment.builder()
                .appraisalForm(form)
                .assignedReviewer(selectedDCM.getStaffMember())
                .assignmentType("DCM_REVIEW")
                .isActive(true)
                .notes("Auto-assigned for department review")
                .build();
        
        formAssignmentRepository.save(assignment);
        
        log.info("Assigned form {} to DCM {} (workload: {}) from {} department",
                form.getId(), selectedDCM.getStaffMember().getFullName(),
                getCurrentDCMWorkload(selectedDCM.getStaffMember()), departmentName);
        
        return selectedDCM.getStaffMember();
    }
    
    /**
     * Get current workload for DCM
     */
    private int getCurrentDCMWorkload(User dcm) {
        return (int) formAssignmentRepository.countActiveAssignmentsByReviewer(dcm);
    }
} 