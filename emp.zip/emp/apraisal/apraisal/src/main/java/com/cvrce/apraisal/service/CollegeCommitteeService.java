package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface CollegeCommitteeService {
    
    Map<String, Object> getCommitteeDashboard();
    
    Page<AppraisalFormDTO> getPendingReviews(Pageable pageable, String department);
    
    ReviewDTO submitCommitteeReview(ReviewDTO reviewDTO, String currentUserEmail);
    
    Map<String, Object> getComprehensiveAppraisalView(UUID formId);
    
    List<ReviewDTO> getAppraisalReviewTrail(UUID formId);
    
    Map<String, Object> generateMeetingAgenda(String meetingDate, String department);
    
    void processBulkReviews(Map<UUID, String> formDecisions);
    
    Map<String, Object> getCrossDepartmentStatistics(String academicYear);
    
    byte[] exportReviewSummary(String academicYear, String format);
    
    void flagAppraisalForSpecialAttention(UUID formId, String flagReason, String priority);
} 