package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.Department;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.*;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);

    @Query("SELECT COUNT(DISTINCT u.department.name) FROM User u")
    long countDepartments();

    @Query("SELECT u FROM User u WHERE u.department.id = :deptId AND u.deleted = false")
    List<User> findByDepartmentId(Long deptId);

    // Additional method needed by service implementations
    @Query("SELECT COUNT(u) FROM User u JOIN u.roles r WHERE r.name = :roleName")
    long countByRoles_Name(@Param("roleName") String roleName);
    
    // Paginated department users
    @Query("SELECT u FROM User u WHERE u.department.id = :deptId AND u.deleted = false")
    Page<User> findByDepartmentId(@Param("deptId") Long deptId, Pageable pageable);
    
    // All non-deleted users with pagination
    @Query("SELECT u FROM User u WHERE u.deleted = false")
    Page<User> findAllActive(Pageable pageable);
    
    // Search users by multiple fields with pagination
    @Query("SELECT u FROM User u WHERE u.deleted = false AND " +
           "(LOWER(u.fullName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.email) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.employeeId) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.department.name) LIKE LOWER(CONCAT('%', :query, '%')))")
    Page<User> searchUsers(@Param("query") String query, Pageable pageable);
    
    // Find users by role with pagination
    @Query("SELECT u FROM User u JOIN u.roles r WHERE u.deleted = false AND LOWER(r.name) = LOWER(:roleName)")
    Page<User> findByRoleName(@Param("roleName") String roleName, Pageable pageable);
    
    // Efficient queries for scheduler
    @Query("SELECT u FROM User u WHERE u.deleted = false")
    List<User> findByDeletedFalse();
    
    @Query("SELECT u FROM User u WHERE u.deleted = false AND u.id NOT IN :excludeIds")
    List<User> findByDeletedFalseAndIdNotIn(@Param("excludeIds") List<UUID> excludeIds);

    @Query("SELECT COUNT(u) FROM User u WHERE u.department.name = :departmentName")
    long countByDepartmentName(@Param("departmentName") String departmentName);
    
    // Add method for committee management
    @Query("SELECT u FROM User u WHERE u.department.id = :departmentId AND u.deleted = false")
    List<User> findByDepartmentIdAndDeletedFalse(@Param("departmentId") Long departmentId);
    
    // Missing methods called by AdminServiceImpl
    @Query("SELECT COUNT(u) FROM User u WHERE u.enabled = true")
    long countByEnabledTrue();
    
    @Query("SELECT COUNT(u) FROM User u WHERE u.enabled = false")
    long countByEnabledFalse();
    
    @Query("SELECT COUNT(u) FROM User u WHERE u.department = :dept")
    long countByDepartment(@Param("dept") Department dept);
    
    @Query("SELECT u FROM User u WHERE u.department = :dept AND u.roles.name = :roleName")
    List<User> findByDepartmentAndRoles_Name(@Param("dept") Department dept, @Param("roleName") String roleName);
}
