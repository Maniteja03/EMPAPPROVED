package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.*;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.entity.review.ReviewerAssignment;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.ReviewerAssignmentRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final ReviewerAssignmentRepository reviewerAssignmentRepository;

    @Override
    public DashboardSummaryDTO getDashboardSummary() {
        // Use efficient counting queries instead of findAll()
        long totalAppraisals = appraisalFormRepository.count();
        long submittedAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.SUBMITTED);
        long completedAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.COMPLETED);
        long pendingAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.DEPARTMENT_REVIEW);
        
        long totalUsers = userRepository.count();
        long totalDepartments = userRepository.countDepartments();
        
        // Use efficient query for reviewer load instead of findAll()
        List<ReviewerLoadDTO> reviewerLoad = getReviewerLoadEfficiently();
        
        return DashboardSummaryDTO.builder()
                .totalSubmissions(totalAppraisals)
                .submittedToday(submittedAppraisals)
                .pendingDepartmentReviews(pendingAppraisals)
                .pendingCommitteeReviews(appraisalFormRepository.countByStatus(AppraisalStatus.COLLEGE_REVIEW))
                .pendingChairpersonReviews(appraisalFormRepository.countByStatus(AppraisalStatus.CHAIRPERSON_REVIEW))
                .totalApproved(completedAppraisals)
                .totalReuploadRequested(appraisalFormRepository.countByStatus(AppraisalStatus.REUPLOAD_REQUIRED))
                .totalDepartments(totalDepartments)
                .reviewerLoad(reviewerLoad)
                .build();
    }

    @Override
    public Map<String, Object> getStaffStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalForms", appraisalFormRepository.count());
        stats.put("submittedForms", appraisalFormRepository.countByStatus(AppraisalStatus.SUBMITTED));
        stats.put("draftForms", appraisalFormRepository.countByStatus(AppraisalStatus.DRAFT));
        stats.put("completedForms", appraisalFormRepository.countByStatus(AppraisalStatus.COMPLETED));
        return stats;
    }

    @Override
    public List<Map<String, Object>> getMyNotifications(int limit, boolean unreadOnly) {
        List<Map<String, Object>> notifications = new ArrayList<>();
        // Placeholder implementation - integrate with NotificationRepository when available
        Map<String, Object> notification = new HashMap<>();
        notification.put("id", "1");
        notification.put("title", "Sample Notification");
        notification.put("message", "This is a sample notification");
        notification.put("read", false);
        notification.put("timestamp", new Date());
        notifications.add(notification);
        return notifications.stream().limit(limit).collect(Collectors.toList());
    }

    @Override
    public Map<String, Object> getRoleBasedTasks() {
        Map<String, Object> tasks = new HashMap<>();
        tasks.put("pendingReviews", appraisalFormRepository.countByStatus(AppraisalStatus.DEPARTMENT_REVIEW));
        tasks.put("pendingApprovals", appraisalFormRepository.countByStatus(AppraisalStatus.HOD_APPROVED));
        tasks.put("committeeReviews", appraisalFormRepository.countByStatus(AppraisalStatus.COLLEGE_REVIEW));
        return tasks;
    }

    @Override
    public List<Map<String, Object>> getWorkflowProgress(String formId) {
        List<Map<String, Object>> workflow = new ArrayList<>();
        // Placeholder implementation - integrate with actual workflow tracking
        Map<String, Object> step = new HashMap<>();
        step.put("step", "Submitted");
        step.put("status", "completed");
        step.put("date", new Date());
        workflow.add(step);
        return workflow;
    }

    @Override
    public Map<String, Object> getDashboardConfig() {
        Map<String, Object> config = new HashMap<>();
        config.put("theme", "light");
        config.put("refreshInterval", 30000);
        config.put("showNotifications", true);
        config.put("defaultView", "summary");
        return config;
    }

    @Override
    public Map<String, String> updateDashboardPreferences(Map<String, Object> preferences) {
        Map<String, String> response = new HashMap<>();
        // Placeholder implementation - integrate with user preferences storage
        response.put("status", "success");
        response.put("message", "Dashboard preferences updated successfully");
        return response;
    }
    
    private List<ReviewerLoadDTO> getReviewerLoadEfficiently() {
        // Implement efficient reviewer load calculation
        // Instead of loading all assignments, use aggregate queries
        return List.of(); // Placeholder - implement based on actual ReviewerLoadDTO structure
    }
}
