package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.security.UserPrincipal;
import com.cvrce.apraisal.service.AppraisalFormService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.UUID;
import java.util.Map;

@RestController
@RequestMapping("/api/appraisals")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("isAuthenticated()")
public class AppraisalFormController {

    private final AppraisalFormService formService;

    private UUID getCurrentUserId() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserPrincipal userPrincipal) {
            return userPrincipal.getId();
        } else {
            throw new IllegalStateException("User not authenticated or invalid principal");
        }
    }

    @PostMapping("/draft")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> createDraft(@RequestParam String year) {
        UUID userId = getCurrentUserId();
        log.info("Creating draft form for user {} for year {}", userId, year);
        AppraisalFormDTO draft = formService.createDraftForm(year, userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(draft);
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<Page<AppraisalFormDTO>> getMyForms(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        UUID userId = getCurrentUserId();
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> forms = formService.getMySubmissions(userId, pageable);
        return ResponseEntity.ok(forms);
    }

    // Keep backward compatibility with non-paginated version
    @GetMapping("/my/all")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<List<AppraisalFormDTO>> getMyFormsAll() {
        UUID userId = getCurrentUserId();
        List<AppraisalFormDTO> forms = formService.getMySubmissions(userId);
        return ResponseEntity.ok(forms);
    }

    @PostMapping("/submit/{formId}")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    // Rate limiting: Max 10 form submissions per day per user
    public ResponseEntity<AppraisalFormDTO> submitForm(@PathVariable UUID formId) {
        // Security check: Ensure user can only submit their own forms
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            AppraisalFormDTO submittedForm = formService.submitForm(formId, currentUserEmail);
            log.info("Form {} submitted successfully by {}", formId, currentUserEmail);
            return ResponseEntity.ok(submittedForm);
        } catch (SecurityException e) {
            log.warn("Unauthorized form submission attempt: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        } catch (IllegalStateException e) {
            log.warn("Invalid form submission: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }

    // Add missing update endpoints for form sections
    @PutMapping("/forms/{formId}/basic-info")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> updateBasicInfo(@PathVariable UUID formId, @RequestBody Map<String, Object> basicInfo) {
        try {
            AppraisalFormDTO updatedForm = formService.updateBasicInfo(formId, basicInfo);
            return ResponseEntity.ok(updatedForm);
        } catch (Exception e) {
            log.error("Error updating basic info for form {}: {}", formId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/forms/{formId}/teaching")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> updateTeachingActivities(@PathVariable UUID formId, @RequestBody Map<String, Object> teachingData) {
        try {
            AppraisalFormDTO updatedForm = formService.updateTeachingActivities(formId, teachingData);
            return ResponseEntity.ok(updatedForm);
        } catch (Exception e) {
            log.error("Error updating teaching activities for form {}: {}", formId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/forms/{formId}/research")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> updateResearchActivities(@PathVariable UUID formId, @RequestBody Map<String, Object> researchData) {
        try {
            AppraisalFormDTO updatedForm = formService.updateResearchActivities(formId, researchData);
            return ResponseEntity.ok(updatedForm);
        } catch (Exception e) {
            log.error("Error updating research activities for form {}: {}", formId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/forms/{formId}/service")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> updateServiceActivities(@PathVariable UUID formId, @RequestBody Map<String, Object> serviceData) {
        try {
            AppraisalFormDTO updatedForm = formService.updateServiceActivities(formId, serviceData);
            return ResponseEntity.ok(updatedForm);
        } catch (Exception e) {
            log.error("Error updating service activities for form {}: {}", formId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/forms/{formId}/additional")
    @PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> updateAdditionalInfo(@PathVariable UUID formId, @RequestBody Map<String, Object> additionalInfo) {
        try {
            AppraisalFormDTO updatedForm = formService.updateAdditionalInfo(formId, additionalInfo);
            return ResponseEntity.ok(updatedForm);
        } catch (Exception e) {
            log.error("Error updating additional info for form {}: {}", formId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/filter")
    @PreAuthorize("hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<Page<AppraisalFormDTO>> filterByStatus(
            @RequestParam AppraisalStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> filteredForms = formService.filterByStatus(status, pageable);
        return ResponseEntity.ok(filteredForms);
    }

    // List all appraisals with pagination (admin/reviewer use)
    @GetMapping("/all")
    @PreAuthorize("hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<Page<AppraisalFormDTO>> getAllAppraisals(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir,
            @RequestParam(required = false) String academicYear,
            @RequestParam(required = false) AppraisalStatus status) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> forms = formService.getAllAppraisals(pageable, academicYear, status);
        return ResponseEntity.ok(forms);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('STAFF') or hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<AppraisalFormDTO> getById(@PathVariable UUID id) {
        // Critical security fix: Check ownership before allowing access
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!formService.canUserAccessForm(id, currentUserEmail)) {
            log.warn("Unauthorized access attempt to appraisal form {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        AppraisalFormDTO form = formService.getById(id);
        return ResponseEntity.ok(form);
    }

    // Search functionality with pagination
    @GetMapping("/search")
    @PreAuthorize("hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<Page<AppraisalFormDTO>> searchAppraisals(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> results = formService.searchAppraisals(query, pageable);
        return ResponseEntity.ok(results);
    }
}
