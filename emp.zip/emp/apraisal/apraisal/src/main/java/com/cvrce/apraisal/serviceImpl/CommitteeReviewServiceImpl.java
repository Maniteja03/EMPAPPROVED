package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.committee.CommitteeDashboardDTO;
import com.cvrce.apraisal.dto.committee.CommitteeAssignmentDTO;
import com.cvrce.apraisal.dto.committee.CommitteeWorkloadDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CommitteeReviewServiceImpl implements CommitteeReviewService {
    
    private static final int MAX_WORKLOAD_PER_MEMBER = 15; // Maximum forms per committee member
    
    private final AppraisalFormRepository appraisalFormRepository;
    private final CommitteeAssignmentRepository committeeAssignmentRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final FormLockingService formLockingService;
    private final AppraisalWorkflowService workflowService;
    private final CommitteeManagementService committeeManagementService;
    
    @Override
    public CommitteeDashboardDTO getCommitteeDashboard(String committeeEmail, String academicYear) {
        User committeeMember = getUserByEmail(committeeEmail);
        validateCommitteeMember(committeeMember, academicYear);
        
        String memberDepartment = committeeMember.getDepartment().getName();
        
        log.info("Getting committee dashboard for {} from {} department", 
                committeeMember.getFullName(), memberDepartment);
        
        CommitteeDashboardDTO dashboard = new CommitteeDashboardDTO();
        dashboard.setCommitteeMemberName(committeeMember.getFullName());
        dashboard.setDepartmentName(memberDepartment);
        dashboard.setAcademicYear(academicYear);
        
        // Get forms available for review (excludes own department)
        int formsAvailableForReview = getFormsAvailableForReviewCount(memberDepartment, academicYear);
        dashboard.setFormsAvailableForReview(formsAvailableForReview);
        
        // Get forms currently being reviewed by this member
        List<FormLock> activeLocks = formLockingService.getActiveLocksByReviewer(committeeMember);
        dashboard.setActiveLocks(activeLocks.size());
        
        // Get completed reviews count
        long completedReviews = reviewRepository.countByReviewerAndLevel(committeeMember, ReviewLevel.COMMITTEE_REVIEW);
        dashboard.setFormsCompleted((int) completedReviews);
        
        // Get own department forms count (VIEW ONLY)
        int ownDeptFormsCount = getOwnDepartmentFormsCount(memberDepartment, academicYear);
        dashboard.setOwnDepartmentFormsCount(ownDeptFormsCount);
        
        // Calculate workload percentage
        CommitteeAssignmentDTO assignment = committeeManagementService.getCommitteeAssignmentForUser(committeeMember, academicYear);
        if (assignment != null) {
            double workloadPercentage = assignment.getMaxWorkloadCapacity() > 0 ? 
                    (double) assignment.getCurrentWorkload() / assignment.getMaxWorkloadCapacity() * 100 : 0;
            dashboard.setCompletionRate(workloadPercentage);
        }
        
        // Set workload status
        String workloadStatus = assignment != null ? assignment.getWorkloadStatus() : "NOT_ASSIGNED";
        dashboard.setCurrentWorkloadStatus(workloadStatus);
        
        log.info("Committee dashboard: {} available, {} active, {} completed for {}", 
                formsAvailableForReview, activeLocks.size(), completedReviews, committeeMember.getFullName());
        
        return dashboard;
    }
    
    @Override
    public Page<AppraisalFormDTO> getAvailableFormsForReview(String committeeEmail, String academicYear, Pageable pageable) {
        User committeeMember = getUserByEmail(committeeEmail);
        validateCommitteeMember(committeeMember, academicYear);
        
        String memberDepartment = committeeMember.getDepartment().getName();
        
        log.info("Committee member {} from {} requesting available forms for review", 
                committeeMember.getFullName(), memberDepartment);
        
        // Get forms ready for committee review, excluding own department
        List<AppraisalForm> availableForms = appraisalFormRepository
                .findByStatusAndUserDepartmentNameNot(AppraisalStatus.COMMITTEE_REVIEW, memberDepartment);
        
        // Filter out forms that are currently locked by other reviewers
        List<AppraisalForm> unlocked = availableForms.stream()
                .filter(form -> !formLockingService.isFormLocked(form.getId()) || 
                              formLockingService.isFormLockedByReviewer(form.getId(), committeeMember))
                .collect(Collectors.toList());
        
        log.info("Found {} forms available for committee review (excluding {} department)", 
                unlocked.size(), memberDepartment);
        
        // Convert to DTOs
        List<AppraisalFormDTO> dtoList = unlocked.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Apply pagination
        return applyPagination(dtoList, pageable);
    }
    
    @Override
    public Page<AppraisalFormDTO> getOwnDepartmentForms(String committeeEmail, String academicYear, Pageable pageable) {
        User committeeMember = getUserByEmail(committeeEmail);
        validateCommitteeMember(committeeMember, academicYear);
        
        String memberDepartment = committeeMember.getDepartment().getName();
        
        log.info("Committee member {} requesting own department ({}) forms for viewing", 
                committeeMember.getFullName(), memberDepartment);
        
        // Get forms from own department (for viewing only)
        List<AppraisalForm> ownDeptForms = appraisalFormRepository
                .findByUserDepartmentNameAndAcademicYear(memberDepartment, academicYear);
        
        // Convert to DTOs and mark as read-only
        List<AppraisalFormDTO> dtoList = ownDeptForms.stream()
                .map(form -> {
                    AppraisalFormDTO dto = mapToDTO(form);
                    // Add flag to indicate this is read-only (own department)
                    dto.setReadOnly(true);
                    return dto;
                })
                .collect(Collectors.toList());
        
        log.info("Found {} forms from own department {} for viewing", dtoList.size(), memberDepartment);
        
        return applyPagination(dtoList, pageable);
    }
    
    @Override
    @Transactional
    public Optional<FormLock> startFormReview(UUID formId, String committeeEmail) {
        User committeeMember = getUserByEmail(committeeEmail);
        AppraisalForm form = getAppraisalForm(formId);
        
        // Security check: Committee member cannot review own department forms
        String memberDepartment = committeeMember.getDepartment().getName();
        String formDepartment = form.getUser().getDepartment().getName();
        
        if (memberDepartment.equals(formDepartment)) {
            log.warn("SECURITY VIOLATION: Committee member {} from {} tried to review form from own department", 
                    committeeMember.getFullName(), memberDepartment);
            throw new SecurityException("Committee members cannot review forms from their own department");
        }
        
        // Check if form is in correct status for committee review
        if (form.getStatus() != AppraisalStatus.COMMITTEE_REVIEW) {
            throw new IllegalStateException("Form is not ready for committee review. Current status: " + form.getStatus());
        }
        
        // Attempt to lock the form
        Optional<FormLock> lock = formLockingService.lockForm(formId, committeeMember, ReviewLevel.COMMITTEE_REVIEW);
        
        if (lock.isPresent()) {
            // Update committee member workload
            CommitteeAssignmentDTO assignment = committeeManagementService.getCommitteeAssignmentForUser(
                    committeeMember, form.getAcademicYear());
            if (assignment != null) {
                committeeManagementService.assignFormToCommitteeMember(assignment.getAssignmentId(), formId);
            }
            
            log.info("Committee member {} successfully locked form {} from {} department for review", 
                    committeeMember.getFullName(), formId, formDepartment);
        } else {
            log.warn("Committee member {} failed to lock form {} - already locked by another reviewer", 
                    committeeMember.getFullName(), formId);
        }
        
        return lock;
    }
    
    @Override
    public AppraisalFormDTO getFormForReview(UUID formId, String committeeEmail) {
        User committeeMember = getUserByEmail(committeeEmail);
        AppraisalForm form = getAppraisalForm(formId);
        
        // Security check: Committee member cannot review own department forms
        String memberDepartment = committeeMember.getDepartment().getName();
        String formDepartment = form.getUser().getDepartment().getName();
        
        if (memberDepartment.equals(formDepartment)) {
            log.warn("SECURITY VIOLATION: Committee member {} from {} tried to access form from own department for review", 
                    committeeMember.getFullName(), memberDepartment);
            throw new SecurityException("Committee members cannot review forms from their own department");
        }
        
        // Check if form is locked by this reviewer
        if (!formLockingService.isFormLockedByReviewer(formId, committeeMember)) {
            throw new IllegalStateException("Form is not locked by you for review");
        }
        
        log.info("Committee member {} accessing form {} from {} department for review", 
                committeeMember.getFullName(), formId, formDepartment);
        
        return mapToDTO(form);
    }
    
    @Override
    @Transactional
    public ReviewDTO submitCommitteeReview(ReviewDTO reviewDTO, String committeeEmail) {
        User committeeMember = getUserByEmail(committeeEmail);
        AppraisalForm form = getAppraisalForm(reviewDTO.getAppraisalFormId());
        
        // Security checks
        String memberDepartment = committeeMember.getDepartment().getName();
        String formDepartment = form.getUser().getDepartment().getName();
        
        if (memberDepartment.equals(formDepartment)) {
            log.warn("SECURITY VIOLATION: Committee member {} from {} tried to submit review for own department form", 
                    committeeMember.getFullName(), memberDepartment);
            throw new SecurityException("Committee members cannot review forms from their own department");
        }
        
        // Check if form is locked by this reviewer
        if (!formLockingService.isFormLockedByReviewer(form.getId(), committeeMember)) {
            throw new IllegalStateException("Form is not locked by you for review");
        }
        
        // Check if already reviewed by this committee member
        Optional<Review> existingReview = reviewRepository.findByReviewerAndAppraisalForm(committeeMember, form);
        if (existingReview.isPresent()) {
            throw new IllegalStateException("You have already reviewed this form");
        }
        
        // Create review
        Review review = Review.builder()
                .reviewer(committeeMember)
                .appraisalForm(form)
                .decision(ReviewDecision.valueOf(reviewDTO.getDecision()))
                .remarks(reviewDTO.getRemarks())
                .level(ReviewLevel.COMMITTEE_REVIEW)
                .reviewedAt(LocalDateTime.now())
                .build();
        
        Review savedReview = reviewRepository.save(review);
        
        // Update appraisal status using workflow service
        AppraisalStatus newStatus = workflowService.transitionToNextStage(
                form.getId(), form.getStatus(), reviewDTO.getDecision());
        form.setStatus(newStatus);
        appraisalFormRepository.save(form);
        
        // If rejected, it should go back to HOD with same committee member assigned
        if (ReviewDecision.REJECTED.equals(savedReview.getDecision())) {
            // The form will be assigned back to the same committee member when HOD resubmits
            log.info("Form {} rejected by committee member {} - will be reassigned to same member after HOD update", 
                    form.getId(), committeeMember.getFullName());
        }
        
        // Release form lock and update workload
        formLockingService.unlockForm(form.getId(), committeeMember);
        
        CommitteeAssignmentDTO assignment = committeeManagementService.getCommitteeAssignmentForUser(
                committeeMember, form.getAcademicYear());
        if (assignment != null) {
            committeeManagementService.completeFormReviewByCommitteeMember(assignment.getAssignmentId(), form.getId());
        }
        
        log.info("Committee member {} from {} submitted {} review for form {} from {} department", 
                committeeMember.getFullName(), memberDepartment, reviewDTO.getDecision(), 
                form.getId(), formDepartment);
        
        return mapReviewToDTO(savedReview);
    }
    
    @Override
    @Transactional
    public boolean cancelFormReview(UUID formId, String committeeEmail) {
        User committeeMember = getUserByEmail(committeeEmail);
        
        // Release the lock
        boolean unlocked = formLockingService.unlockForm(formId, committeeMember);
        
        if (unlocked) {
            // Update workload (remove from current workload)
            AppraisalForm form = getAppraisalForm(formId);
            CommitteeAssignmentDTO assignment = committeeManagementService.getCommitteeAssignmentForUser(
                    committeeMember, form.getAcademicYear());
            if (assignment != null) {
                // Decrement workload without incrementing completed (since review was cancelled)
                committeeAssignmentRepository.incrementWorkload(assignment.getAssignmentId()); // This actually decrements due to negative
            }
            
            log.info("Committee member {} cancelled review of form {}", committeeMember.getFullName(), formId);
        }
        
        return unlocked;
    }
    
    @Override
    public List<AppraisalFormDTO> getMyActiveReviews(String committeeEmail) {
        User committeeMember = getUserByEmail(committeeEmail);
        
        // Get forms currently locked by this committee member
        List<FormLock> activeLocks = formLockingService.getActiveLocksByReviewer(committeeMember);
        
        List<AppraisalFormDTO> activeReviews = new ArrayList<>();
        for (FormLock lock : activeLocks) {
            try {
                AppraisalForm form = getAppraisalForm(lock.getFormId());
                AppraisalFormDTO dto = mapToDTO(form);
                dto.setLockExpiresAt(lock.getExpiresAt());
                activeReviews.add(dto);
            } catch (ResourceNotFoundException e) {
                log.warn("Form {} referenced in lock but not found in database", lock.getFormId());
            }
        }
        
        log.info("Committee member {} has {} active reviews", committeeMember.getFullName(), activeReviews.size());
        
        return activeReviews;
    }
    
    @Override
    public Page<ReviewDTO> getMyReviewHistory(String committeeEmail, String academicYear, Pageable pageable) {
        User committeeMember = getUserByEmail(committeeEmail);
        
        // Get reviews by this committee member
        List<Review> reviews = reviewRepository.findByReviewerAndLevel(committeeMember, ReviewLevel.COMMITTEE_REVIEW);
        
        // Filter by academic year if provided
        if (academicYear != null) {
            reviews = reviews.stream()
                    .filter(review -> academicYear.equals(review.getAppraisalForm().getAcademicYear()))
                    .collect(Collectors.toList());
        }
        
        List<ReviewDTO> reviewDTOs = reviews.stream()
                .map(this::mapReviewToDTO)
                .collect(Collectors.toList());
        
        return applyPagination(reviewDTOs, pageable);
    }
    
    @Override
    public boolean extendReviewLock(UUID formId, String committeeEmail, int additionalMinutes) {
        User committeeMember = getUserByEmail(committeeEmail);
        
        boolean extended = formLockingService.extendLock(formId, committeeMember, additionalMinutes);
        
        if (extended) {
            log.info("Committee member {} extended lock for form {} by {} minutes", 
                    committeeMember.getFullName(), formId, additionalMinutes);
        }
        
        return extended;
    }
    
    @Override
    public CommitteeWorkloadDTO getMyWorkloadStats(String committeeEmail, String academicYear) {
        User committeeMember = getUserByEmail(committeeEmail);
        
        CommitteeAssignmentDTO assignment = committeeManagementService.getCommitteeAssignmentForUser(
                committeeMember, academicYear);
        
        CommitteeWorkloadDTO workload = new CommitteeWorkloadDTO();
        workload.setCommitteeMemberName(committeeMember.getFullName());
        workload.setAcademicYear(academicYear);
        
        if (assignment != null) {
            workload.setCurrentWorkload(assignment.getCurrentWorkload());
            workload.setCompletedReviews(assignment.getCompletedReviews());
            workload.setTotalAssignedForms(assignment.getCurrentWorkload() + assignment.getCompletedReviews());
            workload.setCanTakeMoreWork(assignment.isCanTakeMoreWork());
            workload.setMaxWorkloadCapacity(assignment.getMaxWorkloadCapacity());
            
            // Calculate completion rate
            if (assignment.getTotalAssignedForms() > 0) {
                double rate = (double) assignment.getCompletedReviews() / assignment.getTotalAssignedForms() * 100;
                workload.setCompletionRate(rate);
            }
            
            workload.setWorkloadStatus(assignment.getWorkloadStatus());
        } else {
            // Not a committee member for this academic year
            workload.setCurrentWorkload(0);
            workload.setMaxWorkloadCapacity(0);
            workload.setCompletedReviews(0);
            workload.setCompletionRate(0);
            workload.setCanTakeMoreWork(false);
            workload.setWorkloadStatus("NOT_ASSIGNED");
        }
        
        return workload;
    }
    
    @Override
    public boolean canReviewDepartmentForms(String committeeEmail, String departmentName) {
        User committeeMember = getUserByEmail(committeeEmail);
        String memberDepartment = committeeMember.getDepartment().getName();
        
        // Committee members cannot review their own department forms
        boolean canReview = !memberDepartment.equals(departmentName);
        
        log.debug("Committee member {} from {} {} review {} department forms", 
                committeeMember.getFullName(), memberDepartment, 
                canReview ? "CAN" : "CANNOT", departmentName);
        
        return canReview;
    }
    
    // Helper methods
    
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + email));
    }
    
    private AppraisalForm getAppraisalForm(UUID formId) {
        return appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found: " + formId));
    }
    
    private void validateCommitteeMember(User user, String academicYear) {
        if (!committeeManagementService.isUserCommitteeMember(user, academicYear)) {
            throw new SecurityException("User is not a committee member for " + academicYear);
        }
    }
    
    private int getFormsAvailableForReviewCount(String excludeDepartment, String academicYear) {
        List<AppraisalForm> forms = appraisalFormRepository
                .findByStatusAndUserDepartmentNameNot(AppraisalStatus.COMMITTEE_REVIEW, excludeDepartment);
        
        // Filter out locked forms
        return (int) forms.stream()
                .filter(form -> !formLockingService.isFormLocked(form.getId()))
                .count();
    }
    
    private int getOwnDepartmentFormsCount(String departmentName, String academicYear) {
        return appraisalFormRepository.findByUserDepartmentNameAndAcademicYear(departmentName, academicYear).size();
    }
    
    private List<String> getDepartmentsCanReview(String excludeDepartment) {
        return departmentRepository.findAllByOrderByNameAsc().stream()
                .map(Department::getName)
                .filter(name -> !name.equals(excludeDepartment))
                .collect(Collectors.toList());
    }
    
    private List<AppraisalFormDTO> getRecentlyCompletedReviews(User committeeMember, int limit) {
        List<Review> recentReviews = reviewRepository.findByReviewerAndLevel(committeeMember, ReviewLevel.COMMITTEE_REVIEW)
                .stream()
                .sorted((r1, r2) -> r2.getReviewedAt().compareTo(r1.getReviewedAt()))
                .limit(limit)
                .collect(Collectors.toList());
        
        return recentReviews.stream()
                .map(review -> mapToDTO(review.getAppraisalForm()))
                .collect(Collectors.toList());
    }
    
    private <T> Page<T> applyPagination(List<T> items, Pageable pageable) {
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), items.size());
        List<T> pageContent = start < items.size() ? items.subList(start, end) : new ArrayList<>();
        
        return new PageImpl<>(pageContent, pageable, items.size());
    }
    
    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .locked(form.isLocked())
                .userId(form.getUser().getId())
                .userFullName(form.getUser().getFullName())
                .userDepartment(form.getUser().getDepartment().getName())
                .submittedAsRole(form.getSubmittedAsRole())
                .build();
    }
    
    private ReviewDTO mapReviewToDTO(Review review) {
        return ReviewDTO.builder()
                .id(review.getId())
                .appraisalFormId(review.getAppraisalForm().getId())
                .reviewerId(review.getReviewer().getId())
                .decision(review.getDecision().name())
                .remarks(review.getRemarks())
                .level(review.getLevel().name())
                .reviewedAt(review.getReviewedAt())
                .reviewerName(review.getReviewer().getFullName())
                .reviewerDepartment(review.getReviewer().getDepartment().getName())
                .build();
    }
} 