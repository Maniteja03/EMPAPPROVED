package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "citation_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CitationScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Faculty Details
    @Column(name = "faculty_name", nullable = false, length = 200)
    private String facultyName;
    
    @Column(name = "scopus_author_id", nullable = false, length = 100)
    private String scopusAuthorId;
    
    // Citation Details
    @Column(name = "number_of_citations", nullable = false)
    @Builder.Default
    private Integer numberOfCitations = 0;
    
    @Column(name = "calendar_year", nullable = false)
    private Integer calendarYear; // 2024
    
    // Scoring (1 point per citation)
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    // Verification
    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private Boolean isVerified = false;
    
    @Column(name = "verification_source", length = 100)
    @Builder.Default
    private String verificationSource = "Scopus";
    
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points (1 point per citation)
    public void calculatePoints() {
        if (numberOfCitations != null && numberOfCitations > 0) {
            this.pointsClaimed = new BigDecimal(numberOfCitations);
        }
    }
    
    // Validation
    public boolean isValidForScoring() {
        return facultyName != null && !facultyName.trim().isEmpty() &&
               scopusAuthorId != null && !scopusAuthorId.trim().isEmpty() &&
               numberOfCitations != null && numberOfCitations >= 0 &&
               calendarYear != null;
    }
} 