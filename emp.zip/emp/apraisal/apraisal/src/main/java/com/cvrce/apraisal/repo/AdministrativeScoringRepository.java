package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AdministrativeScoring;
import com.cvrce.apraisal.entity.AdministrativeComponent;
import com.cvrce.apraisal.entity.AppraisalScoring;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface AdministrativeScoringRepository extends JpaRepository<AdministrativeScoring, UUID> {
    
    List<AdministrativeScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT ads FROM AdministrativeScoring ads WHERE ads.appraisalScoring.id = :scoringId ORDER BY ads.componentType")
    List<AdministrativeScoring> findByAppraisalScoringIdOrderByComponent(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT ads FROM AdministrativeScoring ads WHERE ads.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<AdministrativeScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT ads FROM AdministrativeScoring ads WHERE ads.componentType = :componentType")
    List<AdministrativeScoring> findByComponentType(@Param("componentType") AdministrativeComponent componentType);
    
    @Query("SELECT ads FROM AdministrativeScoring ads WHERE ads.componentType = 'HOD_FEEDBACK'")
    List<AdministrativeScoring> findHODFeedbackScorings();
} 