package com.cvrce.apraisal.service;

import java.util.UUID;
import java.util.*;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.enums.AppraisalStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AppraisalFormService {
    AppraisalFormDTO createDraftForm(String academicYear, UUID userId);
    
    // Original non-paginated methods for backward compatibility
    List<AppraisalFormDTO> getMySubmissions(UUID userId);
    List<AppraisalFormDTO> filterByStatus(AppraisalStatus status);
    
    // New paginated methods
    Page<AppraisalFormDTO> getMySubmissions(UUID userId, Pageable pageable);
    Page<AppraisalFormDTO> filterByStatus(AppraisalStatus status, Pageable pageable);
    Page<AppraisalFormDTO> getAllAppraisals(Pageable pageable, String academicYear, AppraisalStatus status);
    Page<AppraisalFormDTO> searchAppraisals(String query, Pageable pageable);
    
    AppraisalFormDTO submit(UUID formId); // locks and submits
    AppraisalFormDTO getById(UUID formId);
    
    // Security validation method to prevent data breach
    boolean canUserAccessForm(UUID formId, String currentUserEmail);
    
    // Missing methods called by controller
    AppraisalFormDTO submitForm(UUID formId, String currentUserEmail);
    AppraisalFormDTO updateBasicInfo(UUID formId, Map<String, Object> basicInfo);
    AppraisalFormDTO updateTeachingActivities(UUID formId, Map<String, Object> teachingData);
    AppraisalFormDTO updateResearchActivities(UUID formId, Map<String, Object> researchData);
    AppraisalFormDTO updateServiceActivities(UUID formId, Map<String, Object> serviceData);
    AppraisalFormDTO updateAdditionalInfo(UUID formId, Map<String, Object> additionalInfo);
}

