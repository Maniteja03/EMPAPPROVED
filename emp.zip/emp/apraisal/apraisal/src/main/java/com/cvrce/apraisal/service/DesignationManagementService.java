package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.designation.DesignationDTO;
import com.cvrce.apraisal.dto.designation.DesignationHistoryDTO;
import com.cvrce.apraisal.dto.designation.PromotionRequestDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface DesignationManagementService {
    
    /**
     * Get current designation for a user
     */
    DesignationDTO getCurrentDesignation(UUID userId);
    
    /**
     * Get designation history for a user
     */
    List<DesignationHistoryDTO> getDesignationHistory(UUID userId);
    
    /**
     * Get all current designations with pagination and search
     */
    Page<DesignationDTO> getAllCurrentDesignations(String searchTerm, Pageable pageable);
    
    /**
     * Get designations by department
     */
    List<DesignationDTO> getDesignationsByDepartment(UUID departmentId);
    
    /**
     * Promote user to new designation
     */
    DesignationDTO promoteUser(PromotionRequestDTO promotionRequest);
    
    /**
     * Get designation statistics
     */
    Map<String, Object> getDesignationStatistics();
    
    /**
     * Get users eligible for promotion
     */
    List<DesignationDTO> getUsersEligibleForPromotion(int yearsInCurrentDesignation);
    
    /**
     * Get all designation types
     */
    List<Map<String, String>> getDesignationTypes();
    
    /**
     * Update designation details (not promotion)
     */
    DesignationDTO updateDesignationDetails(UUID designationId, DesignationDTO designationDTO);
    
    /**
     * Initialize designation for new user
     */
    DesignationDTO initializeDesignationForUser(UUID userId, String designationType, String academicYear);
    
    /**
     * Get designation for scoring purposes (at specific date)
     */
    DesignationDTO getDesignationForScoring(UUID userId, java.time.LocalDate date);
} 