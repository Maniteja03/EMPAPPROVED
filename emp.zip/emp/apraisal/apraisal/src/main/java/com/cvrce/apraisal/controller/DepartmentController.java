package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.dto.department.DepartmentDTO;
import com.cvrce.apraisal.dto.department.DepartmentCreateDTO;
import com.cvrce.apraisal.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class DepartmentController {

    private final DepartmentService departmentService;

    @GetMapping("/departments")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<DepartmentDTO>> getAllDepartments() {
        List<DepartmentDTO> departments = departmentService.getAllDepartments();
        return ResponseEntity.ok(departments);
    }

    @GetMapping("/courses")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getAllCourses() {
        List<Map<String, Object>> courses = departmentService.getAllCourses();
        return ResponseEntity.ok(courses);
    }

    @PostMapping("/departments")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<DepartmentDTO> createDepartment(@RequestBody DepartmentCreateDTO deptData) {
        DepartmentDTO department = departmentService.createDepartment(deptData);
        return ResponseEntity.ok(department);
    }

    @PutMapping("/departments/{deptId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<DepartmentDTO> updateDepartment(@PathVariable Long deptId, 
                                                         @RequestBody DepartmentCreateDTO deptData) {
        DepartmentDTO department = departmentService.updateDepartment(deptId, deptData);
        return ResponseEntity.ok(department);
    }

    @DeleteMapping("/departments/{deptId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deleteDepartment(@PathVariable Long deptId) {
        departmentService.deleteDepartment(deptId);
        return ResponseEntity.ok("Department deleted successfully");
    }
}
