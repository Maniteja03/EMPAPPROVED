package com.cvrce.apraisal.entity;

public enum ParticipationType {
    ORGANIZED("Organized"),
    ATTENDED("Attended");
    
    private final String displayName;
    
    ParticipationType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() { return displayName; }
} 