package com.cvrce.apraisal.enums;

public enum ReviewLevel {
    DEPARTMENT_REVIEW,
    HOD_REVIEW,
    COMMITTEE_REVIEW,        // Committee review level
    COLLEGE_COMMITTEE_REVIEW,
    CHAIRPERSON_REVIEW
}
