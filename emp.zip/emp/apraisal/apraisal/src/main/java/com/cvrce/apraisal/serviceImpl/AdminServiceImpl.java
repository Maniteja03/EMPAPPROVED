package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final AppraisalFormRepository appraisalFormRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public Map<String, Object> getSystemStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // Get real counts from database
        long totalUsers = userRepository.count();
        long activeUsers = userRepository.countByEnabledTrue();
        long totalDepartments = departmentRepository.count();
        long totalForms = appraisalFormRepository.count();
        long completedForms = appraisalFormRepository.countByStatus(AppraisalStatus.COMPLETED);
        long pendingForms = totalForms - completedForms;
        
        stats.put("totalUsers", totalUsers);
        stats.put("activeUsers", activeUsers);
        stats.put("totalDepartments", totalDepartments);
        stats.put("totalForms", totalForms);
        stats.put("completedForms", completedForms);
        stats.put("pendingForms", pendingForms);
        
        // System metrics (these would come from monitoring service in real implementation)
        stats.put("systemUptime", calculateSystemUptime());
        stats.put("averageResponseTime", getCurrentAverageResponseTime());
        
        return stats;
    }

    @Override
    public List<Map<String, Object>> getDepartmentOverview() {
        List<Department> departments = departmentRepository.findAll();
        
        return departments.stream().map(dept -> {
            Map<String, Object> deptInfo = new HashMap<>();
            
            // Get real data for each department
            long totalStaff = userRepository.countByDepartment(dept);
            long totalForms = appraisalFormRepository.countByUserDepartment(dept);
            long completedForms = appraisalFormRepository.countByUserDepartmentAndStatus(dept, AppraisalStatus.COMPLETED.name());
            
            // Calculate average score for completed forms
            Double averageScore = appraisalFormRepository.getAverageScoreByDepartmentAndStatus(dept, AppraisalStatus.COMPLETED.name());
            double completionRate = totalForms > 0 ? (double) completedForms / totalForms * 100 : 0;
            
            deptInfo.put("id", dept.getId());
            deptInfo.put("name", dept.getName());
            deptInfo.put("totalStaff", totalStaff);
            deptInfo.put("totalForms", totalForms);
            deptInfo.put("completedForms", completedForms);
            deptInfo.put("averageScore", averageScore != null ? averageScore : 0.0);
            deptInfo.put("completionRate", Math.round(completionRate * 100.0) / 100.0);
            deptInfo.put("hodName", getHODName(dept));
            deptInfo.put("lastUpdated", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
            
            return deptInfo;
        }).collect(Collectors.toList());
    }

    @Override
    public List<Map<String, Object>> getSystemAlerts() {
        List<Map<String, Object>> alerts = new ArrayList<>();
        
        // Check for real system issues
        checkOverdueForms(alerts);
        checkInactiveUsers(alerts);
        checkSystemResources(alerts);
        
        return alerts;
    }

    @Override
    public List<Map<String, Object>> getRecentActivity(int limit) {
        // In real implementation, this would come from audit log table
        // For now, get recent form submissions and user activities
        List<Map<String, Object>> activities = new ArrayList<>();
        
        Pageable pageable = PageRequest.of(0, limit);
        List<AppraisalForm> recentForms = appraisalFormRepository.findAllByOrderByCreatedAtDesc(pageable);
        
        for (AppraisalForm form : recentForms) {
            Map<String, Object> activity = new HashMap<>();
            activity.put("id", form.getId().toString());
            activity.put("type", "form_submission");
            activity.put("user", form.getUser().getFullName());
            activity.put("action", "Submitted appraisal form");
            activity.put("target", "Form " + form.getId());
            activity.put("timestamp", form.getCreatedAt().toString());
            activity.put("details", "Academic Year: " + form.getAcademicYear());
            activities.add(activity);
        }
        
        return activities;
    }

    @Override
    public Map<String, Object> getSystemHealth() {
        Map<String, Object> health = new HashMap<>();
        
        // Check database connectivity
        try {
            userRepository.count();
            health.put("database", "connected");
        } catch (Exception e) {
            health.put("database", "error");
        }
        
        // System metrics (in real implementation, these would come from monitoring service)
        health.put("status", "healthy");
        health.put("cpu", getCurrentCPUUsage());
        health.put("memory", getCurrentMemoryUsage());
        health.put("disk", getCurrentDiskUsage());
        health.put("uptime", calculateSystemUptime());
        
        return health;
    }

    @Override
    public Map<String, String> createUser(Map<String, Object> userData) {
        try {
            User newUser = User.builder()
                    .id(UUID.randomUUID())
                    .employeeId((String) userData.get("employeeId"))
                    .fullName((String) userData.get("fullName"))
                    .email((String) userData.get("email"))
                    .password(passwordEncoder.encode((String) userData.get("password")))
                    .enabled(true)
                    .deleted(false)
                    .build();
            
            User savedUser = userRepository.save(newUser);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "User created successfully");
            response.put("userId", savedUser.getId().toString());
            
            return response;
        } catch (Exception e) {
            log.error("Error creating user: ", e);
            Map<String, String> response = new HashMap<>();
            response.put("error", "Failed to create user: " + e.getMessage());
            return response;
        }
    }

    @Override
    public List<Map<String, Object>> getUsers(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        List<User> users = userRepository.findAll(pageable).getContent();
        
        return users.stream().map(user -> {
            Map<String, Object> userInfo = new HashMap<>();
            userInfo.put("id", user.getId().toString());
            userInfo.put("employeeId", user.getEmployeeId());
            userInfo.put("name", user.getFullName());
            userInfo.put("email", user.getEmail());
            userInfo.put("department", user.getDepartment() != null ? user.getDepartment().getName() : "");
            userInfo.put("roles", user.getRoles().stream().map(role -> role.getName()).collect(Collectors.toList()));
            userInfo.put("status", user.isEnabled() ? "active" : "inactive");
            userInfo.put("lastLogin", user.getLastLogin());
            return userInfo;
        }).collect(Collectors.toList());
    }

    @Override
    public Map<String, String> updateUser(String userId, Map<String, Object> userData) {
        try {
            Optional<User> userOpt = userRepository.findById(UUID.fromString(userId));
            if (userOpt.isEmpty()) {
                Map<String, String> response = new HashMap<>();
                response.put("error", "User not found");
                return response;
            }
            
            User user = userOpt.get();
            // Update user fields from userData
            if (userData.containsKey("fullName")) {
                user.setFullName((String) userData.get("fullName"));
            }
            if (userData.containsKey("email")) {
                user.setEmail((String) userData.get("email"));
            }
            
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "User updated successfully");
            return response;
        } catch (Exception e) {
            log.error("Error updating user: ", e);
            Map<String, String> response = new HashMap<>();
            response.put("error", "Failed to update user: " + e.getMessage());
            return response;
        }
    }

    @Override
    public Map<String, String> deleteUser(String userId) {
        try {
            Optional<User> userOpt = userRepository.findById(UUID.fromString(userId));
            if (userOpt.isEmpty()) {
                Map<String, String> response = new HashMap<>();
                response.put("error", "User not found");
                return response;
            }
            
            User user = userOpt.get();
            user.setDeleted(true);
            user.setEnabled(false);
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "User deleted successfully");
            return response;
        } catch (Exception e) {
            log.error("Error deleting user: ", e);
            Map<String, String> response = new HashMap<>();
            response.put("error", "Failed to delete user: " + e.getMessage());
            return response;
        }
    }

    @Override
    public Map<String, String> resetUserPassword(String userId) {
        try {
            Optional<User> userOpt = userRepository.findById(UUID.fromString(userId));
            if (userOpt.isEmpty()) {
                Map<String, String> response = new HashMap<>();
                response.put("error", "User not found");
                return response;
            }
            
            User user = userOpt.get();
            String newPassword = "TempPass" + System.currentTimeMillis();
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Password reset successfully");
            response.put("temporaryPassword", newPassword);
            return response;
        } catch (Exception e) {
            log.error("Error resetting password: ", e);
            Map<String, String> response = new HashMap<>();
            response.put("error", "Failed to reset password: " + e.getMessage());
            return response;
        }
    }

    @Override
    public Map<String, String> toggleUserStatus(String userId) {
        try {
            Optional<User> userOpt = userRepository.findById(UUID.fromString(userId));
            if (userOpt.isEmpty()) {
                Map<String, String> response = new HashMap<>();
                response.put("error", "User not found");
                return response;
            }
            
            User user = userOpt.get();
            user.setEnabled(!user.isEnabled());
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "User status updated successfully");
            response.put("newStatus", user.isEnabled() ? "active" : "inactive");
            return response;
        } catch (Exception e) {
            log.error("Error toggling user status: ", e);
            Map<String, String> response = new HashMap<>();
            response.put("error", "Failed to toggle user status: " + e.getMessage());
            return response;
        }
    }

    @Override
    public byte[] exportSystemData(String format) {
        // Implementation for exporting system data
        // This would generate reports in PDF/Excel format
        String data = "System Export - " + LocalDateTime.now().toString();
        return data.getBytes();
    }

    // Helper methods
    private String getHODName(Department dept) {
        List<User> hodUsers = userRepository.findByDepartmentAndRoles_Name(dept, "HOD");
        return hodUsers.isEmpty() ? "Not Assigned" : hodUsers.get(0).getFullName();
    }

    private void checkOverdueForms(List<Map<String, Object>> alerts) {
        // Check for overdue forms and add alerts
        long overdueCount = appraisalFormRepository.countOverdueForms();
        if (overdueCount > 0) {
            Map<String, Object> alert = new HashMap<>();
            alert.put("id", "overdue_forms");
            alert.put("type", "warning");
            alert.put("title", "Overdue Forms");
            alert.put("message", overdueCount + " forms are overdue for review");
            alert.put("timestamp", LocalDateTime.now().toString());
            alert.put("severity", "high");
            alert.put("isResolved", false);
            alerts.add(alert);
        }
    }

    private void checkInactiveUsers(List<Map<String, Object>> alerts) {
        // Check for inactive users
        long inactiveCount = userRepository.countByEnabledFalse();
        if (inactiveCount > 0) {
            Map<String, Object> alert = new HashMap<>();
            alert.put("id", "inactive_users");
            alert.put("type", "info");
            alert.put("title", "Inactive Users");
            alert.put("message", inactiveCount + " users are currently inactive");
            alert.put("timestamp", LocalDateTime.now().toString());
            alert.put("severity", "low");
            alert.put("isResolved", false);
            alerts.add(alert);
        }
    }

    private void checkSystemResources(List<Map<String, Object>> alerts) {
        // In real implementation, check actual system resources
        // For now, just a placeholder
    }

    private String calculateSystemUptime() {
        // In real implementation, calculate actual uptime
        return "15 days, 6 hours";
    }

    private int getCurrentAverageResponseTime() {
        // In real implementation, get from monitoring service
        return 120; // milliseconds
    }

    private double getCurrentCPUUsage() {
        // In real implementation, get actual CPU usage
        return 45.2;
    }

    private double getCurrentMemoryUsage() {
        // In real implementation, get actual memory usage
        return 67.8;
    }

    private double getCurrentDiskUsage() {
        // In real implementation, get actual disk usage
        return 23.4;
    }
} 