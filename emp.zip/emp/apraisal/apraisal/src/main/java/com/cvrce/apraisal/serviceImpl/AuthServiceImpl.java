package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.auth.LoginRequestDTO;
import com.cvrce.apraisal.dto.auth.LoginResponseDTO;
import com.cvrce.apraisal.dto.user.UserCreateDTO;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.RoleRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.security.JwtTokenProvider;
import com.cvrce.apraisal.security.UserPrincipal;
import com.cvrce.apraisal.service.AuthService;
import com.cvrce.apraisal.util.PasswordGenerator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.UUID;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public LoginResponseDTO login(LoginRequestDTO request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        String token = jwtTokenProvider.generateToken(user);

        return LoginResponseDTO.builder()
                .token(token)
                .userId(user.getId().toString())
                .email(user.getEmail())
                .role(determinePrimaryRole(user.getRoles())) // FIXED: Proper multi-role handling
                .build();
    }

    @Override
    public LoginResponseDTO refreshToken(String token) {
        try {
            // Validate the token
            if (!jwtTokenProvider.validateToken(token)) {
                throw new RuntimeException("Invalid token");
            }
            
            // Extract user email from token
            String userEmail = jwtTokenProvider.getEmailFromToken(token);
            
            // Get user from database
            User user = userRepository.findByEmail(userEmail)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));
            
            // Generate new token
            String newToken = jwtTokenProvider.generateToken(user);
            
            return LoginResponseDTO.builder()
                    .token(newToken)
                    .userId(user.getId().toString())
                    .email(user.getEmail())
                    .role(determinePrimaryRole(user.getRoles()))
                    .build();
                    
        } catch (Exception e) {
            throw new RuntimeException("Failed to refresh token: " + e.getMessage());
        }
    }

    @Transactional
    @Override
    public String register(UserCreateDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("User already exists with this email");
        }

        Department department = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("Invalid department"));

        // SECURITY ENHANCEMENT: Auto-generate secure temporary password
        String temporaryPassword = dto.getPassword() != null && !dto.getPassword().trim().isEmpty() 
                ? dto.getPassword() 
                : PasswordGenerator.generateTemporaryPassword();

        // Fixed role assignment logic - use provided roles or default to STAFF
        Set<Role> userRoles;
        if (dto.getRoles() != null && !dto.getRoles().isEmpty()) {
            // Use provided roles from DTO
            userRoles = dto.getRoles().stream()
                .map(roleName -> roleRepository.findByName(roleName)
                    .orElseThrow(() -> new RuntimeException("Invalid role: " + roleName)))
                .collect(Collectors.toSet());
        } else {
            // Default to STAFF if no roles provided
            Role defaultRole = roleRepository.findByName("STAFF")
                    .orElseThrow(() -> new RuntimeException("Default role not found"));
            userRoles = Collections.singleton(defaultRole);
        }

        User user = User.builder()
                .id(UUID.randomUUID())
                .employeeId(dto.getEmployeeId())
                .fullName(dto.getFullName())
                .email(dto.getEmail())
                .password(passwordEncoder.encode(temporaryPassword))
                .enabled(true)
                .deleted(false)
                .dateOfJoining(dto.getDateOfJoining())
                .lastPromotionDate(dto.getLastPromotionDate())
                .department(department)
                .roles(userRoles)  // Use the correctly determined roles
                .build();

        userRepository.save(user);
        
        // Return the temporary password so it can be sent via email
        return temporaryPassword;
    }

    /**
     * SECURITY FIX: Determines the primary role from multiple roles based on hierarchy
     * Higher priority roles take precedence for login response
     */
    private String determinePrimaryRole(Set<Role> roles) {
        // Define role hierarchy (higher index = higher priority)
        List<String> roleHierarchy = List.of(
            "STAFF",           // Lowest priority
            "DCM", 
            "HOD", 
            "COMMITTEE", 
            "CHAIRPERSON", 
            "PRINCIPAL", 
            "ADMIN"           // Highest priority
        );
        
        // Find the highest priority role
        return roles.stream()
                .map(role -> role.getName())
                .filter(roleHierarchy::contains)
                .max((role1, role2) -> Integer.compare(
                    roleHierarchy.indexOf(role1), 
                    roleHierarchy.indexOf(role2)
                ))
                .orElse("STAFF"); // Default fallback
    }
}
