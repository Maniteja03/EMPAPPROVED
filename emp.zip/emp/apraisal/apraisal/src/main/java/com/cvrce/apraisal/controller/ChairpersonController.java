package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.service.ChairpersonService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.security.core.context.SecurityContextHolder;

@RestController
@RequestMapping("/api/chairperson")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('CHAIRPERSON')")
public class ChairpersonController {

    private final ChairpersonService chairpersonService;

    // Get Chairperson dashboard with oversight data
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getChairpersonDashboard() {
        log.info("Fetching Chairperson dashboard data");
        return ResponseEntity.ok(chairpersonService.getChairpersonDashboard());
    }

    // Get appraisals pending chairperson evaluation
    @GetMapping("/pending-evaluations")
    public ResponseEntity<Page<AppraisalFormDTO>> getPendingEvaluations(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String priority) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> pendingEvaluations = chairpersonService.getPendingEvaluations(pageable, department, priority);
        return ResponseEntity.ok(pendingEvaluations);
    }

    // Submit chairperson evaluation
    @PostMapping("/evaluation")
    public ResponseEntity<ReviewDTO> submitChairpersonEvaluation(@Valid @RequestBody ReviewDTO evaluationDTO) {
        // SECURITY FIX: Get current authenticated user email
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Chairperson submitting evaluation for appraisal: {} by authenticated user: {}", 
                evaluationDTO.getAppraisalFormId(), currentUserEmail);
        
        ReviewDTO submittedEvaluation = chairpersonService.submitChairpersonEvaluation(evaluationDTO, currentUserEmail);
        return ResponseEntity.ok(submittedEvaluation);
    }

    // Get comprehensive evaluation view with all stakeholder inputs
    @GetMapping("/evaluation-summary/{formId}")
    public ResponseEntity<Map<String, Object>> getEvaluationSummary(@PathVariable UUID formId) {
        log.info("Chairperson accessing evaluation summary for appraisal: {}", formId);
        Map<String, Object> evaluationSummary = chairpersonService.getComprehensiveEvaluationSummary(formId);
        return ResponseEntity.ok(evaluationSummary);
    }

    // Override lower-level decisions (escalation handling)
    @PostMapping("/override-decision/{formId}")
    public ResponseEntity<String> overrideDecision(
            @PathVariable UUID formId,
            @RequestParam String newDecision,
            @RequestParam String justification) {
        log.info("Chairperson overriding decision for appraisal: {} with new decision: {}", formId, newDecision);
        chairpersonService.overridePreviousDecision(formId, newDecision, justification);
        return ResponseEntity.ok("Decision successfully overridden");
    }

    // Request additional expert review
    @PostMapping("/request-expert-review/{formId}")
    public ResponseEntity<String> requestExpertReview(
            @PathVariable UUID formId,
            @RequestParam String expertArea,
            @RequestParam(required = false) String specificExpertId,
            @RequestParam String reason) {
        log.info("Chairperson requesting expert review for appraisal: {} in area: {}", formId, expertArea);
        chairpersonService.requestExpertReview(formId, expertArea, specificExpertId, reason);
        return ResponseEntity.ok("Expert review requested successfully");
    }

    // Get institutional performance overview
    @GetMapping("/institutional-overview")
    public ResponseEntity<Map<String, Object>> getInstitutionalOverview(
            @RequestParam(required = false) String academicYear,
            @RequestParam(defaultValue = "DEPARTMENT") String groupBy) {
        Map<String, Object> overview = chairpersonService.getInstitutionalPerformanceOverview(academicYear, groupBy);
        return ResponseEntity.ok(overview);
    }

    // Generate policy recommendations based on appraisal patterns
    @GetMapping("/policy-recommendations")
    public ResponseEntity<Map<String, Object>> getPolicyRecommendations(
            @RequestParam(required = false) String academicYear) {
        log.info("Generating policy recommendations for academic year: {}", academicYear);
        Map<String, Object> recommendations = chairpersonService.generatePolicyRecommendations(academicYear);
        return ResponseEntity.ok(recommendations);
    }

    // Schedule appraisal review meetings
    @PostMapping("/schedule-review-meeting")
    public ResponseEntity<String> scheduleReviewMeeting(
            @RequestBody Map<String, Object> meetingDetails) {
        log.info("Chairperson scheduling review meeting");
        chairpersonService.scheduleReviewMeeting(meetingDetails);
        return ResponseEntity.ok("Review meeting scheduled successfully");
    }

    // Generate comprehensive annual report
    @GetMapping("/annual-report")
    public ResponseEntity<byte[]> generateAnnualReport(
            @RequestParam String academicYear,
            @RequestParam(defaultValue = "PDF") String format) {
        log.info("Generating annual appraisal report for year: {}", academicYear);
        byte[] reportData = chairpersonService.generateAnnualAppraisalReport(academicYear, format);
        
        String contentType = format.equalsIgnoreCase("PDF") ? "application/pdf" : "application/vnd.ms-excel";
        String filename = "annual_appraisal_report_" + academicYear + "." + format.toLowerCase();
        
        return ResponseEntity.ok()
                .header("Content-Type", contentType)
                .header("Content-Disposition", "attachment; filename=" + filename)
                .body(reportData);
    }

    // Set evaluation criteria and weights
    @PostMapping("/set-evaluation-criteria")
    public ResponseEntity<String> setEvaluationCriteria(
            @RequestBody Map<String, Object> criteriaConfig) {
        log.info("Chairperson updating evaluation criteria configuration");
        chairpersonService.updateEvaluationCriteria(criteriaConfig);
        return ResponseEntity.ok("Evaluation criteria updated successfully");
    }

    // Monitor reviewer performance and consistency
    @GetMapping("/reviewer-performance")
    public ResponseEntity<Map<String, Object>> getReviewerPerformanceAnalysis(
            @RequestParam(required = false) String academicYear,
            @RequestParam(required = false) String reviewerRole) {
        Map<String, Object> performanceAnalysis = chairpersonService.analyzeReviewerPerformance(academicYear, reviewerRole);
        return ResponseEntity.ok(performanceAnalysis);
    }
} 