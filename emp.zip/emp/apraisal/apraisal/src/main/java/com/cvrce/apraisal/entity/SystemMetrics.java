package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "system_metrics")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class SystemMetrics {

    @Id
    @GeneratedValue
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;

    @Column(name = "metric_name", nullable = false)
    private String metricName;

    @Column(name = "metric_value", nullable = false)
    private Double metricValue;

    @Column(name = "metric_unit")
    private String metricUnit;

    @Enumerated(EnumType.STRING)
    private MetricType type;

    @Column(name = "metric_category")
    private String category;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "additional_data", columnDefinition = "TEXT")
    private String additionalData;

    @CreatedDate
    @Column(name = "recorded_at", nullable = false, updatable = false)
    private LocalDateTime recordedAt;

    public enum MetricType {
        PERFORMANCE,    // Response times, throughput, etc.
        USAGE,          // User activity, feature usage, etc.
        SYSTEM,         // Memory, CPU, disk usage, etc.
        BUSINESS,       // Appraisals processed, reviews completed, etc.
        SECURITY,       // Login attempts, failed authentications, etc.
        ERROR           // Error rates, exception counts, etc.
    }
} 