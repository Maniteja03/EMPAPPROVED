package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/system-stats")
    public ResponseEntity<Map<String, Object>> getSystemStats() {
        Map<String, Object> stats = adminService.getSystemStats();
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/department-overview")
    public ResponseEntity<List<Map<String, Object>>> getDepartmentOverview() {
        List<Map<String, Object>> departments = adminService.getDepartmentOverview();
        return ResponseEntity.ok(departments);
    }

    @GetMapping("/system-alerts")
    public ResponseEntity<List<Map<String, Object>>> getSystemAlerts() {
        List<Map<String, Object>> alerts = adminService.getSystemAlerts();
        return ResponseEntity.ok(alerts);
    }

    @GetMapping("/recent-activity")
    public ResponseEntity<List<Map<String, Object>>> getRecentActivity(@RequestParam(defaultValue = "10") int limit) {
        List<Map<String, Object>> activities = adminService.getRecentActivity(limit);
        return ResponseEntity.ok(activities);
    }

    @GetMapping("/system-health")
    public ResponseEntity<Map<String, Object>> getSystemHealth() {
        Map<String, Object> health = adminService.getSystemHealth();
        return ResponseEntity.ok(health);
    }

    @PostMapping("/users")
    public ResponseEntity<Map<String, String>> createUser(@RequestBody Map<String, Object> userData) {
        Map<String, String> response = adminService.createUser(userData);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/users")
    public ResponseEntity<List<Map<String, Object>>> getUsers(@RequestParam(defaultValue = "0") int page,
                                                              @RequestParam(defaultValue = "10") int size) {
        List<Map<String, Object>> users = adminService.getUsers(page, size);
        return ResponseEntity.ok(users);
    }

    @PutMapping("/users/{userId}")
    public ResponseEntity<Map<String, String>> updateUser(@PathVariable String userId, 
                                                           @RequestBody Map<String, Object> userData) {
        Map<String, String> response = adminService.updateUser(userId, userData);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable String userId) {
        Map<String, String> response = adminService.deleteUser(userId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/users/{userId}/reset-password")
    public ResponseEntity<Map<String, String>> resetUserPassword(@PathVariable String userId) {
        Map<String, String> response = adminService.resetUserPassword(userId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/users/{userId}/toggle-status")
    public ResponseEntity<Map<String, String>> toggleUserStatus(@PathVariable String userId) {
        Map<String, String> response = adminService.toggleUserStatus(userId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/export/{format}")
    public ResponseEntity<byte[]> exportSystemData(@PathVariable String format) {
        byte[] data = adminService.exportSystemData(format);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=system-data." + format)
                .body(data);
    }
} 