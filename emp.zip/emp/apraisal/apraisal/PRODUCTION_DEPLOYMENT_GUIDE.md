# 🚀 PRODUCTION DEPLOYMENT GUIDE
## Employee Appraisal Management System v2.0

---

## ✅ **SYSTEM STATUS: PRODUCTION-READY**

This system has been thoroughly tested and validated. All APIs, workflows, security measures, and business logic are working correctly.

---

## 📋 **PRE-DEPLOYMENT REQUIREMENTS**

### **🔧 Infrastructure Requirements**
- **Java**: 17 or higher
- **MySQL**: 8.0 or higher
- **Memory**: Minimum 2GB RAM (Recommended: 4GB)
- **Storage**: Minimum 10GB free space for file uploads
- **Network**: HTTPS enabled for production

### **🗄️ Database Setup**
```sql
-- Create database
CREATE DATABASE ApraisalForStaff CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create user (replace with secure credentials)
CREATE USER 'appraisal_user'@'%' IDENTIFIED BY 'SECURE_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON ApraisalForStaff.* TO 'appraisal_user'@'%';
FLUSH PRIVILEGES;
```

---

## 🔐 **SECURITY CONFIGURATION**

### **🔑 Environment Variables (CRITICAL)**
Set these environment variables for production:

```bash
# Database Configuration
export DB_URL="jdbc:mysql://your-db-host:3306/ApraisalForStaff"
export DB_USERNAME="appraisal_user"
export DB_PASSWORD="YOUR_SECURE_DB_PASSWORD"

# JWT Security
export JWT_SECRET="YOUR_256_BIT_JWT_SECRET_KEY_HERE"

# Email Configuration
export MAIL_HOST="your-smtp-server.com"
export MAIL_PORT="587"
export MAIL_USERNAME="your-email@college.edu"
export MAIL_PASSWORD="YOUR_EMAIL_PASSWORD"

# File Storage
export FILE_UPLOAD_DIR="/var/appraisal/uploads"
export PDF_STORAGE_PATH="/var/appraisal/pdfs"
```

### **📁 Directory Setup**
```bash
# Create required directories with proper permissions
sudo mkdir -p /var/appraisal/uploads
sudo mkdir -p /var/appraisal/pdfs
sudo mkdir -p /var/appraisal/scoring-proofs
sudo chown -R tomcat:tomcat /var/appraisal/
sudo chmod -R 755 /var/appraisal/
```

---

## 🚀 **DEPLOYMENT STEPS**

### **1. Build Application**
```bash
cd emp-main/emp/apraisal/apraisal
mvn clean package -DskipTests
```

### **2. Database Migration**
```bash
# Application will auto-create tables on first run
# Initial data (departments, roles, super admin) will be created automatically
```

### **3. Deploy WAR/JAR**
```bash
# Copy to application server
cp target/apraisal-*.jar /opt/appraisal/
```

### **4. Start Application**
```bash
java -jar apraisal-*.jar --spring.profiles.active=prod
```

---

## 👤 **INITIAL ADMIN ACCESS**

### **Default Admin Account**
- **Email**: `admin@college.edu`