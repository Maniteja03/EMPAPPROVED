#!/bin/bash

# =============================================================================
# APPRAISAL SYSTEM BACKUP & DISASTER RECOVERY SCRIPT
# Optimized for Mumbai Region (ap-south-1)
# =============================================================================

set -e

# Configuration
BACKUP_DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_RETENTION_DAYS=30
S3_BACKUP_BUCKET="appraisal-backups-mumbai"
AWS_REGION="ap-south-1"
MYSQL_MASTER_HOST="mysql-master"
MYSQL_USER="root"
MYSQL_PASSWORD="${MYSQL_ROOT_PASSWORD:-SecureRootPass123!}"
DATABASE_NAME="ApraisalForStaff"

# Logging
LOG_FILE="/var/log/appraisal/backup_${BACKUP_DATE}.log"
mkdir -p /var/log/appraisal

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# =============================================================================
# DATABASE BACKUP
# =============================================================================
backup_database() {
    log "Starting database backup..."
    
    BACKUP_FILE="database_backup_${BACKUP_DATE}.sql.gz"
    
    # Create compressed database dump
    mysqldump -h "$MYSQL_MASTER_HOST" -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" \
        --single-transaction \
        --routines \
        --triggers \
        --events \
        --quick \
        --lock-tables=false \
        "$DATABASE_NAME" | gzip > "/tmp/$BACKUP_FILE"
    
    # Upload to S3 Mumbai region
    aws s3 cp "/tmp/$BACKUP_FILE" "s3://$S3_BACKUP_BUCKET/database/" \
        --region "$AWS_REGION" \
        --storage-class STANDARD_IA
    
    # Cleanup local file
    rm "/tmp/$BACKUP_FILE"
    
    log "Database backup completed: $BACKUP_FILE"
}

# =============================================================================
# APPLICATION FILES BACKUP
# =============================================================================
backup_application_files() {
    log "Starting application files backup..."
    
    BACKUP_FILE="app_files_backup_${BACKUP_DATE}.tar.gz"
    
    # Create compressed archive of application files
    tar -czf "/tmp/$BACKUP_FILE" \
        -C /app \
        --exclude='*.log' \
        --exclude='temp/*' \
        --exclude='target/*' \
        .
    
    # Upload to S3
    aws s3 cp "/tmp/$BACKUP_FILE" "s3://$S3_BACKUP_BUCKET/application/" \
        --region "$AWS_REGION" \
        --storage-class STANDARD_IA
    
    # Cleanup local file
    rm "/tmp/$BACKUP_FILE"
    
    log "Application files backup completed: $BACKUP_FILE"
}

# =============================================================================
# CONFIGURATION BACKUP
# =============================================================================
backup_configurations() {
    log "Starting configuration backup..."
    
    BACKUP_FILE="config_backup_${BACKUP_DATE}.tar.gz"
    
    # Create archive of configuration files
    tar -czf "/tmp/$BACKUP_FILE" \
        /app/src/main/resources/application*.properties \
        /app/docker-compose.yml \
        /app/nginx/nginx.conf \
        /app/kubernetes/ \
        /app/monitoring/ \
        2>/dev/null || true
    
    # Upload to S3
    aws s3 cp "/tmp/$BACKUP_FILE" "s3://$S3_BACKUP_BUCKET/configurations/" \
        --region "$AWS_REGION" \
        --storage-class STANDARD_IA
    
    # Cleanup local file
    rm "/tmp/$BACKUP_FILE"
    
    log "Configuration backup completed: $BACKUP_FILE"
}

# =============================================================================
# REDIS DATA BACKUP
# =============================================================================
backup_redis_data() {
    log "Starting Redis data backup..."
    
    # Backup each Redis cluster node
    for i in 1 2 3; do
        BACKUP_FILE="redis_cluster_${i}_backup_${BACKUP_DATE}.rdb"
        
        # Create Redis backup
        redis-cli -h "redis-cluster-${i}" -p 6379 \
            --rdb "/tmp/$BACKUP_FILE" \
            2>/dev/null || log "Warning: Could not backup redis-cluster-${i}"
        
        if [ -f "/tmp/$BACKUP_FILE" ]; then
            # Upload to S3
            aws s3 cp "/tmp/$BACKUP_FILE" "s3://$S3_BACKUP_BUCKET/redis/" \
                --region "$AWS_REGION" \
                --storage-class STANDARD_IA
            
            # Cleanup local file
            rm "/tmp/$BACKUP_FILE"
            
            log "Redis cluster-${i} backup completed"
        fi
    done
}

# =============================================================================
# CLEANUP OLD BACKUPS
# =============================================================================
cleanup_old_backups() {
    log "Cleaning up old backups (older than $BACKUP_RETENTION_DAYS days)..."
    
    # Calculate cutoff date
    CUTOFF_DATE=$(date -d "$BACKUP_RETENTION_DAYS days ago" +%Y%m%d)
    
    # List and delete old backups from S3
    for prefix in "database/" "application/" "configurations/" "redis/"; do
        aws s3 ls "s3://$S3_BACKUP_BUCKET/$prefix" --region "$AWS_REGION" | \
        while read -r line; do
            file_date=$(echo "$line" | awk '{print $4}' | grep -o '[0-9]\{8\}' | head -1)
            if [[ "$file_date" < "$CUTOFF_DATE" ]]; then
                file_name=$(echo "$line" | awk '{print $4}')
                aws s3 rm "s3://$S3_BACKUP_BUCKET/$prefix$file_name" --region "$AWS_REGION"
                log "Deleted old backup: $file_name"
            fi
        done
    done
}

# =============================================================================
# DISASTER RECOVERY TEST
# =============================================================================
test_backup_integrity() {
    log "Testing backup integrity..."
    
    # Test latest database backup
    LATEST_DB_BACKUP=$(aws s3 ls "s3://$S3_BACKUP_BUCKET/database/" --region "$AWS_REGION" | \
                       sort | tail -n 1 | awk '{print $4}')
    
    if [ -n "$LATEST_DB_BACKUP" ]; then
        # Download and test database backup
        aws s3 cp "s3://$S3_BACKUP_BUCKET/database/$LATEST_DB_BACKUP" "/tmp/test_backup.sql.gz" \
            --region "$AWS_REGION"
        
        # Test if backup can be extracted
        if gunzip -t "/tmp/test_backup.sql.gz" 2>/dev/null; then
            log "Database backup integrity test: PASSED"
        else
            log "ERROR: Database backup integrity test: FAILED"
        fi
        
        rm -f "/tmp/test_backup.sql.gz"
    fi
}

# =============================================================================
# MONITORING INTEGRATION
# =============================================================================
send_backup_metrics() {
    # Send metrics to monitoring system
    BACKUP_SIZE=$(aws s3 ls "s3://$S3_BACKUP_BUCKET/" --recursive --region "$AWS_REGION" | \
                  awk 'BEGIN{sum=0}{sum+=$3}END{print sum}')
    
    # Send to Prometheus pushgateway (if available)
    if command -v curl >/dev/null 2>&1; then
        curl -X POST http://prometheus-pushgateway:9091/metrics/job/backup_job/instance/$(hostname) \
             --data "backup_size_bytes $BACKUP_SIZE" \
             --data "backup_timestamp $(date +%s)" \
             2>/dev/null || true
    fi
    
    log "Backup metrics sent - Total size: $BACKUP_SIZE bytes"
}

# =============================================================================
# MAIN EXECUTION
# =============================================================================
main() {
    log "=== Starting Appraisal System Backup ==="
    log "Backup ID: $BACKUP_DATE"
    log "Target Region: $AWS_REGION"
    
    # Check AWS CLI availability
    if ! command -v aws >/dev/null 2>&1; then
        log "ERROR: AWS CLI not found. Please install AWS CLI."
        exit 1
    fi
    
    # Check S3 bucket accessibility
    if ! aws s3 ls "s3://$S3_BACKUP_BUCKET" --region "$AWS_REGION" >/dev/null 2>&1; then
        log "ERROR: Cannot access S3 backup bucket: $S3_BACKUP_BUCKET"
        exit 1
    fi
    
    # Execute backup procedures
    backup_database
    backup_application_files
    backup_configurations
    backup_redis_data
    
    # Maintenance tasks
    cleanup_old_backups
    test_backup_integrity
    send_backup_metrics
    
    log "=== Backup Process Completed Successfully ==="
    log "Log file: $LOG_FILE"
}

# =============================================================================
# DISASTER RECOVERY FUNCTION
# =============================================================================
disaster_recovery() {
    if [ "$1" = "restore" ]; then
        log "=== Starting Disaster Recovery ==="
        
        # Restore database
        if [ -n "$2" ]; then
            RESTORE_FILE="$2"
        else
            # Get latest backup
            RESTORE_FILE=$(aws s3 ls "s3://$S3_BACKUP_BUCKET/database/" --region "$AWS_REGION" | \
                          sort | tail -n 1 | awk '{print $4}')
        fi
        
        if [ -n "$RESTORE_FILE" ]; then
            log "Restoring database from: $RESTORE_FILE"
            
            # Download backup
            aws s3 cp "s3://$S3_BACKUP_BUCKET/database/$RESTORE_FILE" "/tmp/restore.sql.gz" \
                --region "$AWS_REGION"
            
            # Restore database
            gunzip -c "/tmp/restore.sql.gz" | \
            mysql -h "$MYSQL_MASTER_HOST" -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" "$DATABASE_NAME"
            
            rm "/tmp/restore.sql.gz"
            log "Database restoration completed"
        else
            log "ERROR: No backup file found for restoration"
            exit 1
        fi
    fi
}

# Handle command line arguments
case "$1" in
    "backup")
        main
        ;;
    "restore")
        disaster_recovery "restore" "$2"
        ;;
    "test")
        test_backup_integrity
        ;;
    *)
        echo "Usage: $0 {backup|restore [backup_file]|test}"
        echo "Examples:"
        echo "  $0 backup                           # Full backup"
        echo "  $0 restore                          # Restore from latest backup"
        echo "  $0 restore database_backup_file.sql.gz  # Restore from specific backup"
        echo "  $0 test                            # Test backup integrity"
        exit 1
        ;;
esac 