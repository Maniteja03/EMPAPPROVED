package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.timeline.AppraisalTimelineDTO;

import java.util.UUID;

public interface DeadlineEnforcementService {
    
    /**
     * Check if staff upload is allowed for academic year
     * @param academicYear The academic year
     * @return true if staff can currently upload appraisals
     */
    boolean isStaffUploadAllowed(String academicYear);
    
    /**
     * Check if HOD DCM assignment is allowed for academic year
     * @param academicYear The academic year
     * @return true if HODs can currently assign DCMs
     */
    boolean isHodDcmAssignmentAllowed(String academicYear);
    
    /**
     * Check if DCM review is allowed for academic year
     * @param academicYear The academic year
     * @return true if DCMs can currently review forms
     */
    boolean isDcmReviewAllowed(String academicYear);
    
    /**
     * Check if HOD review is allowed for academic year
     * @param academicYear The academic year
     * @return true if HODs can currently review forms
     */
    boolean isHodReviewAllowed(String academicYear);
    
    /**
     * Check if committee review is allowed for academic year
     * @param academicYear The academic year
     * @return true if committee can currently review forms
     */
    boolean isCommitteeReviewAllowed(String academicYear);
    
    /**
     * Check if chairperson review is allowed for academic year
     * @param academicYear The academic year
     * @return true if chairperson can currently review forms
     */
    boolean isChairpersonReviewAllowed(String academicYear);
    
    /**
     * Check if principal review is allowed for academic year
     * @param academicYear The academic year
     * @return true if principal can currently review forms
     */
    boolean isPrincipalReviewAllowed(String academicYear);
    
    /**
     * Get deadline enforcement message for action
     * @param academicYear The academic year
     * @param action The action being attempted
     * @return Enforcement message (error or warning)
     */
    String getDeadlineEnforcementMessage(String academicYear, String action);
    
    /**
     * Validate form submission against timeline
     * @param formId The form being submitted
     * @param academicYear The academic year
     * @param action The submission action
     * @throws DeadlineViolationException if submission violates timeline
     */
    void validateFormSubmissionDeadline(UUID formId, String academicYear, String action);
    
    /**
     * Get active timeline for academic year
     * @param academicYear The academic year
     * @return Active timeline if exists
     */
    AppraisalTimelineDTO getActiveTimeline(String academicYear);
    
    /**
     * Check if any deadline is approaching (for warnings)
     * @param academicYear The academic year
     * @param daysAhead Number of days to check ahead
     * @return true if deadline is approaching
     */
    boolean isDeadlineApproaching(String academicYear, int daysAhead);
    
    /**
     * Force allow action (admin override)
     * @param academicYear The academic year
     * @param action The action to force allow
     * @param adminEmail Admin performing override
     * @param reason Reason for override
     * @return true if override was applied
     */
    boolean forceAllowAction(String academicYear, String action, String adminEmail, String reason);
    
    /**
     * Get current phase for academic year
     * @param academicYear The academic year
     * @return Current active phase
     */
    String getCurrentPhase(String academicYear);
    
    /**
     * Get days remaining for current phase
     * @param academicYear The academic year
     * @return Days remaining in current phase
     */
    long getDaysRemainingForCurrentPhase(String academicYear);
}

/**
 * Exception thrown when deadline is violated
 */
class DeadlineViolationException extends RuntimeException {
    private final String academicYear;
    private final String action;
    private final String currentPhase;
    
    public DeadlineViolationException(String message, String academicYear, String action, String currentPhase) {
        super(message);
        this.academicYear = academicYear;
        this.action = action;
        this.currentPhase = currentPhase;
    }
    
    public String getAcademicYear() { return academicYear; }
    public String getAction() { return action; }
    public String getCurrentPhase() { return currentPhase; }
} 