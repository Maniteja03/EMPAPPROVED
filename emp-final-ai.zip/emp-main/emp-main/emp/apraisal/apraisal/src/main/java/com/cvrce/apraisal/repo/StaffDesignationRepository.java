package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.StaffDesignation;
import com.cvrce.apraisal.entity.DesignationType;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface StaffDesignationRepository extends JpaRepository<StaffDesignation, UUID> {
    
    // Find current designation for a user
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.user = :user AND sd.isCurrentDesignation = true")
    Optional<StaffDesignation> findCurrentDesignationByUser(@Param("user") User user);
    
    // Find designation active on a specific date
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.user = :user " +
           "AND sd.effectiveFromDate <= :date " +
           "AND (sd.effectiveToDate IS NULL OR sd.effectiveToDate >= :date)")
    Optional<StaffDesignation> findDesignationByUserAndDate(@Param("user") User user, @Param("date") LocalDate date);
    
    // Find all designations for a user ordered by effective date
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.user = :user ORDER BY sd.effectiveFromDate DESC")
    List<StaffDesignation> findAllDesignationsByUser(@Param("user") User user);
    
    // Find users by designation type
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.designationType = :designationType AND sd.isCurrentDesignation = true")
    List<StaffDesignation> findUsersByCurrentDesignationType(@Param("designationType") DesignationType designationType);
    
    // Find users by designation group
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.isCurrentDesignation = true " +
           "AND sd.designationType IN :designationTypes")
    List<StaffDesignation> findUsersByDesignationGroup(@Param("designationTypes") List<DesignationType> designationTypes);
    
    // Find designations by academic year
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.academicYear = :academicYear")
    List<StaffDesignation> findByAcademicYear(@Param("academicYear") String academicYear);
    
    // Find designations that need to be ended (promotion cases)
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.isCurrentDesignation = true " +
           "AND sd.user IN :users")
    List<StaffDesignation> findCurrentDesignationsForUsers(@Param("users") List<User> users);
    
    // End current designation for user
    @Modifying
    @Query("UPDATE StaffDesignation sd SET sd.isCurrentDesignation = false, sd.effectiveToDate = :endDate " +
           "WHERE sd.user = :user AND sd.isCurrentDesignation = true")
    int endCurrentDesignation(@Param("user") User user, @Param("endDate") LocalDate endDate);
    
    // Get designation statistics
    @Query("SELECT sd.designationType, COUNT(sd) FROM StaffDesignation sd " +
           "WHERE sd.isCurrentDesignation = true GROUP BY sd.designationType")
    List<Object[]> getDesignationStatistics();
    
    // Find designations by department
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.user.department.id = :departmentId " +
           "AND sd.isCurrentDesignation = true")
    List<StaffDesignation> findCurrentDesignationsByDepartment(@Param("departmentId") UUID departmentId);
    
    // Check if user has designation in academic year
    @Query("SELECT COUNT(sd) > 0 FROM StaffDesignation sd WHERE sd.user = :user " +
           "AND sd.academicYear = :academicYear")
    boolean hasDesignationInAcademicYear(@Param("user") User user, @Param("academicYear") String academicYear);
    
    // Find users eligible for promotion (based on years in current designation)
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.isCurrentDesignation = true " +
           "AND sd.effectiveFromDate <= :thresholdDate")
    List<StaffDesignation> findUsersEligibleForPromotion(@Param("thresholdDate") LocalDate thresholdDate);
    
    // Paginated search
    @Query("SELECT sd FROM StaffDesignation sd WHERE sd.isCurrentDesignation = true " +
           "AND (LOWER(sd.user.fullName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
           "OR LOWER(sd.user.employeeId) LIKE LOWER(CONCAT('%', :searchTerm, '%')))")
    Page<StaffDesignation> findCurrentDesignationsWithSearch(@Param("searchTerm") String searchTerm, Pageable pageable);
} 