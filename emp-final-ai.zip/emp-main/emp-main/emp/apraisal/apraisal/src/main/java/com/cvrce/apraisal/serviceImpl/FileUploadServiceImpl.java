package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.service.FileUploadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileUploadServiceImpl implements FileUploadService {
    
    @Value("${app.file.upload.dir:uploads}")
    private String uploadDir;
    
    @Value("${app.file.max-size:10485760}") // 10MB default
    private long maxFileSize;
    
    private static final List<String> ALLOWED_FILE_TYPES = Arrays.asList(
            "pdf", "doc", "docx", "jpg", "jpeg", "png", "gif", "xlsx", "xls"
    );
    
    @Override
    public String uploadProofDocument(MultipartFile file, UUID appraisalFormId, String componentType, String componentId) {
        try {
            // Validate file
            Map<String, Object> validation = validateFile(file);
            if (!(Boolean) validation.get("isValid")) {
                throw new IllegalArgumentException("File validation failed: " + validation.get("errors"));
            }
            
            // Create directory structure
            String directoryPath = String.format("%s/%s/%s/%s", 
                    uploadDir, appraisalFormId, componentType, componentId);
            Path directory = Paths.get(directoryPath);
            Files.createDirectories(directory);
            
            // Generate unique filename
            String originalFilename = file.getOriginalFilename();
            String extension = getFileExtension(originalFilename);
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String filename = String.format("%s_%s.%s", componentType, timestamp, extension);
            
            // Save file
            Path filePath = directory.resolve(filename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            
            String relativePath = String.format("%s/%s/%s/%s", 
                    appraisalFormId, componentType, componentId, filename);
            
            log.info("Uploaded proof document: {} for appraisal: {}, component: {}", 
                    filename, appraisalFormId, componentType);
            
            return relativePath;
            
        } catch (IOException e) {
            log.error("Error uploading file for appraisal: {}, component: {}", appraisalFormId, componentType, e);
            throw new RuntimeException("Failed to upload file", e);
        }
    }
    
    @Override
    public List<String> uploadMultipleProofDocuments(List<MultipartFile> files, UUID appraisalFormId, String componentType) {
        List<String> uploadedFiles = new ArrayList<>();
        
        for (int i = 0; i < files.size(); i++) {
            MultipartFile file = files.get(i);
            String componentId = String.format("item_%d", i + 1);
            String filePath = uploadProofDocument(file, appraisalFormId, componentType, componentId);
            uploadedFiles.add(filePath);
        }
        
        return uploadedFiles;
    }
    
    @Override
    public boolean deleteProofDocument(String filePath) {
        try {
            Path path = Paths.get(uploadDir, filePath);
            boolean deleted = Files.deleteIfExists(path);
            
            if (deleted) {
                log.info("Deleted proof document: {}", filePath);
            } else {
                log.warn("Proof document not found for deletion: {}", filePath);
            }
            
            return deleted;
            
        } catch (IOException e) {
            log.error("Error deleting file: {}", filePath, e);
            return false;
        }
    }
    
    @Override
    public String getProofDocumentUrl(String filePath) {
        // Return URL for accessing the file
        return "/api/files/" + filePath;
    }
    
    @Override
    public Map<String, Object> validateFile(MultipartFile file) {
        Map<String, Object> result = new HashMap<>();
        List<String> errors = new ArrayList<>();
        
        // Check if file is empty
        if (file.isEmpty()) {
            errors.add("File is empty");
        }
        
        // Check file size
        if (file.getSize() > maxFileSize) {
            errors.add("File size exceeds maximum allowed size of " + (maxFileSize / 1024 / 1024) + "MB");
        }
        
        // Check file type
        String filename = file.getOriginalFilename();
        if (filename == null || filename.trim().isEmpty()) {
            errors.add("Invalid filename");
        } else {
            String extension = getFileExtension(filename).toLowerCase();
            if (!ALLOWED_FILE_TYPES.contains(extension)) {
                errors.add("File type not allowed. Allowed types: " + String.join(", ", ALLOWED_FILE_TYPES));
            }
        }
        
        result.put("isValid", errors.isEmpty());
        result.put("errors", errors);
        result.put("fileSize", file.getSize());
        result.put("fileName", filename);
        result.put("fileType", file.getContentType());
        
        return result;
    }
    
    @Override
    public List<String> getAllowedFileTypes() {
        return new ArrayList<>(ALLOWED_FILE_TYPES);
    }
    
    @Override
    public long getMaxFileSize() {
        return maxFileSize;
    }
    
    @Override
    public void cleanupOrphanedFiles() {
        // Implementation for cleaning up orphaned files
        // This would typically run as a scheduled task
        log.info("Starting cleanup of orphaned files");
        
        try {
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                return;
            }
            
            // Logic to identify and clean up orphaned files
            // This would involve checking database references
            
            log.info("Completed cleanup of orphaned files");
            
        } catch (Exception e) {
            log.error("Error during orphaned files cleanup", e);
        }
    }
    
    private String getFileExtension(String filename) {
        if (filename == null || filename.lastIndexOf('.') == -1) {
            return "";
        }
        return filename.substring(filename.lastIndexOf('.') + 1);
    }
}
