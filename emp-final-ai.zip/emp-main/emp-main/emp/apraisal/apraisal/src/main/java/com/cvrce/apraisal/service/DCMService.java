package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.FormLock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Service for Department Coordination Members (DCM) to manage and review appraisal forms
 */
public interface DCMService {
    
    /**
     * Get DCM dashboard with statistics and assigned forms
     * @return Dashboard data including assigned, completed, and pending reviews
     */
    Map<String, Object> getDCMDashboard();
    
    /**
     * Get forms assigned to current DCM for review
     * @param pageable Pagination information
     * @return Page of forms assigned to this DCM
     */
    Page<AppraisalFormDTO> getAssignedReviews(Pageable pageable);
    
    /**
     * Start reviewing a form (attempt to lock it) - NEW METHOD
     * @param formId The form ID to review
     * @param dcmEmail The DCM's email
     * @return FormLock if successful, empty if form is already locked
     */
    Optional<FormLock> startFormReview(UUID formId, String dcmEmail);
    
    /**
     * Get form details for DCM review (with lock check) - NEW METHOD
     * @param formId The form ID
     * @param dcmEmail The DCM's email
     * @return Form details if accessible and locked by this DCM
     */
    AppraisalFormDTO getFormForReview(UUID formId, String dcmEmail);
    
    /**
     * Submit initial DCM review for a form
     * @param reviewDTO Review details including decision and remarks
     * @param currentUserEmail Current authenticated DCM email
     * @return Submitted review
     */
    ReviewDTO submitInitialReview(ReviewDTO reviewDTO, String currentUserEmail);
    
    /**
     * Cancel form review and release lock - NEW METHOD
     * @param formId The form ID
     * @param dcmEmail The DCM's email
     * @return true if lock was released
     */
    boolean cancelFormReview(UUID formId, String dcmEmail);
    
    /**
     * Get forms currently locked by this DCM - NEW METHOD
     * @param dcmEmail The DCM's email
     * @return List of forms currently being reviewed by this DCM
     */
    List<AppraisalFormDTO> getMyActiveReviews(String dcmEmail);
    
    /**
     * Get specific appraisal form for DCM review
     * @param formId Form ID to retrieve
     * @return Appraisal form details
     */
    AppraisalFormDTO getAppraisalForDCMReview(UUID formId);
    
    /**
     * Get DCM statistics for specific academic year
     * @param academicYear Academic year filter
     * @return Statistics including assigned, reviewed, and pending forms
     */
    Map<String, Object> getDCMStatistics(String academicYear);
    
    /**
     * Request reassignment of a form to another DCM
     * @param formId Form ID to reassign
     * @param reason Reason for reassignment request
     */
    void requestReassignment(UUID formId, String reason);
} 