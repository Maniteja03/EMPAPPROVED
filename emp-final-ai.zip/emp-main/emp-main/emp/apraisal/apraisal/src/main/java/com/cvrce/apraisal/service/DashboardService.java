package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.DashboardSummaryDTO;

public interface DashboardService {
    DashboardSummaryDTO getDashboardSummary();
}
