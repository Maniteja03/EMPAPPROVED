package com.cvrce.apraisal.enums;

public enum ReviewDecision {
    APPROVED,
    REJECTED,
    FORWARD
}