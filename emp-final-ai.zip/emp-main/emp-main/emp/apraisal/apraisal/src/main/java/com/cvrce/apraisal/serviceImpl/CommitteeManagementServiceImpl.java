package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.committee.CommitteeAssignmentDTO;
import com.cvrce.apraisal.dto.committee.CommitteeSelectionDTO;
import com.cvrce.apraisal.dto.committee.CommitteeWorkloadStats;
import com.cvrce.apraisal.entity.CommitteeAssignment;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.service.CommitteeManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CommitteeManagementServiceImpl implements CommitteeManagementService {
    
    private final CommitteeAssignmentRepository committeeAssignmentRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final DCMAssignmentRepository dcmAssignmentRepository;
    
    private static final int MAX_WORKLOAD_PER_MEMBER = 15; // Maximum forms per committee member
    private static final Random random = new Random();
    
    @Override
    @Transactional
    public List<CommitteeAssignmentDTO> selectRandomCommitteeMembers(String academicYear, int membersPerDepartment) {
        log.info("Starting random committee member selection for {} with {} members per department", 
                academicYear, membersPerDepartment);
        
        // Deactivate existing committee assignments for the year
        committeeAssignmentRepository.deactivateAllCommitteeAssignmentsForYear(academicYear);
        
        // Get all departments
        List<Department> departments = departmentRepository.findAllByOrderByNameAsc();
        
        List<CommitteeAssignment> newAssignments = new ArrayList<>();
        
        for (Department department : departments) {
            log.info("Selecting committee members from {} department", department.getName());
            
            // Get eligible staff from this department
            List<User> eligibleStaff = getEligibleStaffFromDepartment(department, academicYear);
            
            if (eligibleStaff.size() < membersPerDepartment) {
                log.warn("Department {} has only {} eligible staff for committee selection, requested {}", 
                        department.getName(), eligibleStaff.size(), membersPerDepartment);
            }
            
            // Randomly select members
            int membersToSelect = Math.min(membersPerDepartment, eligibleStaff.size());
            List<User> selectedMembers = selectRandomMembers(eligibleStaff, membersToSelect);
            
            // Create committee assignments
            for (User selectedMember : selectedMembers) {
                CommitteeAssignment assignment = CommitteeAssignment.builder()
                        .committeeMember(selectedMember)
                        .department(department)
                        .academicYear(academicYear)
                        .isActive(true)
                        .assignedAt(LocalDateTime.now())
                        .selectionMethod("RANDOM")
                        .workloadCount(0)
                        .completedReviews(0)
                        .build();
                
                CommitteeAssignment saved = committeeAssignmentRepository.save(assignment);
                newAssignments.add(saved);
                
                log.info("Selected {} from {} department as committee member for {}", 
                        selectedMember.getFullName(), department.getName(), academicYear);
            }
        }
        
        log.info("Completed random committee selection: {} members selected across {} departments", 
                newAssignments.size(), departments.size());
        
        return newAssignments.stream()
                .map(this::createCommitteeAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<CommitteeAssignmentDTO> getCurrentCommitteeMembers(String academicYear) {
        List<CommitteeAssignment> assignments = committeeAssignmentRepository
                .findActiveCommitteeMembersForYear(academicYear);
        
        return assignments.stream()
                .map(this::createCommitteeAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<CommitteeSelectionDTO> getEligibleStaffForCommittee(String academicYear) {
        List<Department> departments = departmentRepository.findAllByOrderByNameAsc();
        List<CommitteeSelectionDTO> allEligibleStaff = new ArrayList<>();
        
        // Get current committee members
        List<CommitteeAssignment> currentCommitteeMembers = committeeAssignmentRepository
                .findActiveCommitteeMembersForYear(academicYear);
        Set<UUID> currentCommitteeIds = currentCommitteeMembers.stream()
                .map(ca -> ca.getCommitteeMember().getId())
                .collect(Collectors.toSet());
        
        for (Department department : departments) {
            List<User> departmentStaff = getEligibleStaffFromDepartment(department, academicYear);
            
            for (User staff : departmentStaff) {
                CommitteeSelectionDTO dto = createCommitteeSelectionDTO(staff, 
                        currentCommitteeIds.contains(staff.getId()), academicYear);
                allEligibleStaff.add(dto);
            }
        }
        
        return allEligibleStaff;
    }
    
    @Override
    @Transactional
    public List<CommitteeAssignmentDTO> assignCommitteeMembers(List<UUID> staffIds, String academicYear) {
        log.info("Manually assigning {} staff members as committee members for {}", 
                staffIds.size(), academicYear);
        
        List<CommitteeAssignment> newAssignments = new ArrayList<>();
        
        for (UUID staffId : staffIds) {
            User staff = userRepository.findById(staffId)
                    .orElseThrow(() -> new ResourceNotFoundException("Staff member not found: " + staffId));
            
            // Check if already a committee member
            if (committeeAssignmentRepository.isUserCommitteeMember(staff, academicYear)) {
                log.warn("Staff member {} is already a committee member for {}", 
                        staff.getFullName(), academicYear);
                continue;
            }
            
            CommitteeAssignment assignment = CommitteeAssignment.builder()
                    .committeeMember(staff)
                    .department(staff.getDepartment())
                    .academicYear(academicYear)
                    .isActive(true)
                    .assignedAt(LocalDateTime.now())
                    .selectionMethod("MANUAL")
                    .workloadCount(0)
                    .completedReviews(0)
                    .build();
            
            CommitteeAssignment saved = committeeAssignmentRepository.save(assignment);
            newAssignments.add(saved);
            
            log.info("Manually assigned {} from {} as committee member for {}", 
                    staff.getFullName(), staff.getDepartment().getName(), academicYear);
        }
        
        return newAssignments.stream()
                .map(this::createCommitteeAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public boolean removeCommitteeMemberAssignment(UUID assignmentId) {
        CommitteeAssignment assignment = committeeAssignmentRepository.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Committee assignment not found: " + assignmentId));
        
        assignment.deactivate();
        committeeAssignmentRepository.save(assignment);
        
        log.info("Removed committee assignment for {} from {} department", 
                assignment.getCommitteeMember().getFullName(), 
                assignment.getDepartment().getName());
        
        return true;
    }
    
    @Override
    @Transactional
    public List<CommitteeAssignmentDTO> reselectionCommitteeMembers(String academicYear, int membersPerDepartment) {
        log.info("Re-selecting committee members for {} with {} members per department", 
                academicYear, membersPerDepartment);
        
        return selectRandomCommitteeMembers(academicYear, membersPerDepartment);
    }
    
    @Override
    public boolean isUserCommitteeMember(User user, String academicYear) {
        return committeeAssignmentRepository.isUserCommitteeMember(user, academicYear);
    }
    
    @Override
    public CommitteeAssignmentDTO getAvailableCommitteeMemberForAssignment(String academicYear, String excludeDepartment) {
        // Find department by name
        Department excludeDept = departmentRepository.findByName(excludeDepartment)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found: " + excludeDepartment));
        
        // Get available committee members (excluding own department, with workload capacity)
        List<CommitteeAssignment> availableMembers = committeeAssignmentRepository
                .findAvailableCommitteeMembersExcludingDepartment(academicYear, excludeDept, MAX_WORKLOAD_PER_MEMBER);
        
        if (availableMembers.isEmpty()) {
            log.warn("No available committee members for assignment (excluding {} department)", excludeDepartment);
            return null;
        }
        
        // Get member with lowest workload (first in the ordered list)
        CommitteeAssignment selectedMember = availableMembers.get(0);
        
        log.info("Selected committee member {} (workload: {}) for form assignment", 
                selectedMember.getCommitteeMember().getFullName(), selectedMember.getWorkloadCount());
        
        return createCommitteeAssignmentDTO(selectedMember);
    }
    
    @Override
    @Transactional
    public void assignFormToCommitteeMember(UUID assignmentId, UUID formId) {
        committeeAssignmentRepository.incrementWorkload(assignmentId);
        
        log.info("Assigned form {} to committee member assignment {}", formId, assignmentId);
    }
    
    @Override
    @Transactional
    public void completeFormReviewByCommitteeMember(UUID assignmentId, UUID formId) {
        committeeAssignmentRepository.completeReview(assignmentId);
        
        log.info("Completed form {} review by committee member assignment {}", formId, assignmentId);
    }
    
    @Override
    public CommitteeAssignmentDTO getCommitteeAssignmentForUser(User user, String academicYear) {
        Optional<CommitteeAssignment> assignment = committeeAssignmentRepository
                .findActiveCommitteeAssignmentByMemberAndYear(user, academicYear);
        
        return assignment.map(this::createCommitteeAssignmentDTO).orElse(null);
    }
    
    @Override
    public CommitteeWorkloadStats getCommitteeWorkloadStats(String academicYear) {
        CommitteeWorkloadStats stats = new CommitteeWorkloadStats();
        stats.setAcademicYear(academicYear);
        
        List<CommitteeAssignment> allMembers = committeeAssignmentRepository
                .findActiveCommitteeMembersForYear(academicYear);
        
        stats.setTotalCommitteeMembers(allMembers.size());
        
        if (!allMembers.isEmpty()) {
            double totalWorkload = allMembers.stream()
                    .mapToInt(CommitteeAssignment::getWorkloadCount)
                    .sum();
            stats.setAverageWorkloadPerMember(totalWorkload / allMembers.size());
        }
        
        // Get forms under committee review
        long formsUnderReview = appraisalFormRepository.countByStatus(AppraisalStatus.COMMITTEE_REVIEW);
        stats.setTotalFormsUnderCommitteeReview((int) formsUnderReview);
        
        // Get completed forms
        long completedForms = allMembers.stream()
                .mapToInt(CommitteeAssignment::getCompletedReviews)
                .sum();
        stats.setTotalFormsCompleted((int) completedForms);
        
        // TODO: Add department-wise statistics
        stats.setDepartmentStats(new ArrayList<>());
        
        return stats;
    }
    
    @Override
    public List<CommitteeAssignmentDTO> getCommitteeMembersForDepartmentReview(String academicYear, String departmentName) {
        Department department = departmentRepository.findByName(departmentName)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found: " + departmentName));
        
        List<CommitteeAssignment> availableMembers = committeeAssignmentRepository
                .findAvailableCommitteeMembersExcludingDepartment(academicYear, department, MAX_WORKLOAD_PER_MEMBER);
        
        return availableMembers.stream()
                .map(this::createCommitteeAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    // Helper methods
    
    private List<User> getEligibleStaffFromDepartment(Department department, String academicYear) {
        // Get all users from department
        List<User> departmentUsers = userRepository.findByDepartmentIdAndDeletedFalse(department.getId());
        
        return departmentUsers.stream()
                .filter(user -> isEligibleForCommittee(user, academicYear))
                .collect(Collectors.toList());
    }
    
    private boolean isEligibleForCommittee(User user, String academicYear) {
        // Exclude HODs, Principals, Chairpersons
        boolean hasExcludedRole = user.getRoles().stream()
                .anyMatch(role -> Arrays.asList("HOD", "PRINCIPAL", "CHAIRPERSON").contains(role.getName()));
        
        if (hasExcludedRole) {
            return false;
        }
        
        // Can include regular staff and DCMs
        boolean hasEligibleRole = user.getRoles().stream()
                .anyMatch(role -> Arrays.asList("STAFF", "DCM").contains(role.getName()));
        
        return hasEligibleRole && !user.isDeleted();
    }
    
    private List<User> selectRandomMembers(List<User> eligibleStaff, int count) {
        if (eligibleStaff.size() <= count) {
            return new ArrayList<>(eligibleStaff);
        }
        
        List<User> shuffled = new ArrayList<>(eligibleStaff);
        Collections.shuffle(shuffled, random);
        
        return shuffled.subList(0, count);
    }
    
    private CommitteeSelectionDTO createCommitteeSelectionDTO(User staff, boolean isCurrentlyCommitteeMember, String academicYear) {
        // Check if staff has submitted own appraisal
        boolean hasSubmittedOwn = appraisalFormRepository.existsByUserAndAcademicYear(staff, academicYear);
        
        // Check if staff is DCM
        boolean isDCM = dcmAssignmentRepository.findActiveDCMAssignmentByStaffAndYear(staff, academicYear).isPresent();
        
        // Check if staff is HOD
        boolean isHOD = staff.getRoles().stream().anyMatch(role -> "HOD".equals(role.getName()));
        
        // Get previous committee assignments
        int previousAssignments = committeeAssignmentRepository.findCommitteeAssignmentHistory(staff).size();
        
        return CommitteeSelectionDTO.builder()
                .staffId(staff.getId())
                .fullName(staff.getFullName())
                .email(staff.getEmail())
                .employeeId(staff.getEmployeeId())
                .departmentName(staff.getDepartment().getName())
                .designation("Staff") // Default since User entity doesn't have designation field
                .isCurrentlyCommitteeMember(isCurrentlyCommitteeMember)
                .isEligible(!isCurrentlyCommitteeMember && !isHOD && isEligibleForCommittee(staff, academicYear))
                .ineligibilityReason(isCurrentlyCommitteeMember ? "Already committee member" : 
                                   isHOD ? "HOD cannot be committee member" : null)
                .yearsOfExperience(calculateExperience(staff))
                .isDCM(isDCM)
                .isHOD(isHOD)
                .hasSubmittedOwnAppraisal(hasSubmittedOwn)
                .previousCommitteeAssignments(previousAssignments)
                .build();
    }
    
    private CommitteeAssignmentDTO createCommitteeAssignmentDTO(CommitteeAssignment assignment) {
        User member = assignment.getCommitteeMember();
        
        // Get review statistics
        long totalReviews = reviewRepository.countByReviewerAndLevel(member, ReviewLevel.COMMITTEE_REVIEW);
        long approvedReviews = reviewRepository.countByReviewerAndLevelAndDecision(
                member, ReviewLevel.COMMITTEE_REVIEW, ReviewDecision.APPROVED);
        
        return CommitteeAssignmentDTO.builder()
                .assignmentId(assignment.getId())
                .committeeMemberId(member.getId())
                .memberFullName(member.getFullName())
                .memberEmail(member.getEmail())
                .memberEmployeeId(member.getEmployeeId())
                .memberDepartmentName(member.getDepartment().getName())
                .memberDesignation("Staff") // Default since User entity doesn't have designation field
                .academicYear(assignment.getAcademicYear())
                .isActive(assignment.isCurrentlyActive())
                .assignedAt(assignment.getAssignedAt())
                .deactivatedAt(assignment.getDeactivatedAt())
                .selectionMethod(assignment.getSelectionMethod())
                .currentWorkload(assignment.getWorkloadCount())
                .completedReviews(assignment.getCompletedReviews())
                .completionRate(totalReviews > 0 ? (double) assignment.getCompletedReviews() / totalReviews * 100 : 0)
                .totalAssignedForms(assignment.getWorkloadCount() + assignment.getCompletedReviews())
                .status(assignment.isCurrentlyActive() ? "ACTIVE" : "INACTIVE")
                .canTakeMoreWork(assignment.canTakeMoreWork(MAX_WORKLOAD_PER_MEMBER))
                .maxWorkloadCapacity(MAX_WORKLOAD_PER_MEMBER)
                .formsApproved((int) approvedReviews)
                .formsRejected((int) (totalReviews - approvedReviews))
                .approvalRate(totalReviews > 0 ? (double) approvedReviews / totalReviews * 100 : 0)
                .build();
    }
    
    private int calculateExperience(User staff) {
        // Placeholder - would need to implement based on joining date or other criteria
        return 5; // Default to 5 years
    }
} 