package com.cvrce.apraisal.dto.dcm;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class DCMValidationResult {
    private boolean valid;
    private List<String> errorMessages;
    private List<String> warningMessages;
    
    public DCMValidationResult(boolean valid) {
        this.valid = valid;
        this.errorMessages = new ArrayList<>();
        this.warningMessages = new ArrayList<>();
    }
    
    public void addError(String error) { this.errorMessages.add(error); }
    public void addWarning(String warning) { this.warningMessages.add(warning); }
    public boolean isValid() { return valid && errorMessages.isEmpty(); }
    public void setValid(boolean valid) { this.valid = valid; }
} 