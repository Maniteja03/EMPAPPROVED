package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.dto.committee.CommitteeDashboardDTO;
import com.cvrce.apraisal.dto.committee.CommitteeWorkloadDTO;
import com.cvrce.apraisal.entity.FormLock;
import com.cvrce.apraisal.service.CommitteeReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/committee-review")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("@committeeManagementService.isUserCommitteeMember(authentication.principal, #academicYear)")
public class CommitteeReviewController {
    
    private final CommitteeReviewService committeeReviewService;
    
    /**
     * Get committee member dashboard
     */
    @GetMapping("/dashboard")
    public ResponseEntity<CommitteeDashboardDTO> getDashboard(@RequestParam String academicYear) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting dashboard for {}", committeeEmail, academicYear);
        
        CommitteeDashboardDTO dashboard = committeeReviewService.getCommitteeDashboard(committeeEmail, academicYear);
        
        return ResponseEntity.ok(dashboard);
    }
    
    /**
     * Get forms available for committee review (excludes own department)
     */
    @GetMapping("/available-forms") 
    public ResponseEntity<Page<AppraisalFormDTO>> getAvailableFormsForReview(
            @RequestParam String academicYear,
            Pageable pageable) {
        
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting available forms for review in {}", 
                committeeEmail, academicYear);
        
        Page<AppraisalFormDTO> availableForms = committeeReviewService
                .getAvailableFormsForReview(committeeEmail, academicYear, pageable);
        
        return ResponseEntity.ok(availableForms);
    }
    
    /**
     * Get forms from own department (VIEW ONLY - no review actions)
     */
    @GetMapping("/own-department-forms")
    public ResponseEntity<Page<AppraisalFormDTO>> getOwnDepartmentForms(
            @RequestParam String academicYear,
            Pageable pageable) {
        
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting own department forms for viewing in {}", 
                committeeEmail, academicYear);
        
        Page<AppraisalFormDTO> ownDeptForms = committeeReviewService
                .getOwnDepartmentForms(committeeEmail, academicYear, pageable);
        
        return ResponseEntity.ok(ownDeptForms);
    }
    
    /**
     * Start reviewing a form (attempt to lock it)
     */
    @PostMapping("/start-review/{formId}")
    public ResponseEntity<FormLockResponse> startFormReview(@PathVariable UUID formId) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} attempting to start review of form {}", committeeEmail, formId);
        
        Optional<FormLock> lock = committeeReviewService.startFormReview(formId, committeeEmail);
        
        if (lock.isPresent()) {
            FormLockResponse response = new FormLockResponse(true, "Form locked successfully", 
                    lock.get().getExpiresAt().toString());
            return ResponseEntity.ok(response);
        } else {
            FormLockResponse response = new FormLockResponse(false, 
                    "Form is currently being reviewed by another committee member", null);
            return ResponseEntity.status(423).body(response); // 423 Locked
        }
    }
    
    /**
     * Get form details for review
     */
    @GetMapping("/form/{formId}")
    public ResponseEntity<AppraisalFormDTO> getFormForReview(@PathVariable UUID formId) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting form {} for review", committeeEmail, formId);
        
        try {
            AppraisalFormDTO form = committeeReviewService.getFormForReview(formId, committeeEmail);
            return ResponseEntity.ok(form);
        } catch (SecurityException e) {
            log.warn("Security violation: Committee member {} tried to access unauthorized form {}", 
                    committeeEmail, formId);
            return ResponseEntity.status(403).build();
        } catch (IllegalStateException e) {
            log.warn("Form {} is not available for review: {}", formId, e.getMessage());
            return ResponseEntity.status(423).build(); // 423 Locked
        }
    }
    
    /**
     * Submit committee review (approve or reject)
     */
    @PostMapping("/submit-review")
    // RATE LIMITING: Consider adding rate limiting for committee reviews
    public ResponseEntity<ReviewDTO> submitCommitteeReview(@Valid @RequestBody ReviewDTO reviewDTO) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} submitting review for form {} with decision {}", 
                committeeEmail, reviewDTO.getAppraisalFormId(), reviewDTO.getDecision());
        
        try {
            ReviewDTO submittedReview = committeeReviewService.submitCommitteeReview(reviewDTO, committeeEmail);
            return ResponseEntity.ok(submittedReview);
        } catch (SecurityException e) {
            log.warn("Security violation: Committee member {} unauthorized review submission", committeeEmail);
            return ResponseEntity.status(403).build();
        } catch (IllegalStateException e) {
            log.warn("Invalid review state for form {}: {}", reviewDTO.getAppraisalFormId(), e.getMessage());
            return ResponseEntity.status(400).build();
        }
    }
    
    /**
     * Cancel form review and release lock
     */
    @PostMapping("/cancel-review/{formId}")
    public ResponseEntity<Void> cancelFormReview(@PathVariable UUID formId) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} cancelling review of form {}", committeeEmail, formId);
        
        boolean cancelled = committeeReviewService.cancelFormReview(formId, committeeEmail);
        
        if (cancelled) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Get forms currently being reviewed by this committee member
     */
    @GetMapping("/my-active-reviews")
    public ResponseEntity<List<AppraisalFormDTO>> getMyActiveReviews() {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting active reviews", committeeEmail);
        
        List<AppraisalFormDTO> activeReviews = committeeReviewService.getMyActiveReviews(committeeEmail);
        
        return ResponseEntity.ok(activeReviews);
    }
    
    /**
     * Get committee review history
     */
    @GetMapping("/my-review-history")
    public ResponseEntity<Page<ReviewDTO>> getMyReviewHistory(
            @RequestParam String academicYear,
            Pageable pageable) {
        
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting review history for {}", committeeEmail, academicYear);
        
        Page<ReviewDTO> reviewHistory = committeeReviewService
                .getMyReviewHistory(committeeEmail, academicYear, pageable);
        
        return ResponseEntity.ok(reviewHistory);
    }
    
    /**
     * Extend form review lock
     */
    @PostMapping("/extend-lock/{formId}")
    public ResponseEntity<FormLockResponse> extendReviewLock(
            @PathVariable UUID formId,
            @RequestParam(defaultValue = "15") int additionalMinutes) {
        
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} extending lock for form {} by {} minutes", 
                committeeEmail, formId, additionalMinutes);
        
        boolean extended = committeeReviewService.extendReviewLock(formId, committeeEmail, additionalMinutes);
        
        if (extended) {
            FormLockResponse response = new FormLockResponse(true, 
                    "Lock extended by " + additionalMinutes + " minutes", null);
            return ResponseEntity.ok(response);
        } else {
            FormLockResponse response = new FormLockResponse(false, 
                    "Failed to extend lock - form may not be locked by you", null);
            return ResponseEntity.status(400).body(response);
        }
    }
    
    /**
     * Get workload statistics
     */
    @GetMapping("/workload-stats")
    public ResponseEntity<CommitteeWorkloadDTO> getWorkloadStats(@RequestParam String academicYear) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Committee member {} requesting workload stats for {}", committeeEmail, academicYear);
        
        CommitteeWorkloadDTO workloadStats = committeeReviewService
                .getMyWorkloadStats(committeeEmail, academicYear);
        
        return ResponseEntity.ok(workloadStats);
    }
    
    /**
     * Check if can review forms from a specific department
     */
    @GetMapping("/can-review-department/{departmentName}")
    public ResponseEntity<Boolean> canReviewDepartmentForms(@PathVariable String departmentName) {
        String committeeEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        boolean canReview = committeeReviewService.canReviewDepartmentForms(committeeEmail, departmentName);
        
        return ResponseEntity.ok(canReview);
    }
}

/**
 * Response DTO for form locking operations
 */
class FormLockResponse {
    private boolean success;
    private String message;
    private String lockExpiresAt;
    
    public FormLockResponse(boolean success, String message, String lockExpiresAt) {
        this.success = success;
        this.message = message;
        this.lockExpiresAt = lockExpiresAt;
    }
    
    // Getters
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public String getLockExpiresAt() { return lockExpiresAt; }
} 