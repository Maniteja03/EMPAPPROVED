package com.cvrce.apraisal.exception;

import lombok.Getter;
import java.util.Map;
import java.util.List;

@Getter
public class ValidationException extends RuntimeException {
    
    private final String field;
    private final Object rejectedValue;
    private final Map<String, String> fieldErrors;
    private final List<String> globalErrors;
    
    public ValidationException(String message) {
        super(message);
        this.field = null;
        this.rejectedValue = null;
        this.fieldErrors = null;
        this.globalErrors = null;
    }
    
    public ValidationException(String message, String field, Object rejectedValue) {
        super(message);
        this.field = field;
        this.rejectedValue = rejectedValue;
        this.fieldErrors = null;
        this.globalErrors = null;
    }
    
    public ValidationException(String message, Map<String, String> fieldErrors) {
        super(message);
        this.field = null;
        this.rejectedValue = null;
        this.fieldErrors = fieldErrors;
        this.globalErrors = null;
    }
    
    public ValidationException(String message, Map<String, String> fieldErrors, List<String> globalErrors) {
        super(message);
        this.field = null;
        this.rejectedValue = null;
        this.fieldErrors = fieldErrors;
        this.globalErrors = globalErrors;
    }
}

// Specific validation exception classes
class InvalidFileFormatException extends ValidationException {
    public InvalidFileFormatException(String message, String filename) {
        super("Invalid file format: " + message, "file", filename);
    }
}

class FileSizeExceededException extends ValidationException {
    public FileSizeExceededException(String message, String filename, long size) {
        super("File size exceeded: " + message, "fileSize", size);
    }
}

class DateRangeValidationException extends ValidationException {
    public DateRangeValidationException(String message, String field, Object value) {
        super(message, field, value);
    }
}

class EnumValidationException extends ValidationException {
    public EnumValidationException(String message, String field, Object value) {
        super(message, field, value);
    }
}

class UniqueConstraintValidationException extends ValidationException {
    public UniqueConstraintValidationException(String message, String field, Object value) {
        super("Duplicate value found: " + message, field, value);
    }
}

class RequiredFieldValidationException extends ValidationException {
    public RequiredFieldValidationException(String fieldName) {
        super("Required field is missing: " + fieldName, fieldName, null);
    }
}

class BusinessRuleValidationException extends ValidationException {
    public BusinessRuleValidationException(String message) {
        super("Business rule violation: " + message);
    }
} 