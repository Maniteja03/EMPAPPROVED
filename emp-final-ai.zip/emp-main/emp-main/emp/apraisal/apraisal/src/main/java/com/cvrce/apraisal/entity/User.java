package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "users")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(columnDefinition = "BINARY(16)")
	private UUID id;

	@Column(nullable = false, unique = true)
	private String employeeId;

	@Column(nullable = false)
	private String fullName;

	@Column(nullable = false, unique = true)
	private String email;

	@Column(nullable = false)
	private String password;

	private LocalDate dateOfJoining;

	private LocalDate lastPromotionDate;

	private boolean enabled;

	@Builder.Default
	private boolean deleted = false;

	@ManyToOne
	@JoinColumn(name = "department_id")
	private Department department;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles = new HashSet<>();
	
	// NEW: Designation relationships
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@Builder.Default
	private List<StaffDesignation> designationHistory = new ArrayList<>();
	
	// Additional profile fields for appraisal
	@Column(name = "contact_number", length = 15)
	private String contactNumber;
	
	@Column(name = "date_of_promotion_at_cvr")
	private LocalDate dateOfPromotionAtCVR;
	
	@Column(name = "experience_at_cvr_years", precision = 4, scale = 1)
	private java.math.BigDecimal experienceAtCVRYears;
	
	@Column(name = "teaching_exp_outside_cvr_years", precision = 4, scale = 1)
	private java.math.BigDecimal teachingExpOutsideCVRYears;
	
	@Column(name = "total_teaching_exp_years", precision = 4, scale = 1)
	private java.math.BigDecimal totalTeachingExpYears;
	
	@Column(name = "industry_exp_years", precision = 4, scale = 1)
	private java.math.BigDecimal industryExpYears;
	
	@Column(name = "is_hs_faculty", nullable = false)
	@Builder.Default
	private Boolean isHSFaculty = false; // Humanities & Sciences faculty flag
	
	// Helper methods for designation management
	public StaffDesignation getCurrentDesignation() {
		return designationHistory.stream()
				.filter(StaffDesignation::getIsCurrentDesignation)
				.findFirst()
				.orElse(null);
	}
	
	public StaffDesignation getDesignationOn(LocalDate date) {
		return designationHistory.stream()
				.filter(designation -> designation.isActiveOn(date))
				.findFirst()
				.orElse(null);
	}
	
	public DesignationType getCurrentDesignationType() {
		StaffDesignation current = getCurrentDesignation();
		return current != null ? current.getDesignationType() : null;
	}
	
	public DesignationGroup getCurrentDesignationGroup() {
		StaffDesignation current = getCurrentDesignation();
		return current != null ? current.getDesignationGroup() : null;
	}
	
	// Helper method to add a new designation
	public void addDesignation(StaffDesignation newDesignation) {
		// End current designation
		StaffDesignation current = getCurrentDesignation();
		if (current != null) {
			current.endDesignation(newDesignation.getEffectiveFromDate().minusDays(1));
		}
		
		// Set new designation as current
		newDesignation.makeCurrentDesignation();
		newDesignation.setUser(this);
		
		if (designationHistory == null) {
			designationHistory = new ArrayList<>();
		}
		designationHistory.add(newDesignation);
	}
}
