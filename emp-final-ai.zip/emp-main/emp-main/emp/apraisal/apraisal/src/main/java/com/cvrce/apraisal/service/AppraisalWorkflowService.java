package com.cvrce.apraisal.service;

import com.cvrce.apraisal.enums.AppraisalStatus;
import java.util.UUID;

/**
 * Service to handle appraisal workflow state transitions
 */
public interface AppraisalWorkflowService {
    
    /**
     * Move appraisal to the next stage in the workflow
     * @param formId the appraisal form ID
     * @param currentStatus current status of the appraisal
     * @param decision the decision made (APPROVED/REJECTED)
     * @return the new status after transition
     */
    AppraisalStatus transitionToNextStage(UUID formId, AppraisalStatus currentStatus, String decision);
    
    /**
     * Check if a user can review an appraisal at its current status
     * @param formId the appraisal form ID
     * @param userRole the role of the user trying to review
     * @return true if the user can review at current stage
     */
    boolean canUserReviewAtCurrentStage(UUID formId, String userRole);
    
    /**
     * Get the expected reviewer role for the current status
     * @param status current appraisal status
     * @return the role that should review at this stage
     */
    String getExpectedReviewerRole(AppraisalStatus status);
    
    /**
     * Validate if the status transition is allowed
     * @param fromStatus current status
     * @param toStatus desired status
     * @return true if transition is valid
     */
    boolean isValidTransition(AppraisalStatus fromStatus, AppraisalStatus toStatus);
} 