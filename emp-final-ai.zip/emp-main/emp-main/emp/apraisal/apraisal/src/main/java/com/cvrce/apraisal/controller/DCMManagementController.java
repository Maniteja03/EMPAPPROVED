package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.dcm.DCMAssignmentDTO;
import com.cvrce.apraisal.dto.dcm.DCMSelectionDTO;
import com.cvrce.apraisal.dto.dcm.DCMValidationResult;
import com.cvrce.apraisal.dto.dcm.DCMWorkloadStats;
import com.cvrce.apraisal.service.DCMManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/dcm-management")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('HOD')")
public class DCMManagementController {
    
    private final DCMManagementService dcmManagementService;
    
    /**
     * Get all eligible staff members for DCM assignment
     */
    @GetMapping("/eligible-staff")
    public ResponseEntity<List<DCMSelectionDTO>> getEligibleStaff(
            @RequestParam String academicYear) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} requesting eligible staff for DCM assignment in {}", hodEmail, academicYear);
        
        List<DCMSelectionDTO> eligibleStaff = dcmManagementService.getEligibleStaffForDCM(hodEmail, academicYear);
        
        return ResponseEntity.ok(eligibleStaff);
    }
    
    /**
     * Get current DCM assignments for HOD's department
     */
    @GetMapping("/current-assignments")
    public ResponseEntity<List<DCMAssignmentDTO>> getCurrentAssignments(
            @RequestParam String academicYear) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} requesting current DCM assignments for {}", hodEmail, academicYear);
        
        List<DCMAssignmentDTO> assignments = dcmManagementService.getCurrentDCMAssignments(hodEmail, academicYear);
        
        return ResponseEntity.ok(assignments);
    }
    
    /**
     * Assign new DCMs (add to existing assignments)
     */
    @PostMapping("/assign")
    public ResponseEntity<List<DCMAssignmentDTO>> assignDCMs(
            @Valid @RequestBody DCMAssignmentRequest request) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} assigning {} staff members as DCMs for {}", 
                hodEmail, request.getStaffIds().size(), request.getAcademicYear());
        
        List<DCMAssignmentDTO> assignments = dcmManagementService.assignDCMs(
                hodEmail, request.getStaffIds(), request.getAcademicYear());
        
        return ResponseEntity.ok(assignments);
    }
    
    /**
     * Replace all current DCM assignments with new ones
     */
    @PutMapping("/replace-all")
    public ResponseEntity<List<DCMAssignmentDTO>> replaceAllAssignments(
            @Valid @RequestBody DCMAssignmentRequest request) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} replacing all DCM assignments for {}", hodEmail, request.getAcademicYear());
        
        List<DCMAssignmentDTO> assignments = dcmManagementService.replaceDCMAssignments(
                hodEmail, request.getStaffIds(), request.getAcademicYear());
        
        return ResponseEntity.ok(assignments);
    }
    
    /**
     * Remove a specific DCM assignment
     */
    @DeleteMapping("/assignment/{assignmentId}")
    public ResponseEntity<Void> removeDCMAssignment(@PathVariable UUID assignmentId) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} removing DCM assignment {}", hodEmail, assignmentId);
        
        boolean removed = dcmManagementService.removeDCMAssignment(hodEmail, assignmentId);
        
        if (removed) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Validate DCM assignments before applying
     */
    @PostMapping("/validate")
    public ResponseEntity<DCMValidationResult> validateAssignments(
            @Valid @RequestBody DCMAssignmentRequest request) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} validating DCM assignments for {}", hodEmail, request.getAcademicYear());
        
        DCMValidationResult validation = dcmManagementService.validateDCMAssignments(
                hodEmail, request.getStaffIds(), request.getAcademicYear());
        
        return ResponseEntity.ok(validation);
    }
    
    /**
     * Get DCM workload statistics for department
     */
    @GetMapping("/workload-stats")
    public ResponseEntity<DCMWorkloadStats> getWorkloadStats(@RequestParam String academicYear) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} requesting workload stats for {}", hodEmail, academicYear);
        
        DCMWorkloadStats stats = dcmManagementService.getDCMWorkloadStats(hodEmail, academicYear);
        
        return ResponseEntity.ok(stats);
    }
    
    /**
     * Get DCM assignment history for a specific staff member
     */
    @GetMapping("/assignment-history/{staffId}")
    public ResponseEntity<List<DCMAssignmentDTO>> getAssignmentHistory(@PathVariable UUID staffId) {
        
        String hodEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD {} requesting assignment history for staff {}", hodEmail, staffId);
        
        List<DCMAssignmentDTO> history = dcmManagementService.getDCMAssignmentHistory(staffId);
        
        return ResponseEntity.ok(history);
    }
}

/**
 * Request DTO for DCM assignments
 */
class DCMAssignmentRequest {
    @jakarta.validation.constraints.NotNull(message = "Academic year is required")
    private String academicYear;
    
    @jakarta.validation.constraints.NotEmpty(message = "At least one staff member must be selected")
    private List<UUID> staffIds;
    
    // Constructors, getters, setters
    public DCMAssignmentRequest() {}
    
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public List<UUID> getStaffIds() { return staffIds; }
    public void setStaffIds(List<UUID> staffIds) { this.staffIds = staffIds; }
} 