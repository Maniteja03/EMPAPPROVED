package com.cvrce.apraisal.service;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface FileUploadService {
    
    /**
     * Upload proof document for scoring component
     */
    String uploadProofDocument(MultipartFile file, UUID appraisalFormId, String componentType, String componentId);
    
    /**
     * Upload multiple proof documents
     */
    List<String> uploadMultipleProofDocuments(List<MultipartFile> files, UUID appraisalFormId, String componentType);
    
    /**
     * Delete proof document
     */
    boolean deleteProofDocument(String filePath);
    
    /**
     * Get proof document URL
     */
    String getProofDocumentUrl(String filePath);
    
    /**
     * Validate file for upload
     */
    Map<String, Object> validateFile(MultipartFile file);
    
    /**
     * Get allowed file types
     */
    List<String> getAllowedFileTypes();
    
    /**
     * Get maximum file size
     */
    long getMaxFileSize();
    
    /**
     * Clean up orphaned files
     */
    void cleanupOrphanedFiles();
}
