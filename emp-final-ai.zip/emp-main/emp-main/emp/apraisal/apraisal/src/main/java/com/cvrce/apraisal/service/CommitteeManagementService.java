package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.committee.CommitteeAssignmentDTO;
import com.cvrce.apraisal.dto.committee.CommitteeSelectionDTO;
import com.cvrce.apraisal.dto.committee.CommitteeWorkloadStats;
import com.cvrce.apraisal.entity.User;

import java.util.List;
import java.util.UUID;

/**
 * Service for managing committee member selection and assignments
 */
public interface CommitteeManagementService {
    
    /**
     * Randomly select committee members from all departments
     * @param academicYear The academic year
     * @param membersPerDepartment Number of members to select per department
     * @return List of newly assigned committee members
     */
    List<CommitteeAssignmentDTO> selectRandomCommitteeMembers(String academicYear, int membersPerDepartment);
    
    /**
     * Get current committee members for academic year
     * @param academicYear The academic year
     * @return List of current committee assignments
     */
    List<CommitteeAssignmentDTO> getCurrentCommitteeMembers(String academicYear);
    
    /**
     * Get all eligible staff members for committee selection
     * @param academicYear The academic year
     * @return List of eligible staff with selection details
     */
    List<CommitteeSelectionDTO> getEligibleStaffForCommittee(String academicYear);
    
    /**
     * Manually assign specific staff members as committee members
     * @param staffIds List of staff IDs to assign
     * @param academicYear The academic year
     * @return List of new committee assignments
     */
    List<CommitteeAssignmentDTO> assignCommitteeMembers(List<UUID> staffIds, String academicYear);
    
    /**
     * Remove a committee member assignment
     * @param assignmentId The assignment ID to remove
     * @return true if removed successfully
     */
    boolean removeCommitteeMemberAssignment(UUID assignmentId);
    
    /**
     * Re-select committee members (deactivate current and select new ones)
     * @param academicYear The academic year
     * @param membersPerDepartment Number of members to select per department
     * @return List of newly selected committee members
     */
    List<CommitteeAssignmentDTO> reselectionCommitteeMembers(String academicYear, int membersPerDepartment);
    
    /**
     * Check if user is a committee member for academic year
     * @param user The user to check
     * @param academicYear The academic year
     * @return true if user is currently a committee member
     */
    boolean isUserCommitteeMember(User user, String academicYear);
    
    /**
     * Get available committee member for form assignment (load balancing)
     * @param academicYear The academic year
     * @param excludeDepartment Department to exclude (can't review own department)
     * @return Available committee member with lowest workload, or null if none available
     */
    CommitteeAssignmentDTO getAvailableCommitteeMemberForAssignment(String academicYear, String excludeDepartment);
    
    /**
     * Assign form to committee member (increment workload)
     * @param assignmentId The committee assignment ID
     * @param formId The form ID being assigned
     */
    void assignFormToCommitteeMember(UUID assignmentId, UUID formId);
    
    /**
     * Complete form review by committee member (decrement workload, increment completed)
     * @param assignmentId The committee assignment ID
     * @param formId The form ID that was completed
     */
    void completeFormReviewByCommitteeMember(UUID assignmentId, UUID formId);
    
    /**
     * Get committee assignment for specific user
     * @param user The user
     * @param academicYear The academic year
     * @return Committee assignment if exists
     */
    CommitteeAssignmentDTO getCommitteeAssignmentForUser(User user, String academicYear);
    
    /**
     * Get committee workload distribution statistics
     * @param academicYear The academic year
     * @return Committee workload statistics
     */
    CommitteeWorkloadStats getCommitteeWorkloadStats(String academicYear);
    
    /**
     * Get committee members who can review forms from a specific department
     * @param academicYear The academic year
     * @param departmentName Department name to exclude from reviewers
     * @return List of available committee members
     */
    List<CommitteeAssignmentDTO> getCommitteeMembersForDepartmentReview(String academicYear, String departmentName);
} 