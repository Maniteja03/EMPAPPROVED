package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.ConferenceScoring;
import com.cvrce.apraisal.entity.ConferenceType;
import com.cvrce.apraisal.entity.ParticipationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ConferenceScoringRepository extends JpaRepository<ConferenceScoring, UUID> {
    
    List<ConferenceScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT cs FROM ConferenceScoring cs WHERE cs.appraisalScoring.id = :scoringId ORDER BY cs.startDate DESC")
    List<ConferenceScoring> findByAppraisalScoringIdOrderByDate(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT cs FROM ConferenceScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<ConferenceScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT cs FROM ConferenceScoring cs WHERE cs.participationType = :participationType")
    List<ConferenceScoring> findByParticipationType(@Param("participationType") ParticipationType participationType);
    
    @Query("SELECT cs FROM ConferenceScoring cs WHERE cs.conferenceType = :conferenceType")
    List<ConferenceScoring> findByConferenceType(@Param("conferenceType") ConferenceType conferenceType);
    
    @Query("SELECT cs FROM ConferenceScoring cs WHERE cs.isNPTELSWAYAM = true")
    List<ConferenceScoring> findNPTELSWAYAMCourses();
    
    @Query("SELECT COUNT(cs), cs.participationType FROM ConferenceScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear GROUP BY cs.participationType")
    List<Object[]> getConferenceStatisticsByParticipationType(@Param("academicYear") String academicYear);
} 