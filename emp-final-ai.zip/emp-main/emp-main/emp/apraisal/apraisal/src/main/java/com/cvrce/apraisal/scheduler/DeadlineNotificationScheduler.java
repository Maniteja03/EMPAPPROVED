package com.cvrce.apraisal.scheduler;

import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.dto.NotificationDTO;
import com.cvrce.apraisal.service.NotificationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.Arrays;

@Component
@RequiredArgsConstructor
@Slf4j
public class DeadlineNotificationScheduler {

    private final DeadlineConfigRepository deadlineRepo;
    private final AppraisalFormRepository appraisalFormRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;

    @Scheduled(cron = "0 0 9 * * ?") // Daily at 9 AM
    public void sendDeadlineReminders() {
        try {
            log.info("Running deadline reminder scheduler");
            
            // Get due deadlines efficiently (replace findAll())
            LocalDate today = LocalDate.now();
            LocalDate reminderDate = today.plusDays(3); // 3 days before deadline
            
            // Use efficient query instead of findAll()
            List<DeadlineConfig> dueDeadlines = deadlineRepo.findByDeadlineDateBetween(today, reminderDate);
            
            if (dueDeadlines.isEmpty()) {
                log.info("No upcoming deadlines found");
                return;
            }

            // Get users who haven't submitted efficiently
            for (DeadlineConfig deadline : dueDeadlines) {
                // Get submitted user IDs for this academic year efficiently
                List<UUID> submittedUserIds = appraisalFormRepo
                    .findByAcademicYearAndStatusIn(deadline.getAcademicYear(), 
                        Arrays.asList(AppraisalStatus.SUBMITTED, AppraisalStatus.DEPARTMENT_REVIEW, 
                                     AppraisalStatus.HOD_APPROVED, AppraisalStatus.COLLEGE_REVIEW, 
                                     AppraisalStatus.CHAIRPERSON_REVIEW, AppraisalStatus.COMPLETED))
                    .stream()
                    .map(form -> form.getUser().getId())
                    .collect(Collectors.toList());

                // Get active users efficiently (exclude submitted users)
                List<User> pendingUsers;
                if (submittedUserIds.isEmpty()) {
                    pendingUsers = userRepo.findByDeletedFalse();
                } else {
                    pendingUsers = userRepo.findByDeletedFalseAndIdNotIn(submittedUserIds);
                }

                // Send notifications
                for (User user : pendingUsers) {
                    NotificationDTO notification = NotificationDTO.builder()
                            .userId(user.getId())
                            .title("Appraisal Deadline Reminder")
                            .message("Your appraisal form for " + deadline.getAcademicYear() + 
                                   " is due on " + deadline.getDeadlineDate() + ". Please complete it soon.")
                            .build();
                    
                    notificationService.sendNotification(notification);
                }
                
                log.info("Sent {} deadline reminders for {}", pendingUsers.size(), deadline.getAcademicYear());
            }
            
        } catch (Exception e) {
            log.error("Error in deadline reminder scheduler", e);
        }
    }
}
