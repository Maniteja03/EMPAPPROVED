package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.FormAssignment;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface FormAssignmentRepository extends JpaRepository<FormAssignment, UUID> {
    
    @Query("SELECT fa FROM FormAssignment fa WHERE fa.appraisalForm.id = :formId AND fa.isActive = true")
    Optional<FormAssignment> findActiveAssignmentByFormId(@Param("formId") UUID formId);
    
    @Query("SELECT fa FROM FormAssignment fa WHERE fa.assignedReviewer = :reviewer AND fa.isActive = true")
    List<FormAssignment> findActiveAssignmentsByReviewer(@Param("reviewer") User reviewer);
    
    @Query("SELECT COUNT(fa) FROM FormAssignment fa WHERE fa.assignedReviewer = :reviewer AND fa.isActive = true")
    long countActiveAssignmentsByReviewer(@Param("reviewer") User reviewer);
    
    @Query("SELECT fa FROM FormAssignment fa WHERE fa.committeeAssignment.id = :assignmentId AND fa.isActive = true")
    List<FormAssignment> findActiveAssignmentsByCommitteeAssignment(@Param("assignmentId") UUID assignmentId);
    
    @Modifying
    @Query("UPDATE FormAssignment fa SET fa.isActive = false WHERE fa.appraisalForm.id = :formId")
    int deactivateAssignmentsByFormId(@Param("formId") UUID formId);
    
    @Modifying
    @Query("UPDATE FormAssignment fa SET fa.completedAt = CURRENT_TIMESTAMP, fa.isActive = false WHERE fa.id = :assignmentId")
    int completeAssignment(@Param("assignmentId") UUID assignmentId);
    
    @Query("SELECT fa FROM FormAssignment fa WHERE fa.assignmentType = :assignmentType AND fa.isActive = true")
    List<FormAssignment> findActiveAssignmentsByType(@Param("assignmentType") String assignmentType);
    
    @Query("SELECT COUNT(fa) FROM FormAssignment fa WHERE fa.assignmentType = 'COMMITTEE_REVIEW' AND fa.isActive = true")
    long countActiveCommitteeAssignments();
    
    @Query("SELECT COUNT(fa) FROM FormAssignment fa WHERE fa.assignmentType = 'DCM_REVIEW' AND fa.isActive = true")
    long countActiveDCMAssignments();
} 