package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.DesignationType;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AppraisalScoringRepository extends JpaRepository<AppraisalScoring, UUID> {
    
    // Find scoring by appraisal form
    Optional<AppraisalScoring> findByAppraisalForm(AppraisalForm appraisalForm);
    
    // Find scoring by appraisal form ID
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.id = :formId")
    Optional<AppraisalScoring> findByAppraisalFormId(@Param("formId") UUID formId);
    
    // Find scoring by user and academic year
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.user = :user " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    Optional<AppraisalScoring> findByUserAndAcademicYear(@Param("user") User user, @Param("academicYear") String academicYear);
    
    // Find all scorings for a user
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.user = :user " +
           "ORDER BY aps.appraisalForm.academicYear DESC")
    List<AppraisalScoring> findAllByUser(@Param("user") User user);
    
    // Find scorings by academic year
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.academicYear = :academicYear")
    List<AppraisalScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    // Find scorings by department and academic year
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.user.department.id = :departmentId " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    List<AppraisalScoring> findByDepartmentAndAcademicYear(@Param("departmentId") UUID departmentId, @Param("academicYear") String academicYear);
    
    // Find top scorers by academic year
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.appraisalForm.academicYear = :academicYear " +
           "ORDER BY aps.totalScore DESC")
    List<AppraisalScoring> findTopScorersByAcademicYear(@Param("academicYear") String academicYear, Pageable pageable);
    
    // Find scorings above threshold
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.totalScore >= :threshold " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    List<AppraisalScoring> findScoringsAboveThreshold(@Param("threshold") BigDecimal threshold, @Param("academicYear") String academicYear);
    
    // Get scoring statistics by designation group
    @Query("SELECT aps.designationAtSubmission.designationType, " +
           "AVG(aps.totalScore), MIN(aps.totalScore), MAX(aps.totalScore), COUNT(aps) " +
           "FROM AppraisalScoring aps WHERE aps.appraisalForm.academicYear = :academicYear " +
           "GROUP BY aps.designationAtSubmission.designationType")
    List<Object[]> getScoringStatisticsByDesignation(@Param("academicYear") String academicYear);
    
    // Find H&S faculty scorings
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.isHSFaculty = true " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    List<AppraisalScoring> findHSFacultyScoringsByAcademicYear(@Param("academicYear") String academicYear);
    
    // Find scorings requiring manual review
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.isAutoCalculated = false " +
           "AND aps.manualOverrideReason IS NOT NULL")
    List<AppraisalScoring> findScoringsWithManualOverride();
    
    // Find incomplete scorings (missing components)
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.totalScore = 0 " +
           "OR aps.partAFinalScore = 0 OR aps.partBFinalScore = 0")
    List<AppraisalScoring> findIncompleteScoringsByAcademicYear(@Param("academicYear") String academicYear);
    
    // Get average scores by part
    @Query("SELECT AVG(aps.partAFinalScore), AVG(aps.partBFinalScore), AVG(aps.partCScore) " +
           "FROM AppraisalScoring aps WHERE aps.appraisalForm.academicYear = :academicYear")
    List<Object[]> getAverageScoresByPart(@Param("academicYear") String academicYear);
    
    // Find scorings by designation type and academic year
    @Query("SELECT aps FROM AppraisalScoring aps WHERE aps.designationAtSubmission.designationType = :designationType " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    List<AppraisalScoring> findByDesignationTypeAndAcademicYear(
            @Param("designationType") DesignationType designationType, 
            @Param("academicYear") String academicYear);
    
    // Search scorings with pagination
    @Query("SELECT aps FROM AppraisalScoring aps WHERE " +
           "(LOWER(aps.appraisalForm.user.fullName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
           "OR LOWER(aps.appraisalForm.user.employeeId) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
           "AND aps.appraisalForm.academicYear = :academicYear")
    Page<AppraisalScoring> findScoringsWithSearch(@Param("searchTerm") String searchTerm, 
                                                  @Param("academicYear") String academicYear, 
                                                  Pageable pageable);
} 