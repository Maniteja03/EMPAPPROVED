package com.cvrce.apraisal.enums;

public enum AppraisalStatus {
    DRAFT,
    SUBMITTED,
    DEPARTMENT_REVIEW,      // DCM review stage
    DCM_APPROVED,          // After DCM approves, before HOD
    REUPLOAD_REQUIRED,     // When DCM/HOD rejects for reupload
    HOD_APPROVED,          // After HOD approves, ready for committee
    COMMITTEE_REVIEW,      // Committee review stage
    COMMITTEE_REJECTED,    // Committee rejected, back to HOD
    HOD_UPDATED,          // HOD updated after committee rejection
    COLLEGE_REVIEW,       // College committee approved, legacy status
    CHAIRPERSON_REVIEW,   // Chairperson review stage
    PRINCIPAL_REVIEW,     // Principal final review
    COMPLETED             // Fully approved and completed
}
