package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.service.DCMService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Optional;
import java.util.HashMap;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/dcm")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('DCM')")
public class DCMController {

    private final DCMService dcmService;

    // Get DCM dashboard data
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDCMDashboard() {
        log.info("Fetching DCM dashboard data");
        return ResponseEntity.ok(dcmService.getDCMDashboard());
    }

    // Get appraisals assigned for DCM review
    @GetMapping("/assigned-reviews")
    public ResponseEntity<Page<AppraisalFormDTO>> getAssignedReviews(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> assignedReviews = dcmService.getAssignedReviews(pageable);
        return ResponseEntity.ok(assignedReviews);
    }

    // Submit initial DCM review
    @PostMapping("/review")
    public ResponseEntity<ReviewDTO> submitDCMReview(@Valid @RequestBody ReviewDTO reviewDTO) {
        // SECURITY FIX: Get current authenticated user email
        String currentUserEmail = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();
        
        log.info("DCM submitting review for appraisal: {} by authenticated user: {}", 
                reviewDTO.getAppraisalFormId(), currentUserEmail);
        
        ReviewDTO submittedReview = dcmService.submitInitialReview(reviewDTO, currentUserEmail);
        return ResponseEntity.ok(submittedReview);
    }

    // Get specific appraisal for DCM review
    @GetMapping("/review/{formId}")
    public ResponseEntity<AppraisalFormDTO> getAppraisalForReview(@PathVariable UUID formId) {
        log.info("DCM accessing appraisal {} for review", formId);
        AppraisalFormDTO appraisal = dcmService.getAppraisalForDCMReview(formId);
        return ResponseEntity.ok(appraisal);
    }

    // ✅ NEW: Start form review with locking
    @PostMapping("/start-review/{formId}")
    public ResponseEntity<?> startFormReview(@PathVariable UUID formId) {
        String dcmEmail = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();
        
        log.info("DCM {} attempting to start review for form {}", dcmEmail, formId);
        
        Optional<com.cvrce.apraisal.entity.FormLock> lock = dcmService.startFormReview(formId, dcmEmail);
        
        if (lock.isPresent()) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("lockId", lock.get().getId());
            response.put("expiresAt", lock.get().getExpiresAt());
            response.put("message", "Form locked successfully for review");
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Form is already locked by another reviewer or not assigned to you");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        }
    }

    // ✅ NEW: Get form for review (with lock check)
    @GetMapping("/form-for-review/{formId}")
    public ResponseEntity<AppraisalFormDTO> getFormForReview(@PathVariable UUID formId) {
        String dcmEmail = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();
        
        log.info("DCM {} accessing locked form {} for review", dcmEmail, formId);
        
        try {
            AppraisalFormDTO form = dcmService.getFormForReview(formId, dcmEmail);
            return ResponseEntity.ok(form);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }

    // ✅ NEW: Cancel form review and release lock
    @PostMapping("/cancel-review/{formId}")
    public ResponseEntity<?> cancelFormReview(@PathVariable UUID formId) {
        String dcmEmail = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();
        
        log.info("DCM {} cancelling review for form {}", dcmEmail, formId);
        
        boolean released = dcmService.cancelFormReview(formId, dcmEmail);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", released);
        response.put("message", released ? "Review cancelled and lock released" : "No active lock found");
        
        return ResponseEntity.ok(response);
    }

    // ✅ NEW: Get active reviews (locked forms)
    @GetMapping("/active-reviews")
    public ResponseEntity<List<AppraisalFormDTO>> getMyActiveReviews() {
        String dcmEmail = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();
        
        log.info("DCM {} requesting active reviews", dcmEmail);
        
        List<AppraisalFormDTO> activeReviews = dcmService.getMyActiveReviews(dcmEmail);
        return ResponseEntity.ok(activeReviews);
    }

    /*
    // Get DCM review history
    @GetMapping("/review-history")
    public ResponseEntity<Page<ReviewDTO>> getReviewHistory(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String academicYear) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("reviewedAt").descending());
        Page<ReviewDTO> reviewHistory = dcmService.getReviewHistory(pageable, academicYear);
        return ResponseEntity.ok(reviewHistory);
    }
    */

    // Get appraisal statistics for DCM
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getDCMStatistics(
            @RequestParam(required = false) String academicYear) {
        log.info("Fetching DCM statistics for academic year: {}", academicYear);
        Map<String, Object> statistics = dcmService.getDCMStatistics(academicYear);
        return ResponseEntity.ok(statistics);
    }

    // Request reassignment of an appraisal
    @PostMapping("/request-reassignment/{formId}")
    public ResponseEntity<String> requestReassignment(
            @PathVariable UUID formId,
            @RequestParam String reason) {
        log.info("DCM requesting reassignment for appraisal: {} with reason: {}", formId, reason);
        dcmService.requestReassignment(formId, reason);
        return ResponseEntity.ok("Reassignment request submitted successfully");
    }

    /*
    // Get department-specific appraisal trends
    @GetMapping("/department-trends")
    public ResponseEntity<Map<String, Object>> getDepartmentTrends(
            @RequestParam(required = false) String academicYear) {
        Map<String, Object> trends = dcmService.getDepartmentAppraisalTrends(academicYear);
        return ResponseEntity.ok(trends);
    }
    */
} 