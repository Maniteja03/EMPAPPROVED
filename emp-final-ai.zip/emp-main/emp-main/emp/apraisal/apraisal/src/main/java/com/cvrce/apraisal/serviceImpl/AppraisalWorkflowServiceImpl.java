package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class AppraisalWorkflowServiceImpl implements AppraisalWorkflowService {
    
    // Updated workflow transitions for new enhanced system
    private static final Map<AppraisalStatus, AppraisalStatus> APPROVED_TRANSITIONS = new HashMap<>() {{
        put(AppraisalStatus.DRAFT, AppraisalStatus.DEPARTMENT_REVIEW);                 // Staff submits → DCM review
        put(AppraisalStatus.DEPARTMENT_REVIEW, AppraisalStatus.DCM_APPROVED);          // DCM approves → HOD review  
        put(AppraisalStatus.DCM_APPROVED, AppraisalStatus.HOD_APPROVED);               // HOD approves → Committee review
        put(AppraisalStatus.HOD_APPROVED, AppraisalStatus.COMMITTEE_REVIEW);           // Auto-assigned to committee
        put(AppraisalStatus.COMMITTEE_REVIEW, AppraisalStatus.CHAIRPERSON_REVIEW);     // Committee approves → Chairperson
        put(AppraisalStatus.HOD_UPDATED, AppraisalStatus.COMMITTEE_REVIEW);            // HOD updates after rejection → Same committee member
        put(AppraisalStatus.CHAIRPERSON_REVIEW, AppraisalStatus.PRINCIPAL_REVIEW);     // Chairperson approves → Principal
        put(AppraisalStatus.PRINCIPAL_REVIEW, AppraisalStatus.COMPLETED);              // Principal approves → COMPLETED
        put(AppraisalStatus.COLLEGE_REVIEW, AppraisalStatus.COMPLETED);                // College committee approves → COMPLETED (legacy)
        put(AppraisalStatus.COMPLETED, AppraisalStatus.COMPLETED);                     // Stay completed
    }};
    
    // Rejection transitions - where forms go when rejected
    private static final Map<AppraisalStatus, AppraisalStatus> REJECTED_TRANSITIONS = new HashMap<>() {{
        put(AppraisalStatus.DEPARTMENT_REVIEW, AppraisalStatus.REUPLOAD_REQUIRED);     // DCM rejects → Staff reupload
        put(AppraisalStatus.DCM_APPROVED, AppraisalStatus.REUPLOAD_REQUIRED);          // HOD rejects → Staff reupload  
        put(AppraisalStatus.COMMITTEE_REVIEW, AppraisalStatus.COMMITTEE_REJECTED);     // Committee rejects → HOD update
        put(AppraisalStatus.CHAIRPERSON_REVIEW, AppraisalStatus.COMMITTEE_REVIEW);     // Chairperson rejects → Back to committee
        put(AppraisalStatus.PRINCIPAL_REVIEW, AppraisalStatus.CHAIRPERSON_REVIEW);     // Principal rejects → Back to chairperson
        put(AppraisalStatus.COLLEGE_REVIEW, AppraisalStatus.COMMITTEE_REVIEW);         // College committee rejects → Back to committee (legacy)
    }};
    
    // Define role-to-status mapping for new workflow
    private static final Map<AppraisalStatus, String> STATUS_TO_REVIEWER = new HashMap<>() {{
        put(AppraisalStatus.DEPARTMENT_REVIEW, "DCM");
        put(AppraisalStatus.DCM_APPROVED, "HOD"); 
        put(AppraisalStatus.HOD_APPROVED, "SYSTEM_AUTO_ASSIGN");
        put(AppraisalStatus.COMMITTEE_REVIEW, "COMMITTEE");
        put(AppraisalStatus.COMMITTEE_REJECTED, "HOD");
        put(AppraisalStatus.HOD_UPDATED, "COMMITTEE_SAME_MEMBER");
        put(AppraisalStatus.CHAIRPERSON_REVIEW, "CHAIRPERSON");
        put(AppraisalStatus.PRINCIPAL_REVIEW, "PRINCIPAL");
        put(AppraisalStatus.COLLEGE_REVIEW, "PRINCIPAL"); // Legacy college committee goes to principal
    }};
    
    @Override
    public AppraisalStatus transitionToNextStage(UUID formId, AppraisalStatus currentStatus, String decision) {
        log.info("Transitioning appraisal {} from {} with decision {}", formId, currentStatus, decision);
        
        AppraisalStatus nextStatus;
        
        if ("APPROVED".equalsIgnoreCase(decision)) {
            nextStatus = APPROVED_TRANSITIONS.get(currentStatus);
            if (nextStatus == null) {
                throw new IllegalStateException("No approved transition defined for status: " + currentStatus);
            }
        } else if ("REJECTED".equalsIgnoreCase(decision)) {
            nextStatus = REJECTED_TRANSITIONS.get(currentStatus);
            if (nextStatus == null) {
                throw new IllegalStateException("No rejected transition defined for status: " + currentStatus);
            }
        } else {
            throw new IllegalArgumentException("Invalid decision: " + decision + ". Must be APPROVED or REJECTED");
        }
        
        log.info("Appraisal {} transitioned from {} to {} (decision: {})", 
                formId, currentStatus, nextStatus, decision);
        
        return nextStatus;
    }
    
    @Override
    public boolean canUserReviewAtCurrentStage(UUID formId, String userRole) {
        // Implementation to check if user can review at current stage
        return true; // Simplified for now
    }
    
    @Override
    public String getExpectedReviewerRole(AppraisalStatus status) {
        return STATUS_TO_REVIEWER.getOrDefault(status, "UNKNOWN");
    }
    
    @Override
    public boolean isValidTransition(AppraisalStatus fromStatus, AppraisalStatus toStatus) {
        // Check if transition is valid in both approved and rejected paths
        AppraisalStatus approvedNext = APPROVED_TRANSITIONS.get(fromStatus);
        AppraisalStatus rejectedNext = REJECTED_TRANSITIONS.get(fromStatus);
        
        return (approvedNext != null && approvedNext == toStatus) || 
               (rejectedNext != null && rejectedNext == toStatus);
    }
    
    public boolean canTransition(AppraisalStatus currentStatus, String decision) {
        if ("APPROVED".equalsIgnoreCase(decision)) {
            return APPROVED_TRANSITIONS.containsKey(currentStatus);
        } else if ("REJECTED".equalsIgnoreCase(decision)) {
            return REJECTED_TRANSITIONS.containsKey(currentStatus);
        }
        return false;
    }
    
    public String getRequiredReviewerRole(AppraisalStatus status) {
        return STATUS_TO_REVIEWER.getOrDefault(status, "UNKNOWN");
    }
    
    public List<AppraisalStatus> getNextPossibleStatuses(AppraisalStatus currentStatus) {
        List<AppraisalStatus> possibleStatuses = new ArrayList<>();
        
        // Add approved transition if exists
        AppraisalStatus approvedNext = APPROVED_TRANSITIONS.get(currentStatus);
        if (approvedNext != null) {
            possibleStatuses.add(approvedNext);
        }
        
        // Add rejected transition if exists
        AppraisalStatus rejectedNext = REJECTED_TRANSITIONS.get(currentStatus);
        if (rejectedNext != null && !possibleStatuses.contains(rejectedNext)) {
            possibleStatuses.add(rejectedNext);
        }
        
        return possibleStatuses;
    }
    
    public boolean isTerminalStatus(AppraisalStatus status) {
        return status == AppraisalStatus.COMPLETED || 
               status == AppraisalStatus.REUPLOAD_REQUIRED;
    }
    
    public int getWorkflowStageNumber(AppraisalStatus status) {
        return switch (status) {
            case DRAFT -> 0;
            case DEPARTMENT_REVIEW -> 1;
            case DCM_APPROVED -> 2;
            case HOD_APPROVED -> 3;
            case COMMITTEE_REVIEW -> 4;
            case COMMITTEE_REJECTED -> 3; // Back to HOD level
            case HOD_UPDATED -> 4; // Back to committee level (same member)
            case COLLEGE_REVIEW -> 4; // Legacy college committee level
            case CHAIRPERSON_REVIEW -> 5;
            case PRINCIPAL_REVIEW -> 6;
            case COMPLETED -> 7;
            case REUPLOAD_REQUIRED -> 0; // Back to beginning
            default -> -1;
        };
    }
    
    public String getWorkflowStageDescription(AppraisalStatus status) {
        return switch (status) {
            case DRAFT -> "Draft - Staff preparing appraisal";
            case DEPARTMENT_REVIEW -> "Under DCM Review - Department level verification";
            case DCM_APPROVED -> "DCM Approved - Awaiting HOD review";
            case HOD_APPROVED -> "HOD Approved - Ready for committee assignment";
            case COMMITTEE_REVIEW -> "Committee Review - College committee evaluation";
            case COMMITTEE_REJECTED -> "Committee Rejected - HOD needs to update and resubmit";
            case HOD_UPDATED -> "HOD Updated - Resubmitted to same committee member";
            case COLLEGE_REVIEW -> "College Committee Review - Legacy committee evaluation awaiting principal";
            case CHAIRPERSON_REVIEW -> "Chairperson Review - Senior management review";
            case PRINCIPAL_REVIEW -> "Principal Review - Final institutional approval";
            case COMPLETED -> "Completed - Appraisal process finished";
            case REUPLOAD_REQUIRED -> "Reupload Required - Staff needs to revise and resubmit";
            default -> "Unknown Status";
        };
    }
    
    /**
     * Check if form can be auto-assigned to committee
     */
    public boolean requiresCommitteeAssignment(AppraisalStatus status) {
        return status == AppraisalStatus.HOD_APPROVED;
    }
    
    /**
     * Check if form should go back to same committee member (after HOD update)
     */
    public boolean requiresSameCommitteeMember(AppraisalStatus status) {
        return status == AppraisalStatus.HOD_UPDATED;
    }
    
    /**
     * Get workflow completion percentage
     */
    public double getCompletionPercentage(AppraisalStatus status) {
        int currentStage = getWorkflowStageNumber(status);
        int totalStages = 7; // COMPLETED is stage 7
        
        if (currentStage < 0) return 0.0;
        if (currentStage >= totalStages) return 100.0;
        
        return (double) currentStage / totalStages * 100.0;
    }
    
    /**
     * Check if status allows editing
     */
    public boolean allowsEditing(AppraisalStatus status) {
        return status == AppraisalStatus.DRAFT || 
               status == AppraisalStatus.REUPLOAD_REQUIRED;
    }
    
    /**
     * Get all statuses that can transition to target status
     */
    public List<AppraisalStatus> getStatusesThatCanTransitionTo(AppraisalStatus targetStatus) {
        List<AppraisalStatus> sourceStatuses = new ArrayList<>();
        
        // Check approved transitions
        APPROVED_TRANSITIONS.entrySet().stream()
                .filter(entry -> entry.getValue() == targetStatus)
                .forEach(entry -> sourceStatuses.add(entry.getKey()));
        
        // Check rejected transitions  
        REJECTED_TRANSITIONS.entrySet().stream()
                .filter(entry -> entry.getValue() == targetStatus)
                .forEach(entry -> sourceStatuses.add(entry.getKey()));
        
        return sourceStatuses;
    }
} 