package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.ProjectScoring;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Repository
public interface ProjectScoringRepository extends JpaRepository<ProjectScoring, UUID> {
    
    List<ProjectScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT ps FROM ProjectScoring ps WHERE ps.appraisalScoring.id = :scoringId ORDER BY ps.sanctionedDate DESC")
    List<ProjectScoring> findByAppraisalScoringIdOrderByDate(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT ps FROM ProjectScoring ps WHERE ps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<ProjectScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT ps FROM ProjectScoring ps WHERE ps.isExternallyFunded = true")
    List<ProjectScoring> findExternallyFundedProjects();
    
    @Query("SELECT ps FROM ProjectScoring ps WHERE ps.isPrincipalInvestigator = true")
    List<ProjectScoring> findPrincipalInvestigatorProjects();
    
    @Query("SELECT SUM(ps.fundingAmountLakhs) FROM ProjectScoring ps WHERE ps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    BigDecimal getTotalFundingByAcademicYear(@Param("academicYear") String academicYear);
} 