package com.cvrce.apraisal.dto.user;

import lombok.*;

import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
public class UserResponseDTO {
    private UUID id;
    private String employeeId;
    private String fullName;
    private String email;
    private boolean enabled;
    private boolean deleted;
    private LocalDate dateOfJoining;
    private LocalDate lastPromotionDate;
    private Long departmentId;
    private String departmentName;
    private Set<String> roles;
}
