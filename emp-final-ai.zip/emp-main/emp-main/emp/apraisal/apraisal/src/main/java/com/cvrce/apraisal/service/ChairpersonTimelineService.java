package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.timeline.AppraisalTimelineDTO;
import com.cvrce.apraisal.dto.timeline.TimelineSetupDTO;
import com.cvrce.apraisal.dto.timeline.TimelineStatusDTO;
import com.cvrce.apraisal.dto.timeline.TimelineStatisticsDTO;
import com.cvrce.apraisal.dto.timeline.TimelineValidationResult;
import com.cvrce.apraisal.dto.timeline.TimelineReportDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface ChairpersonTimelineService {
    
    /**
     * Create new appraisal timeline for academic year (Chairperson only)
     * @param chairpersonEmail The chairperson's email
     * @param timelineSetup Timeline setup with all deadlines
     * @return Created timeline
     */
    AppraisalTimelineDTO createAppraisalTimeline(String chairpersonEmail, TimelineSetupDTO timelineSetup);
    
    /**
     * Update existing timeline (only if not finalized)
     * @param chairpersonEmail The chairperson's email
     * @param timelineId Timeline ID to update
     * @param timelineSetup Updated timeline setup
     * @return Updated timeline
     */
    AppraisalTimelineDTO updateAppraisalTimeline(String chairpersonEmail, UUID timelineId, TimelineSetupDTO timelineSetup);
    
    /**
     * Get active timeline for academic year
     * @param academicYear The academic year
     * @return Active timeline if exists
     */
    AppraisalTimelineDTO getActiveTimelineForYear(String academicYear);
    
    /**
     * Get all timelines created by chairperson
     * @param chairpersonEmail The chairperson's email
     * @return List of timelines created by this chairperson
     */
    List<AppraisalTimelineDTO> getTimelinesCreatedByChairperson(String chairpersonEmail);
    
    /**
     * Get all active timelines across all academic years
     * @return List of all active timelines
     */
    List<AppraisalTimelineDTO> getAllActiveTimelines();
    
    /**
     * Finalize timeline (lock it from further changes)
     * @param chairpersonEmail The chairperson's email
     * @param timelineId Timeline ID to finalize
     * @return true if successfully finalized
     */
    boolean finalizeTimeline(String chairpersonEmail, UUID timelineId);
    
    /**
     * Deactivate timeline
     * @param chairpersonEmail The chairperson's email
     * @param timelineId Timeline ID to deactivate
     * @return true if successfully deactivated
     */
    boolean deactivateTimeline(String chairpersonEmail, UUID timelineId);
    
    /**
     * Get current timeline status (which phase is active, days remaining, etc.)
     * @param academicYear The academic year
     * @return Current timeline status
     */
    TimelineStatusDTO getCurrentTimelineStatus(String academicYear);
    
    /**
     * Check if specific action is allowed based on current timeline
     * @param academicYear The academic year
     * @param action The action to check (e.g., "STAFF_UPLOAD", "HOD_DCM_ASSIGNMENT")
     * @return true if action is currently allowed
     */
    boolean isActionAllowed(String academicYear, String action);
    
    /**
     * Get timeline for current date (auto-detect which timeline is currently active)
     * @return Currently active timeline based on today's date
     */
    AppraisalTimelineDTO getCurrentActiveTimeline();
    
    /**
     * Update timeline phases based on current date (scheduled job)
     * Called daily to automatically update timeline phases
     * @return Number of timelines updated
     */
    int updateTimelinePhases();
    
    /**
     * Send deadline reminder notifications (scheduled job)
     * @param daysBeforeDeadline Days before deadline to send reminder
     * @return Number of reminders sent
     */
    int sendDeadlineReminders(int daysBeforeDeadline);
    
    /**
     * Get timeline statistics for chairperson dashboard
     * @param chairpersonEmail The chairperson's email
     * @return Timeline statistics
     */
    TimelineStatisticsDTO getTimelineStatistics(String chairpersonEmail);
    
    /**
     * Validate timeline dates (ensure logical sequence)
     * @param timelineSetup Timeline setup to validate
     * @return Validation result
     */
    TimelineValidationResult validateTimelineDates(TimelineSetupDTO timelineSetup);
    
    /**
     * Get timeline template (suggested dates based on academic calendar)
     * @param academicYear The academic year
     * @param startDate Preferred start date
     * @return Suggested timeline template
     */
    TimelineSetupDTO getTimelineTemplate(String academicYear, LocalDate startDate);
    
    /**
     * Clone timeline from previous year
     * @param chairpersonEmail The chairperson's email
     * @param sourceAcademicYear Source academic year to clone from
     * @param targetAcademicYear Target academic year
     * @param dayOffset Number of days to shift all dates
     * @return Cloned timeline
     */
    AppraisalTimelineDTO cloneTimelineFromPreviousYear(String chairpersonEmail, String sourceAcademicYear, 
                                                      String targetAcademicYear, int dayOffset);
    
    /**
     * Get overdue timelines
     * @return List of timelines that are past their final deadline
     */
    List<AppraisalTimelineDTO> getOverdueTimelines();
    
    /**
     * Force complete timeline (admin/chairperson emergency action)
     * @param chairpersonEmail The chairperson's email
     * @param timelineId Timeline ID to force complete
     * @param reason Reason for force completion
     * @return true if successfully completed
     */
    boolean forceCompleteTimeline(String chairpersonEmail, UUID timelineId, String reason);
    
    /**
     * Generate timeline report (for chairperson review)
     * @param timelineId Timeline ID
     * @return Timeline report with statistics and progress
     */
    TimelineReportDTO generateTimelineReport(UUID timelineId);
} 