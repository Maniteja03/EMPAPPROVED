package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, UUID> {
    
    Page<AuditLog> findByUserId(UUID userId, Pageable pageable);
    
    Page<AuditLog> findByEntityAndEntityId(String entity, String entityId, Pageable pageable);
    
    Page<AuditLog> findByAction(String action, Pageable pageable);
    
    Page<AuditLog> findByCreatedAtBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    
    Page<AuditLog> findByLevel(AuditLog.AuditLevel level, Pageable pageable);
    
    @Query("SELECT al FROM AuditLog al WHERE al.level IN ('CRITICAL', 'ERROR') ORDER BY al.createdAt DESC")
    Page<AuditLog> findSecurityAuditLogs(Pageable pageable);
    
    @Query("SELECT COUNT(al) FROM AuditLog al WHERE al.action = :action AND al.createdAt >= :since")
    long countByActionSince(@Param("action") String action, @Param("since") LocalDateTime since);
    
    @Query("SELECT al.action, COUNT(al) FROM AuditLog al WHERE al.createdAt >= :since GROUP BY al.action ORDER BY COUNT(al) DESC")
    List<Object[]> findTopActionsSince(@Param("since") LocalDateTime since, Pageable pageable);
    
    @Query("SELECT al.user.id, COUNT(al) FROM AuditLog al WHERE al.createdAt >= :since GROUP BY al.user.id ORDER BY COUNT(al) DESC")
    List<Object[]> findMostActiveUsersSince(@Param("since") LocalDateTime since, Pageable pageable);
    
    @Modifying
    @Query("DELETE FROM AuditLog al WHERE al.createdAt < :cutoffDate")
    int deleteOldAuditLogs(@Param("cutoffDate") LocalDateTime cutoffDate);
    
    @Query("SELECT COUNT(al) FROM AuditLog al WHERE al.user.id = :userId AND al.action = 'LOGIN_ATTEMPT' AND al.level = 'ERROR' AND al.createdAt >= :since")
    long countFailedLoginAttempts(@Param("userId") UUID userId, @Param("since") LocalDateTime since);
} 