package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.SummaryEvaluationDTO;
import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.service.PrincipalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/principal")
@RequiredArgsConstructor
@PreAuthorize("hasRole('PRINCIPAL')")
public class PrincipalController {

    private final PrincipalService principalService;

    // Get all appraisals pending final approval
    @GetMapping("/pending-approvals")
    public ResponseEntity<List<AppraisalFormDTO>> getPendingApprovals() {
        return ResponseEntity.ok(principalService.getPendingFinalApprovals());
    }

    // Get specific appraisal for final review
    @GetMapping("/appraisal/{formId}")
    public ResponseEntity<AppraisalFormDTO> getAppraisalForFinalReview(@PathVariable UUID formId) {
        return ResponseEntity.ok(principalService.getAppraisalForFinalReview(formId));
    }

    // Provide final approval or rejection
    @PostMapping("/final-decision/{formId}")
    public ResponseEntity<String> provideFinalDecision(
            @PathVariable UUID formId,
            @RequestParam String decision, // "APPROVED" or "REJECTED"
            @RequestParam(required = false) String comments) {
        
        principalService.provideFinalDecision(formId, decision, comments);
        return ResponseEntity.ok("Final decision recorded successfully");
    }

    // Get dashboard summary for principal
    @GetMapping("/dashboard")
    public ResponseEntity<?> getPrincipalDashboard() {
        return ResponseEntity.ok(principalService.getPrincipalDashboard());
    }

    // Bulk approve multiple appraisals
    @PostMapping("/bulk-approve")
    public ResponseEntity<String> bulkApprove(@RequestBody List<UUID> formIds) {
        principalService.bulkApprove(formIds);
        return ResponseEntity.ok("Bulk approval completed");
    }

    // Get appraisal statistics for the academic year
    @GetMapping("/statistics")
    public ResponseEntity<?> getAppraisalStatistics(@RequestParam String academicYear) {
        return ResponseEntity.ok(principalService.getAppraisalStatistics(academicYear));
    }
} 