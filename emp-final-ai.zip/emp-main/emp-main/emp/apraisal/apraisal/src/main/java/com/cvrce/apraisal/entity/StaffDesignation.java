package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "staff_designations")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class StaffDesignation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private DesignationType designationType;
    
    @Column(name = "effective_from_date", nullable = false)
    private LocalDate effectiveFromDate;
    
    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate; // null means current designation
    
    @Column(name = "academic_year", nullable = false, length = 10)
    private String academicYear; // e.g., "2024-25"
    
    @Column(name = "promotion_order_number", length = 100)
    private String promotionOrderNumber;
    
    @Column(name = "promotion_date")
    private LocalDate promotionDate;
    
    @Column(name = "is_current_designation", nullable = false)
    @Builder.Default
    private Boolean isCurrentDesignation = false;
    
    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Helper method to make this designation current
    public void makeCurrentDesignation() {
        this.isCurrentDesignation = true;
        this.effectiveToDate = null;
    }
    
    // Helper method to end this designation
    public void endDesignation(LocalDate endDate) {
        this.isCurrentDesignation = false;
        this.effectiveToDate = endDate;
    }
    
    // Helper method to check if designation was active during a specific date
    public boolean isActiveOn(LocalDate date) {
        boolean afterStart = !date.isBefore(effectiveFromDate);
        boolean beforeEnd = effectiveToDate == null || !date.isAfter(effectiveToDate);
        return afterStart && beforeEnd;
    }
    
    // Get designation group for scoring (groups with same scoring rules)
    public DesignationGroup getDesignationGroup() {
        return switch (designationType) {
            case PROFESSOR -> DesignationGroup.PROFESSOR;
            case SR_ASSOCIATE_PROFESSOR, ASSOCIATE_PROFESSOR, DOCTORATE -> DesignationGroup.ASSOCIATE_LEVEL;
            case ASSISTANT_PROFESSOR -> DesignationGroup.ASSISTANT_LEVEL;
        };
    }
} 