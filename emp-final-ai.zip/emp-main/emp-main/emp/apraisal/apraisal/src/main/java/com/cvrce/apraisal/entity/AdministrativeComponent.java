package com.cvrce.apraisal.entity;

public enum AdministrativeComponent {
    DEPARTMENT_LEVEL("Administrative works - Department level", 5,
            "Mentoring, Attendance coordinator, Class teacher, Project coordinator, " +
            "Mini-project in charges, Lab in charges, BOS member, Department committee member, " +
            "Research hours coordinator, Guest lecture faculty coordinator, Members of Department Association, " +
            "Industrial visits in charge, any other work/activity assigned by HODs"),
    
    COLLEGE_LEVEL("Administrative works - College level", 5,
            "NAAC/NBA/UGC/College committees, Anti-ragging committee, Library committee, CRT, " +
            "Placement coordinator, Research coordinator, Alumni responsibilities, Grievance Committee, " +
            "NPTEL coordinator, ERP coordinator, Exam Cell additional responsibilities, " +
            "Graduation Day/Orientation Day committees, Hostel committee, Members of Professional Associations, " +
            "College club related activities, NSS coordinator, Outreach program activities, " +
            "any other work/activity assigned by Principal"),
    
    EXAMINATION_RELATED("Examination related works", 5,
            "Invigilation, Moderation, Chief examiner, Observer, Scrutiny, Paper evaluation, " +
            "paper setting, any other work/activity related to examinations"),
    
    HOD_FEEDBACK("HOD's feedback", 5,
            "Assessment by Head of the Department - Regularity and punctuality, " +
            "Completion of work assigned, Behavior with students, Behavior with peers and teamwork, " +
            "Research contribution to the Department");
    
    private final String displayName;
    private final int maxPoints;
    private final String description;
    
    AdministrativeComponent(String displayName, int maxPoints, String description) {
        this.displayName = displayName;
        this.maxPoints = maxPoints;
        this.description = description;
    }
    
    public String getDisplayName() { return displayName; }
    public int getMaxPoints() { return maxPoints; }
    public String getDescription() { return description; }
} 