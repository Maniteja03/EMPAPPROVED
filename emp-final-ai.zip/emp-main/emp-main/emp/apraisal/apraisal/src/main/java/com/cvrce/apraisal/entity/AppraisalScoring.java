package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "appraisal_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AppraisalScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_form_id", nullable = false, unique = true)
    private AppraisalForm appraisalForm;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "designation_id", nullable = false)
    private StaffDesignation designationAtSubmission; // Designation when form was submitted
    
    // PART A: Research and Professional Practice (Weightage = 40)
    @Column(name = "part_a_raw_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partARawScore = BigDecimal.ZERO;
    
    @Column(name = "part_a_max_raw", precision = 10, scale = 2)
    private BigDecimal partAMaxRaw; // Based on designation (100/75/50)
    
    @Column(name = "part_a_final_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partAFinalScore = BigDecimal.ZERO; // Scaled to 40
    
    // PART B: Professional Contribution and Others (Weightage = 60)
    @Column(name = "part_b_raw_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partBRawScore = BigDecimal.ZERO;
    
    @Column(name = "part_b_max_raw", precision = 10, scale = 2)
    private BigDecimal partBMaxRaw; // Based on designation (100/95/85)
    
    @Column(name = "part_b_final_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partBFinalScore = BigDecimal.ZERO; // Scaled to 60
    
    // PART C: Student Trainings and Certifications (Max = 25)
    @Column(name = "part_c_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partCScore = BigDecimal.ZERO;
    
    @Column(name = "part_c_max_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal partCMaxScore = new BigDecimal("25");
    
    // TOTAL SCORE (Part A + Part B + Part C = 40 + 60 + 25 = 125 max)
    @Column(name = "total_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal totalScore = BigDecimal.ZERO;
    
    @Column(name = "max_possible_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal maxPossibleScore = new BigDecimal("125");
    
    // H&S Faculty Special Logic Flag
    @Column(name = "is_hs_faculty", nullable = false)
    @Builder.Default
    private Boolean isHSFaculty = false;
    
    @Column(name = "hs_organizing_events_score", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal hsOrganizingEventsScore = BigDecimal.ZERO;
    
    // Auto-calculation flags
    @Column(name = "is_auto_calculated", nullable = false)
    @Builder.Default
    private Boolean isAutoCalculated = true;
    
    @Column(name = "manual_override_reason", columnDefinition = "TEXT")
    private String manualOverrideReason;
    
    @Column(name = "last_calculated_at")
    private LocalDateTime lastCalculatedAt;
    
    // Relationships to detailed scoring
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<PublicationScoring> publicationScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<CitationScoring> citationScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<PatentScoring> patentScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<ProjectScoring> projectScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<ConsultancyScoring> consultancyScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<TeachingPerformanceScoring> teachingPerformanceScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<ConferenceScoring> conferenceScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<AdministrativeScoring> administrativeScorings = new ArrayList<>();
    
    @OneToMany(mappedBy = "appraisalScoring", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<StudentTrainingScoring> studentTrainingScorings = new ArrayList<>();
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Helper methods for calculations
    public void calculateTotalScore() {
        this.totalScore = partAFinalScore.add(partBFinalScore).add(partCScore);
        this.lastCalculatedAt = LocalDateTime.now();
    }
    
    public void calculatePartAFinalScore() {
        if (partAMaxRaw != null && partAMaxRaw.compareTo(BigDecimal.ZERO) > 0) {
            // Formula: (Raw Score / Max Raw) × 40
            BigDecimal scalingFactor = new BigDecimal("40");
            this.partAFinalScore = partARawScore.divide(partAMaxRaw, 2, java.math.RoundingMode.HALF_UP)
                    .multiply(scalingFactor);
        }
    }
    
    public void calculatePartBFinalScore() {
        if (partBMaxRaw != null && partBMaxRaw.compareTo(BigDecimal.ZERO) > 0) {
            // Formula: (Raw Score / Max Raw) × 60
            BigDecimal scalingFactor = new BigDecimal("60");
            this.partBFinalScore = partBRawScore.divide(partBMaxRaw, 2, java.math.RoundingMode.HALF_UP)
                    .multiply(scalingFactor);
        }
    }
    
    public BigDecimal getScorePercentage() {
        if (maxPossibleScore.compareTo(BigDecimal.ZERO) > 0) {
            return totalScore.divide(maxPossibleScore, 4, java.math.RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("100"));
        }
        return BigDecimal.ZERO;
    }
    
    // Initialize scoring based on designation
    public void initializeWithDesignation(StaffDesignation designation) {
        DesignationGroup group = designation.getDesignationGroup();
        this.partAMaxRaw = new BigDecimal(group.getPartAMaxRaw());
        this.partBMaxRaw = new BigDecimal(group.getPartBMaxRaw());
        this.partCMaxScore = new BigDecimal(group.getPartCMax());
        this.designationAtSubmission = designation;
    }
} 