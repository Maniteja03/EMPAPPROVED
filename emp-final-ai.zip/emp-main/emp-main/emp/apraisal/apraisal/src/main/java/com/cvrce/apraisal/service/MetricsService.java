package com.cvrce.apraisal.service;

import com.cvrce.apraisal.entity.SystemMetrics;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.Map;

public interface MetricsService {
    
    // Performance Metrics
    void recordResponseTime(String endpoint, long responseTimeMs);
    void recordDatabaseQueryTime(String queryType, long queryTimeMs);
    void recordFileUploadTime(String fileType, long uploadTimeMs);
    
    // Usage Metrics
    void recordUserLogin(String userRole);
    void recordFeatureUsage(String featureName, String userRole);
    void recordAppraisalSubmission(String department, String academicYear);
    void recordReviewCompletion(String reviewLevel, String department);
    
    // System Metrics
    void recordSystemLoad(double cpuUsage, double memoryUsage, double diskUsage);
    void recordConcurrentUsers(int activeUsers);
    void recordDatabaseConnections(int activeConnections);
    
    // Business Metrics
    void recordAppraisalProcessingTime(String appraisalId, long processingTimeHours);
    void recordReviewTurnaroundTime(String reviewLevel, long turnaroundTimeHours);
    void recordDeadlineCompliance(String academicYear, boolean metDeadline);
    
    // Security Metrics
    void recordFailedLoginAttempt(String ipAddress, String userAgent);
    void recordSecurityEvent(String eventType, String severity);
    void recordUnauthorizedAccess(String resource, String userRole);
    
    // Error Metrics
    void recordException(String exceptionType, String component);
    void recordApiError(String endpoint, int statusCode);
    void recordValidationError(String fieldName, String validationType);
    
    // Analytics Methods
    Map<String, Object> getPerformanceMetrics(LocalDateTime startDate, LocalDateTime endDate);
    Map<String, Object> getUsageStatistics(LocalDateTime startDate, LocalDateTime endDate);
    Map<String, Object> getSystemHealthMetrics();
    Map<String, Object> getBusinessAnalytics(String academicYear);
    Map<String, Object> getSecurityMetrics(LocalDateTime startDate, LocalDateTime endDate);
    Map<String, Object> getErrorAnalytics(LocalDateTime startDate, LocalDateTime endDate);
    
    // Trending and Forecasting
    Map<String, Object> getTrendingMetrics(String metricCategory, LocalDateTime startDate, LocalDateTime endDate);
    Map<String, Object> getPredictiveAnalytics(String metricName, int forecastDays);
    
    // Real-time Monitoring
    Map<String, Object> getCurrentSystemStatus();
    Map<String, Object> getActiveUserMetrics();
    Map<String, Object> getRealTimePerformanceMetrics();
    
    // Metric Management
    Page<SystemMetrics> getMetricsByType(SystemMetrics.MetricType type, Pageable pageable);
    Page<SystemMetrics> getMetricsByCategory(String category, Pageable pageable);
    Page<SystemMetrics> getMetricsByDateRange(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    
    void cleanupOldMetrics(int retentionDays);
    
    // Dashboard Data
    Map<String, Object> getExecutiveDashboardMetrics();
    Map<String, Object> getOperationalDashboardMetrics();
    Map<String, Object> getTechnicalDashboardMetrics();
} 