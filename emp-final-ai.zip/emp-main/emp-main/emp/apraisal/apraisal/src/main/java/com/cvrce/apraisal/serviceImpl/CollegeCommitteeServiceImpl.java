package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.NotificationDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.entity.SummaryEvaluation;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.AppraisalBusinessException;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.SummaryEvaluationRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import com.cvrce.apraisal.service.CollegeCommitteeService;
import com.cvrce.apraisal.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.security.core.context.SecurityContextHolder;
import com.cvrce.apraisal.security.UserPrincipal;
import com.cvrce.apraisal.service.AppraisalFormService;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.repo.DepartmentRepository;

@Service
@RequiredArgsConstructor
@Slf4j
public class CollegeCommitteeServiceImpl implements CollegeCommitteeService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final AppraisalWorkflowService workflowService;
    private final AppraisalFormService appraisalFormService;
    private final DepartmentRepository departmentRepository;

    @Override
    public Map<String, Object> getCommitteeDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        
        List<AppraisalForm> pendingForms = appraisalFormRepository.findByStatus(AppraisalStatus.COLLEGE_REVIEW);
        long pendingReviews = pendingForms.size();
        long completedReviews = reviewRepository.count();
        String currentAcademicYear = getCurrentAcademicYear();
        long totalFormsThisYear = appraisalFormRepository.findByAcademicYear(currentAcademicYear).size();
        
        dashboard.put("pendingReviews", pendingReviews);
        dashboard.put("completedReviews", completedReviews);
        dashboard.put("totalFormsThisYear", totalFormsThisYear);
        dashboard.put("completionRate", totalFormsThisYear > 0 ? (double) completedReviews / totalFormsThisYear : 0.0);
        dashboard.put("lastUpdated", LocalDateTime.now());
        
        return dashboard;
    }

    @Override
    public Page<AppraisalFormDTO> getPendingReviews(Pageable pageable, String department) {
        List<AppraisalForm> pendingForms = appraisalFormRepository.findByStatus(AppraisalStatus.COLLEGE_REVIEW);
        
        // Simple department filtering if needed (simplified)
        if (department != null) {
            pendingForms = pendingForms.stream()
                    .filter(form -> form.getUser().getDepartment().getName().equals(department))
                    .collect(Collectors.toList());
        }
        
        List<AppraisalFormDTO> dtoList = pendingForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Manual pagination
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    @Transactional
    public ReviewDTO submitCommitteeReview(ReviewDTO reviewDTO, String currentUserEmail) {
        AppraisalForm appraisal = appraisalFormRepository.findById(reviewDTO.getAppraisalFormId())
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.COLLEGE_REVIEW) {
            throw new IllegalStateException("Appraisal is not in correct state for committee review");
        }
        
        // SECURITY FIX: Get reviewer from authenticated user, not from client
        User reviewer = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current user not found: " + currentUserEmail));
        
        Review review = Review.builder()
                .reviewer(reviewer)
                .appraisalForm(appraisal)
                .decision(ReviewDecision.valueOf(reviewDTO.getDecision()))
                .remarks(reviewDTO.getRemarks())
                .level(ReviewLevel.COLLEGE_COMMITTEE_REVIEW)
                .reviewedAt(LocalDateTime.now())
                .build();
        
        Review savedReview = reviewRepository.save(review);
        
        // Update appraisal status using workflow service
        AppraisalStatus newStatus = workflowService.transitionToNextStage(
            reviewDTO.getAppraisalFormId(), 
            appraisal.getStatus(), 
            reviewDTO.getDecision()
        );
        appraisal.setStatus(newStatus);
        appraisalFormRepository.save(appraisal);
        
        log.info("Committee submitted review for appraisal {} by authenticated user {}", 
                reviewDTO.getAppraisalFormId(), currentUserEmail);
        
        return mapReviewToDTO(savedReview);
    }

    @Override
    public Map<String, Object> getComprehensiveAppraisalView(UUID formId) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        List<Review> allReviews = reviewRepository.findByAppraisalFormId(formId);
        
        Map<String, Object> comprehensiveView = new HashMap<>();
        comprehensiveView.put("appraisal", mapToDTO(appraisal));
        comprehensiveView.put("reviewHistory", allReviews.stream().map(this::mapReviewToDTO).collect(Collectors.toList()));
        comprehensiveView.put("currentStatus", appraisal.getStatus());
        comprehensiveView.put("totalScore", appraisal.getTotalScore());
        comprehensiveView.put("submittedDate", appraisal.getSubmittedDate());
        
        return comprehensiveView;
    }

    @Override
    public List<ReviewDTO> getAppraisalReviewTrail(UUID formId) {
        List<Review> reviews = reviewRepository.findByAppraisalFormId(formId);
        return reviews.stream().map(this::mapReviewToDTO).collect(Collectors.toList());
    }

    @Override
    public Map<String, Object> generateMeetingAgenda(String meetingDate, String department) {
        Map<String, Object> agenda = new HashMap<>();
        
        List<AppraisalForm> pendingReviews = appraisalFormRepository.findByStatus(AppraisalStatus.COLLEGE_REVIEW);
        
        if (department != null) {
            pendingReviews = pendingReviews.stream()
                    .filter(form -> form.getUser().getDepartment().getName().equals(department))
                    .collect(Collectors.toList());
        }
        
        agenda.put("meetingDate", meetingDate);
        agenda.put("department", department);
        agenda.put("pendingReviews", pendingReviews.stream().map(this::mapToDTO).collect(Collectors.toList()));
        agenda.put("totalItems", pendingReviews.size());
        agenda.put("generatedAt", LocalDateTime.now());
        
        return agenda;
    }

    @Override
    @Transactional
    public void processBulkReviews(Map<UUID, String> formDecisions) {
        for (Map.Entry<UUID, String> entry : formDecisions.entrySet()) {
            UUID formId = entry.getKey();
            String decision = entry.getValue();
            
            AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                    .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found: " + formId));
            
            // Create review record (simplified - would need current user)
            User currentUser = getCurrentUser();
            if (currentUser != null) {
                Review review = Review.builder()
                        .reviewer(currentUser)
                        .appraisalForm(appraisal)
                        .decision(ReviewDecision.valueOf(decision))
                        .remarks("Bulk review decision")
                        .level(ReviewLevel.COLLEGE_COMMITTEE_REVIEW)
                        .reviewedAt(LocalDateTime.now())
                        .build();
                
                reviewRepository.save(review);
                
                // Update appraisal status
                if ("APPROVED".equals(decision)) {
                    appraisal.setStatus(AppraisalStatus.CHAIRPERSON_REVIEW);
                } else {
                    appraisal.setStatus(AppraisalStatus.REUPLOAD_REQUIRED);
                }
                appraisalFormRepository.save(appraisal);
            }
        }
        
        log.info("Processed bulk reviews for {} appraisals", formDecisions.size());
    }

    @Override
    public Map<String, Object> getCrossDepartmentStatistics(String academicYear) {
        Map<String, Object> stats = new HashMap<>();
        
        // Get all departments dynamically
        List<Department> allDepartments = departmentRepository.findAll();
        Map<String, Object> departmentStats = new HashMap<>();
        
        int totalAppraisals = 0;
        int totalApproved = 0;
        
        for (Department department : allDepartments) {
            // Get appraisals for this department and academic year
            List<AppraisalForm> deptAppraisals = appraisalFormRepository.findByAcademicYear(academicYear)
                    .stream()
                    .filter(form -> form.getUser().getDepartment().getId().equals(department.getId()))
                    .collect(Collectors.toList());
            
            int deptTotal = deptAppraisals.size();
            int deptApproved = (int) deptAppraisals.stream()
                    .filter(form -> form.getStatus() == AppraisalStatus.COMPLETED)
                    .count();
            int deptPending = deptTotal - deptApproved;
            
            departmentStats.put(department.getName(), Map.of(
                    "total", deptTotal,
                    "approved", deptApproved,
                    "pending", deptPending,
                    "approvalRate", deptTotal > 0 ? (double) deptApproved / deptTotal : 0.0
            ));
            
            totalAppraisals += deptTotal;
            totalApproved += deptApproved;
        }
        
        stats.put("departmentBreakdown", departmentStats);
        stats.put("overallApprovalRate", totalAppraisals > 0 ? (double) totalApproved / totalAppraisals : 0.0);
        stats.put("academicYear", academicYear);
        stats.put("totalAppraisals", totalAppraisals);
        stats.put("totalDepartments", allDepartments.size());
        
        return stats;
    }

    @Override
    public byte[] exportReviewSummary(String academicYear, String format) {
        String content = "Committee Review Summary for " + academicYear;
        return content.getBytes();
    }

    @Override
    public void flagAppraisalForSpecialAttention(UUID formId, String flagReason, String priority) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        log.info("Appraisal {} flagged for special attention: {} (Priority: {})", 
                formId, flagReason, priority);
    }

    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .userFullName(form.getUser().getFullName())
                .build();
    }

    private ReviewDTO mapReviewToDTO(Review review) {
        ReviewDTO dto = new ReviewDTO();
        dto.setId(review.getId());
        dto.setAppraisalFormId(review.getAppraisalForm().getId());
        dto.setReviewerId(review.getReviewer().getId());
        dto.setDecision(review.getDecision().name());
        dto.setRemarks(review.getRemarks());
        dto.setLevel(review.getLevel().name());
        dto.setReviewedAt(review.getReviewedAt());
        return dto;
    }
    
    private String getCurrentAcademicYear() {
        LocalDate now = LocalDate.now();
        int year = now.getYear();
        
        // Academic year typically starts from June/July
        if (now.getMonthValue() >= 6) {
            return year + "-" + String.valueOf(year + 1).substring(2);
        } else {
            return (year - 1) + "-" + String.valueOf(year).substring(2);
        }
    }
    
    private User getCurrentUser() {
        try {
            Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (principal instanceof UserPrincipal userPrincipal) {
                return userRepository.findById(userPrincipal.getId())
                        .orElseThrow(() -> new ResourceNotFoundException("Current user not found"));
            } else {
                String email = SecurityContextHolder.getContext().getAuthentication().getName();
                return userRepository.findByEmail(email)
                        .orElseThrow(() -> new ResourceNotFoundException("Current user not found"));
            }
        } catch (Exception e) {
            log.warn("Could not get current user from security context", e);
            return null;
        }
    }
} 