package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "conference_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ConferenceScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Conference Details
    @Column(name = "conference_name", nullable = false, columnDefinition = "TEXT")
    private String conferenceName;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "conference_type", nullable = false)
    private ConferenceType conferenceType;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "participation_type", nullable = false)
    private ParticipationType participationType; // ORGANIZED or ATTENDED
    
    @Column(name = "organizing_institute", length = 200)
    private String organizingInstitute;
    
    @Column(name = "place", length = 100)
    private String place;
    
    @Column(name = "start_date")
    private LocalDate startDate;
    
    @Column(name = "end_date")
    private LocalDate endDate;
    
    @Column(name = "duration_days", nullable = false)
    @Builder.Default
    private Integer durationDays = 1;
    
    // Role Details (for ORGANIZED conferences)
    @Enumerated(EnumType.STRING)
    @Column(name = "faculty_role")
    private FacultyRole facultyRole;
    
    // NPTEL/SWAYAM Details (for ATTENDED conferences)
    @Column(name = "is_nptel_swayam", nullable = false)
    @Builder.Default
    private Boolean isNPTELSWAYAM = false;
    
    @Column(name = "course_duration_weeks")
    private Integer courseDurationWeeks;
    
    @Column(name = "minimum_pass_percentage", precision = 5, scale = 2)
    private BigDecimal minimumPassPercentage;
    
    // Scoring
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // Verification
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    @Column(name = "certificate_path", columnDefinition = "TEXT")
    private String certificatePath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate duration
    public void calculateDuration() {
        if (startDate != null && endDate != null) {
            this.durationDays = (int) java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate) + 1;
        }
    }
    
    // Auto-calculate points based on type, role, and duration
    public void calculatePoints() {
        if (participationType == ParticipationType.ORGANIZED) {
            this.autoCalculatedPoints = calculateOrganizedConferencePoints();
        } else if (participationType == ParticipationType.ATTENDED) {
            this.autoCalculatedPoints = calculateAttendedConferencePoints();
        }
        
        if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
            this.pointsClaimed = autoCalculatedPoints;
        }
    }
    
    private BigDecimal calculateOrganizedConferencePoints() {
        // Based on Annexure VII - Table 5
        if (conferenceType == ConferenceType.INTERNATIONAL_CONFERENCE) {
            return switch (facultyRole) {
                case CONFERENCE_CHAIR, CONVENER, COORDINATOR, GUEST_EDITOR -> new BigDecimal("10");
                case CO_CHAIR, CO_CONVENER, CO_COORDINATOR -> new BigDecimal("8");
                case ORGANIZING_COMMITTEE_MEMBER -> new BigDecimal("6");
                case ADVISORY_MEMBER, TECHNICAL_COMMITTEE_MEMBER -> new BigDecimal("4");
                default -> BigDecimal.ZERO;
            };
        } else if (conferenceType == ConferenceType.FDP_WORKSHOP_STTP) {
            if (durationDays >= 5) {
                return switch (facultyRole) {
                    case CONVENER, COORDINATOR, CO_CONVENER, CO_COORDINATOR -> new BigDecimal("3");
                    case ORGANIZING_COMMITTEE_MEMBER, TECHNICAL_COMMITTEE_MEMBER -> new BigDecimal("2");
                    case ADVISORY_MEMBER -> new BigDecimal("1");
                    default -> BigDecimal.ZERO;
                };
            } else if (durationDays >= 2) {
                return switch (facultyRole) {
                    case CONVENER, COORDINATOR, CO_CONVENER, CO_COORDINATOR -> new BigDecimal("2");
                    case ORGANIZING_COMMITTEE_MEMBER, TECHNICAL_COMMITTEE_MEMBER -> new BigDecimal("1");
                    case ADVISORY_MEMBER -> new BigDecimal("1");
                    default -> BigDecimal.ZERO;
                };
            } else { // 1 day
                return new BigDecimal("1");
            }
        }
        return BigDecimal.ZERO;
    }
    
    private BigDecimal calculateAttendedConferencePoints() {
        // Based on Annexure VIII - Table 6
        if (isNPTELSWAYAM && courseDurationWeeks != null && minimumPassPercentage != null) {
            if (minimumPassPercentage.compareTo(new BigDecimal("60")) >= 0) {
                if (courseDurationWeeks >= 12) {
                    return new BigDecimal("5");
                } else if (courseDurationWeeks >= 8) {
                    return new BigDecimal("3");
                } else if (courseDurationWeeks >= 4) {
                    return new BigDecimal("1");
                }
            }
        } else {
            // Regular conferences/FDPs attended
            if (conferenceType == ConferenceType.INTERNATIONAL_CONFERENCE) {
                return new BigDecimal("5"); // International conferences
            } else if (conferenceType == ConferenceType.FDP_WORKSHOP_STTP) {
                if (durationDays >= 5) {
                    return new BigDecimal("5");
                } else if (durationDays >= 2) {
                    return new BigDecimal("3");
                } else {
                    return new BigDecimal("1");
                }
            }
        }
        return BigDecimal.ZERO;
    }
    
    // Validation
    public boolean isValidForScoring() {
        return conferenceName != null && !conferenceName.trim().isEmpty() &&
               conferenceType != null &&
               participationType != null &&
               durationDays != null && durationDays > 0;
    }
} 