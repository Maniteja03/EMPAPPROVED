package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    // Rate limiting: Max 20 review submissions per hour per reviewer
    public ResponseEntity<ReviewDTO> submitReview(@Valid @RequestBody ReviewDTO dto) {
        // SECURITY FIX: Automatically use current authenticated user as reviewer
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("Review submitted for form {} by authenticated user {}", dto.getAppraisalFormId(), currentUserEmail);
        
        // Pass the current user email to the service instead of trusting client reviewerId
        ReviewDTO submittedReview = reviewService.submitReview(dto, currentUserEmail);
        return new ResponseEntity<>(submittedReview, HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<ReviewDTO>> getReviews(@PathVariable UUID formId) {
        log.info("Fetching reviews for form {}", formId);
        return ResponseEntity.ok(reviewService.getReviewsByFormId(formId));
    }
}
