package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.CitationScoring;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface CitationScoringRepository extends JpaRepository<CitationScoring, UUID> {
    
    List<CitationScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT cs FROM CitationScoring cs WHERE cs.appraisalScoring.id = :scoringId ORDER BY cs.calendarYear DESC")
    List<CitationScoring> findByAppraisalScoringIdOrderByYear(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT cs FROM CitationScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<CitationScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT cs FROM CitationScoring cs WHERE cs.isVerified = false")
    List<CitationScoring> findUnverifiedCitations();
    
    @Query("SELECT cs FROM CitationScoring cs WHERE cs.scopusAuthorId = :scopusId")
    List<CitationScoring> findByScopusAuthorId(@Param("scopusId") String scopusId);
    
    @Query("SELECT SUM(cs.numberOfCitations) FROM CitationScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear")
    Long getTotalCitationsByAcademicYear(@Param("academicYear") String academicYear);
} 