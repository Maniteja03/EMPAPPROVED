package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.FormLock;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.ReviewLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface FormLockRepository extends JpaRepository<FormLock, UUID> {
    
    // Find active lock for a specific form
    @Query("SELECT fl FROM FormLock fl WHERE fl.formId = :formId AND fl.isActive = true AND fl.expiresAt > :now")
    Optional<FormLock> findActiveLockByFormId(@Param("formId") UUID formId, @Param("now") LocalDateTime now);
    
    // Find all active locks for a specific reviewer
    @Query("SELECT fl FROM FormLock fl WHERE fl.reviewer = :reviewer AND fl.isActive = true AND fl.expiresAt > :now")
    List<FormLock> findActiveLocksByReviewer(@Param("reviewer") User reviewer, @Param("now") LocalDateTime now);
    
    // Find all expired locks
    @Query("SELECT fl FROM FormLock fl WHERE fl.isActive = true AND fl.expiresAt <= :now")
    List<FormLock> findExpiredLocks(@Param("now") LocalDateTime now);
    
    // Deactivate expired locks (bulk update)
    @Modifying
    @Query("UPDATE FormLock fl SET fl.isActive = false WHERE fl.isActive = true AND fl.expiresAt <= :now")
    int deactivateExpiredLocks(@Param("now") LocalDateTime now);
    
    // Check if form is currently locked by any reviewer
    @Query("SELECT COUNT(fl) > 0 FROM FormLock fl WHERE fl.formId = :formId AND fl.isActive = true AND fl.expiresAt > :now")
    boolean isFormLocked(@Param("formId") UUID formId, @Param("now") LocalDateTime now);
    
    // Check if form is locked by specific reviewer
    @Query("SELECT COUNT(fl) > 0 FROM FormLock fl WHERE fl.formId = :formId AND fl.reviewer = :reviewer AND fl.isActive = true AND fl.expiresAt > :now")
    boolean isFormLockedByReviewer(@Param("formId") UUID formId, @Param("reviewer") User reviewer, @Param("now") LocalDateTime now);
    
    // Find locks by review level
    @Query("SELECT fl FROM FormLock fl WHERE fl.reviewLevel = :level AND fl.isActive = true AND fl.expiresAt > :now")
    List<FormLock> findActiveLocksByLevel(@Param("level") ReviewLevel level, @Param("now") LocalDateTime now);
    
    // Deactivate specific lock
    @Modifying
    @Query("UPDATE FormLock fl SET fl.isActive = false WHERE fl.id = :lockId")
    int deactivateLock(@Param("lockId") UUID lockId);
    
    // Get reviewer's current workload (number of active locks)
    @Query("SELECT COUNT(fl) FROM FormLock fl WHERE fl.reviewer = :reviewer AND fl.isActive = true AND fl.expiresAt > :now")
    long getReviewerWorkload(@Param("reviewer") User reviewer, @Param("now") LocalDateTime now);
} 