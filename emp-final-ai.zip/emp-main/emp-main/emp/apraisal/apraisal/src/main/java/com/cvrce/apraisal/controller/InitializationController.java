package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.RoleRepository;
import com.cvrce.apraisal.repo.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/init")
@RequiredArgsConstructor
@Slf4j
public class InitializationController {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Value("${app.initialization.enabled:true}")
    private boolean initializationEnabled;

    /**
     * TEMPORARY ENDPOINT: Create super admin for first-time setup
     * This endpoint should be DISABLED after first use
     * 
     * POST /api/init/create-super-admin
     * Body: {
     *   "email": "admin@college.edu",
     *   "fullName": "System Administrator",
     *   "employeeId": "ADMIN001",
     *   "password": "YourSecurePassword123!"
     * }
     */
    @PostMapping("/create-super-admin")
    public ResponseEntity<?> createSuperAdmin(@RequestBody Map<String, String> request) {
        
        // Security check - disable after first admin is created
        if (!initializationEnabled) {
            return ResponseEntity.badRequest()
                    .body("❌ Initialization is disabled. Super admin already exists.");
        }
        
        try {
            String email = request.get("email");
            String fullName = request.get("fullName");
            String employeeId = request.get("employeeId");
            String password = request.get("password");
            
            // Validation
            if (email == null || fullName == null || employeeId == null || password == null) {
                return ResponseEntity.badRequest()
                        .body("❌ Missing required fields: email, fullName, employeeId, password");
            }
            
            // Check if admin already exists
            if (userRepository.existsByEmail(email)) {
                return ResponseEntity.badRequest()
                        .body("❌ User with email " + email + " already exists");
            }
            
            // Initialize basic data
            initializeRolesAndDepartments();
            
            // Get required entities
            Role adminRole = roleRepository.findByName("ADMIN")
                    .orElseThrow(() -> new RuntimeException("Admin role not found"));
            
            Department adminDept = departmentRepository.findByName("Administration")
                    .orElseThrow(() -> new RuntimeException("Administration department not found"));
            
            // Create Super Admin
            User superAdmin = User.builder()
                    .id(UUID.randomUUID())
                    .employeeId(employeeId)
                    .fullName(fullName)
                    .email(email)
                    .password(passwordEncoder.encode(password))
                    .enabled(true)
                    .deleted(false)
                    .dateOfJoining(LocalDate.now())
                    .department(adminDept)
                    .roles(Collections.singleton(adminRole))
                    .build();
            
            userRepository.save(superAdmin);
            
            // Prepare response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "SUCCESS");
            response.put("message", "🎯 Super Admin created successfully!");
            response.put("email", email);
            response.put("employeeId", employeeId);
            response.put("warning", "⚠️ IMPORTANT: This endpoint is now DISABLED for security. Change app.initialization.enabled=false in config.");
            
            log.info("🎯 SUPER ADMIN CREATED: {} ({})", email, employeeId);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("❌ Failed to create super admin: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body("❌ Failed to create super admin: " + e.getMessage());
        }
    }
    
    /**
     * Check initialization status
     */
    @GetMapping("/status")
    public ResponseEntity<?> getInitializationStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("initializationEnabled", initializationEnabled);
        status.put("adminExists", userRepository.existsByEmail("admin@college.edu"));
        status.put("rolesCount", roleRepository.count());
        status.put("departmentsCount", departmentRepository.count());
        status.put("usersCount", userRepository.count());
        
        return ResponseEntity.ok(status);
    }
    
    private void initializeRolesAndDepartments() {
        // Create roles if not exist
        String[] roleNames = {"ADMIN", "STAFF", "DCM", "HOD", "COMMITTEE", "CHAIRPERSON", "PRINCIPAL"};
        for (String roleName : roleNames) {
            if (!roleRepository.existsByName(roleName)) {
                roleRepository.save(Role.builder().name(roleName).build());
            }
        }
        
        // Create departments if not exist
        String[] departments = {
            "Computer Science Engineering",
            "Administration"
        };
        for (String deptName : departments) {
            if (!departmentRepository.existsByName(deptName)) {
                departmentRepository.save(Department.builder()
                        .name(deptName).build());
            }
        }
    }
} 