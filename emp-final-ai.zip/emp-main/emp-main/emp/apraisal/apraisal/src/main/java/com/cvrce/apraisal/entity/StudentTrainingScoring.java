package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "student_training_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class StudentTrainingScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "training_type", nullable = false)
    private StudentTrainingType trainingType;
    
    // Common fields
    @Column(name = "title", nullable = false, length = 200)
    private String title;
    
    @Column(name = "academic_year", nullable = false, length = 10)
    private String academicYear;
    
    @Column(name = "semester", length = 20)
    private String semester;
    
    // E-Box Training specific fields
    @Column(name = "branch_section", length = 50)
    private String branchSection;
    
    @Column(name = "students_allotted")
    private Integer studentsAllotted;
    
    @Column(name = "students_completed_70_percent")
    private Integer studentsCompleted70Percent;
    
    // Student Certification specific fields
    @Column(name = "company_name", length = 200)
    private String companyName;
    
    @Column(name = "students_certified")
    private Integer studentsCertified;
    
    @Column(name = "certification_percentage", precision = 5, scale = 2)
    private BigDecimal certificationPercentage;
    
    // Scoring
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // Verification
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points based on training type
    public void calculatePoints() {
        if (trainingType == StudentTrainingType.E_BOX_TRAINING) {
            this.autoCalculatedPoints = calculateEBoxPoints();
        } else if (trainingType == StudentTrainingType.STUDENT_CERTIFICATION) {
            this.autoCalculatedPoints = calculateCertificationPoints();
        }
        
        if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
            this.pointsClaimed = autoCalculatedPoints;
        }
    }
    
    private BigDecimal calculateEBoxPoints() {
        if (studentsCompleted70Percent == null || studentsCompleted70Percent <= 0) {
            return BigDecimal.ZERO;
        }
        
        // Points distribution from Part C - E-Box Training table
        if (studentsCompleted70Percent >= 17) {
            return new BigDecimal("5");
        } else if (studentsCompleted70Percent >= 16) {
            return new BigDecimal("4");
        } else if (studentsCompleted70Percent >= 10) {
            return new BigDecimal("3");
        } else if (studentsCompleted70Percent >= 6) {
            return new BigDecimal("2");
        } else if (studentsCompleted70Percent >= 1) {
            return new BigDecimal("1");
        }
        return BigDecimal.ZERO;
    }
    
    private BigDecimal calculateCertificationPoints() {
        if (certificationPercentage == null) {
            calculateCertificationPercentage();
        }
        
        if (certificationPercentage != null) {
            // Formula: (Percentage × 5) / 100
            return certificationPercentage.multiply(new BigDecimal("5"))
                    .divide(new BigDecimal("100"), 2, java.math.RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }
    
    // Calculate certification percentage
    public void calculateCertificationPercentage() {
        if (studentsAllotted != null && studentsCertified != null && studentsAllotted > 0) {
            this.certificationPercentage = new BigDecimal(studentsCertified)
                    .divide(new BigDecimal(studentsAllotted), 2, java.math.RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("100"));
        }
    }
    
    // Validation
    public boolean isValidForScoring() {
        return trainingType != null &&
               studentsAllotted != null && studentsAllotted > 0;
    }
} 