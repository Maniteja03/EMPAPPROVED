package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

import com.cvrce.apraisal.enums.AppraisalStatus;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
@Table(name = "appraisal_forms")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppraisalForm {

    @Id
    @GeneratedValue
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String academicYear; // e.g., "2024-25"

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AppraisalStatus status; // SUBMITTED, REUPLOAD_REQUIRED, etc.

    private LocalDate submittedDate;

    private double totalScore;

    @Builder.Default
    private boolean locked = false; // Lock after deadline

    @Builder.Default
    private boolean deleted = false;
    
    // NEW: Role submitted as (for multi-role users)
    @Column(name = "submitted_as_role", length = 50)
    private String submittedAsRole;
    
    // NEW: Scoring relationship
    @OneToOne(mappedBy = "appraisalForm", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private AppraisalScoring appraisalScoring;
    
    @CreationTimestamp
    @Column(updatable = false)
    private LocalDate createdAt;

    @UpdateTimestamp
    @Column
    private LocalDate updatedAt;
    
    // Helper method to initialize scoring
    public void initializeScoring(StaffDesignation designation) {
        if (appraisalScoring == null) {
            appraisalScoring = AppraisalScoring.builder()
                    .appraisalForm(this)
                    .build();
            appraisalScoring.initializeWithDesignation(designation);
        }
    }
    
    // Helper method to get total calculated score
    public java.math.BigDecimal getCalculatedTotalScore() {
        return appraisalScoring != null ? appraisalScoring.getTotalScore() : java.math.BigDecimal.ZERO;
    }
    
    // Update legacy totalScore field from calculated score
    public void updateTotalScore() {
        if (appraisalScoring != null) {
            this.totalScore = appraisalScoring.getTotalScore().doubleValue();
        }
    }
}
