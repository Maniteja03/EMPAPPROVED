package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.service.FileUploadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "https://your-domain.com"})
public class FileUploadController {
    
    private final FileUploadService fileUploadService;
    
    // Upload single proof document
    @PostMapping("/upload-proof")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> uploadProofDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam("appraisalFormId") UUID appraisalFormId,
            @RequestParam("componentType") String componentType,
            @RequestParam("componentId") String componentId) {
        
        log.info("Uploading proof document for appraisal: {}, component: {}", appraisalFormId, componentType);
        
        try {
            String filePath = fileUploadService.uploadProofDocument(file, appraisalFormId, componentType, componentId);
            String fileUrl = fileUploadService.getProofDocumentUrl(filePath);
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "filePath", filePath,
                    "fileUrl", fileUrl,
                    "message", "File uploaded successfully"
            ));
            
        } catch (Exception e) {
            log.error("Error uploading proof document", e);
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Failed to upload file: " + e.getMessage()
            ));
        }
    }
    
    // Upload multiple proof documents
    @PostMapping("/upload-multiple-proofs")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> uploadMultipleProofDocuments(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam("appraisalFormId") UUID appraisalFormId,
            @RequestParam("componentType") String componentType) {
        
        log.info("Uploading {} proof documents for appraisal: {}, component: {}", 
                files.size(), appraisalFormId, componentType);
        
        try {
            List<String> filePaths = fileUploadService.uploadMultipleProofDocuments(files, appraisalFormId, componentType);
            
            List<String> fileUrls = filePaths.stream()
                    .map(fileUploadService::getProofDocumentUrl)
                    .toList();
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "filePaths", filePaths,
                    "fileUrls", fileUrls,
                    "uploadedCount", filePaths.size(),
                    "message", "Files uploaded successfully"
            ));
            
        } catch (Exception e) {
            log.error("Error uploading multiple proof documents", e);
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Failed to upload files: " + e.getMessage()
            ));
        }
    }
    
    // Delete proof document
    @DeleteMapping("/delete-proof")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> deleteProofDocument(@RequestParam("filePath") String filePath) {
        log.info("Deleting proof document: {}", filePath);
        
        boolean deleted = fileUploadService.deleteProofDocument(filePath);
        
        if (deleted) {
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "File deleted successfully"
            ));
        } else {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Failed to delete file"
            ));
        }
    }
    
    // Validate file before upload
    @PostMapping("/validate")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> validateFile(@RequestParam("file") MultipartFile file) {
        log.info("Validating file: {}", file.getOriginalFilename());
        
        Map<String, Object> validation = fileUploadService.validateFile(file);
        return ResponseEntity.ok(validation);
    }
    
    // Get file upload configuration
    @GetMapping("/config")
    @PreAuthorize("hasAnyRole('STAFF', 'DCM', 'HOD', 'COMMITTEE', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> getFileUploadConfig() {
        return ResponseEntity.ok(Map.of(
                "allowedFileTypes", fileUploadService.getAllowedFileTypes(),
                "maxFileSize", fileUploadService.getMaxFileSize(),
                "maxFileSizeMB", fileUploadService.getMaxFileSize() / 1024 / 1024
        ));
    }
}
