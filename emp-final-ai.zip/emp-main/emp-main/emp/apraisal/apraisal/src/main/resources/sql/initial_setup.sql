-- ====================================================================
-- EMPLOYEE APPRAISAL SYSTEM - INITIAL SETUP SQL
-- Run this ONCE after creating the database schema
-- ====================================================================

-- 1. Create Departments
INSERT INTO departments (id, name, code, created_at) VALUES 
(1, 'Computer Science Engineering', 'CSE', NOW()),
(2, 'Mechanical Engineering', 'MECH', NOW()),
(3, 'Electrical Engineering', 'ECE', NOW()),
(4, 'Civil Engineering', 'CIVIL', NOW()),
(5, 'Electronics and Communication', 'EC', NOW()),
(6, 'Information Science', 'IS', NOW()),
(7, 'Administration', 'ADMIN', NOW()),
(8, 'Management', 'MGMT', NOW());

-- 2. Create Roles
INSERT INTO roles (id, name, created_at) VALUES 
(1, 'ADMIN', NOW()),
(2, 'STAFF', NOW()),
(3, 'DCM', NOW()),
(4, 'HOD', NOW()),
(5, 'COMMITTEE', NOW()),
(6, 'CHAIRPERSON', NOW()),
(7, 'PRINCIPAL', NOW());

-- 3. Create Super Admin User
-- Password: Admin@123 (BCrypt encoded)
INSERT INTO users (
    id, employee_id, full_name, email, password, 
    enabled, deleted, date_of_joining, department_id, 
    created_at, updated_at
) VALUES (
    UUID(), 
    'ADMIN001', 
    'System Administrator', 
    'admin@college.edu',
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',  -- Admin@123
    true, 
    false, 
    '2024-01-01', 
    7,  -- Administration department
    NOW(), 
    NOW()
);

-- 4. Assign ADMIN role to Super Admin
INSERT INTO user_roles (user_id, role_id) 
SELECT u.id, r.id 
FROM users u, roles r 
WHERE u.email = 'admin@college.edu' AND r.name = 'ADMIN';

-- 5. Create Sample Principal (Optional)
INSERT INTO users (
    id, employee_id, full_name, email, password, 
    enabled, deleted, date_of_joining, department_id, 
    created_at, updated_at
) VALUES (
    UUID(), 
    'PRIN001', 
    'Dr. Principal Name', 
    'principal@college.edu',
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',  -- Admin@123
    true, 
    false, 
    '2024-01-01', 
    8,  -- Management department
    NOW(), 
    NOW()
);

-- Assign PRINCIPAL role
INSERT INTO user_roles (user_id, role_id) 
SELECT u.id, r.id 
FROM users u, roles r 
WHERE u.email = 'principal@college.edu' AND r.name = 'PRINCIPAL';

-- ====================================================================
-- VERIFICATION QUERIES (Run these to confirm setup)
-- ====================================================================

-- Check if departments were created
SELECT * FROM departments;

-- Check if roles were created  
SELECT * FROM roles;

-- Check if admin user was created
SELECT u.employee_id, u.full_name, u.email, u.enabled, d.name as department
FROM users u 
JOIN departments d ON u.department_id = d.id 
WHERE u.email = 'admin@college.edu';

-- Check admin roles
SELECT u.email, r.name as role
FROM users u 
JOIN user_roles ur ON u.id = ur.user_id
JOIN roles r ON ur.role_id = r.id
WHERE u.email = 'admin@college.edu';

-- ====================================================================
-- INITIAL SUPER ADMIN CREDENTIALS
-- Email: admin@college.edu
-- Password: Admin@123
-- ==================================================================== 