package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.PatentScoring;
import com.cvrce.apraisal.enums.PatentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PatentScoringRepository extends JpaRepository<PatentScoring, UUID> {
    
    List<PatentScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT ps FROM PatentScoring ps WHERE ps.appraisalScoring.id = :scoringId ORDER BY ps.publishedGrantedDate DESC")
    List<PatentScoring> findByAppraisalScoringIdOrderByDate(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT ps FROM PatentScoring ps WHERE ps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<PatentScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT ps FROM PatentScoring ps WHERE ps.patentStatus = :status")
    List<PatentScoring> findByPatentStatus(@Param("status") PatentStatus status);
    
    @Query("SELECT ps FROM PatentScoring ps WHERE ps.isVerified = false")
    List<PatentScoring> findUnverifiedPatents();
    
    @Query("SELECT COUNT(ps), ps.patentStatus FROM PatentScoring ps WHERE ps.appraisalScoring.appraisalForm.academicYear = :academicYear GROUP BY ps.patentStatus")
    List<Object[]> getPatentStatisticsByStatus(@Param("academicYear") String academicYear);
} 