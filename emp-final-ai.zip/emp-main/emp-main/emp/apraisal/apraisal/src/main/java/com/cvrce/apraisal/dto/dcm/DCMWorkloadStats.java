package com.cvrce.apraisal.dto.dcm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DCMWorkloadStats {
    private String departmentName;
    private String academicYear;
    private int totalDCMs;
    private int activeDCMs;
    private int totalFormsAssigned;
    private int formsCompleted;
    private int formsPending;
    private double averageFormsPerDCM;
    private double completionRate;
    private List<DCMWorkloadDetail> dcmDetails;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DCMWorkloadDetail {
        private String dcmName;
        private String email;
        private int formsAssigned;
        private int formsCompleted;
        private double completionRate;
        private String workloadStatus;
    }
} 