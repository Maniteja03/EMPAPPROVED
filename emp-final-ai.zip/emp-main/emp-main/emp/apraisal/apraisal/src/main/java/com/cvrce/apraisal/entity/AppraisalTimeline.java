package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "appraisal_timelines")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppraisalTimeline {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @Column(name = "academic_year", nullable = false, unique = true, length = 20)
    private String academicYear; // e.g., "2024-25"
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_chairperson_id", nullable = false)
    private User createdByChairperson; // Chairperson who set this timeline
    
    // Phase 1: Staff Upload Phase
    @Column(name = "staff_upload_start_date", nullable = false)
    private LocalDate staffUploadStartDate; // When staff can start uploading
    
    @Column(name = "staff_upload_deadline", nullable = false)
    private LocalDate staffUploadDeadline; // Staff MUST upload before this date
    
    // Phase 2: HOD DCM Assignment Phase  
    @Column(name = "hod_dcm_assignment_deadline", nullable = false)
    private LocalDate hodDcmAssignmentDeadline; // HODs must assign DCMs by this date
    
    // Phase 3: Department Review Phase (DCM Review)
    @Column(name = "dcm_review_deadline", nullable = false)
    private LocalDate dcmReviewDeadline; // DCMs must complete reviews by this date
    
    // Phase 4: HOD Review Phase
    @Column(name = "hod_review_deadline", nullable = false)
    private LocalDate hodReviewDeadline; // HODs must complete reviews by this date
    
    // Phase 5: Committee Review Phase
    @Column(name = "committee_review_deadline", nullable = false)
    private LocalDate committeeReviewDeadline; // Committee must complete reviews by this date
    
    // Phase 6: Chairperson Review Phase
    @Column(name = "chairperson_review_deadline", nullable = false)
    private LocalDate chairpersonReviewDeadline; // Chairperson completes by this date
    
    // Phase 7: Principal Bulk Submission
    @Column(name = "principal_bulk_submission_date", nullable = false)
    private LocalDate principalBulkSubmissionDate; // Principal final bulk submission
    
    // Timeline status and metadata
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;
    
    @Column(name = "current_phase", nullable = false, length = 50)
    @Builder.Default
    private String currentPhase = "STAFF_UPLOAD"; // Current active phase
    
    @Column(name = "timeline_description", length = 500)
    private String timelineDescription; // Optional description from Chairperson
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    @Column(name = "finalized_at")
    private LocalDateTime finalizedAt; // When timeline was locked/finalized
    
    // Notification settings
    @Column(name = "send_deadline_reminders", nullable = false)
    @Builder.Default
    private Boolean sendDeadlineReminders = true;
    
    @Column(name = "reminder_days_before", nullable = false)
    @Builder.Default
    private Integer reminderDaysBeforeDeadline = 3; // Send reminder 3 days before each deadline
    
    // Statistics tracking
    @Column(name = "total_staff_count")
    private Integer totalStaffCount; // Total staff who should submit
    
    @Column(name = "total_departments_count")
    private Integer totalDepartmentsCount; // Total departments involved
    
    // Helper methods
    
    /**
     * Get current active phase based on today's date
     */
    public String getCurrentActivePhase() {
        LocalDate today = LocalDate.now();
        
        if (today.isBefore(staffUploadStartDate)) {
            return "TIMELINE_SET";
        } else if (today.isBefore(staffUploadDeadline) || today.isEqual(staffUploadDeadline)) {
            return "STAFF_UPLOAD";
        } else if (today.isBefore(hodDcmAssignmentDeadline) || today.isEqual(hodDcmAssignmentDeadline)) {
            return "HOD_DCM_ASSIGNMENT";
        } else if (today.isBefore(dcmReviewDeadline) || today.isEqual(dcmReviewDeadline)) {
            return "DCM_REVIEW";
        } else if (today.isBefore(hodReviewDeadline) || today.isEqual(hodReviewDeadline)) {
            return "HOD_REVIEW";
        } else if (today.isBefore(committeeReviewDeadline) || today.isEqual(committeeReviewDeadline)) {
            return "COMMITTEE_REVIEW";
        } else if (today.isBefore(chairpersonReviewDeadline) || today.isEqual(chairpersonReviewDeadline)) {
            return "CHAIRPERSON_REVIEW";
        } else if (today.isBefore(principalBulkSubmissionDate) || today.isEqual(principalBulkSubmissionDate)) {
            return "PRINCIPAL_REVIEW";
        } else {
            return "COMPLETED";
        }
    }
    
    /**
     * Check if staff upload is currently allowed
     */
    public boolean isStaffUploadAllowed() {
        LocalDate today = LocalDate.now();
        return today.isAfter(staffUploadStartDate.minusDays(1)) && 
               today.isBefore(staffUploadDeadline.plusDays(1)) && 
               isActive;
    }
    
    /**
     * Check if HOD DCM assignment is currently allowed
     */
    public boolean isHodDcmAssignmentAllowed() {
        LocalDate today = LocalDate.now();
        return today.isAfter(staffUploadDeadline) && 
               today.isBefore(hodDcmAssignmentDeadline.plusDays(1)) && 
               isActive;
    }
    
    /**
     * Check if specific phase is currently active
     */
    public boolean isPhaseActive(String phase) {
        return phase.equals(getCurrentActivePhase()) && isActive;
    }
    
    /**
     * Get days remaining for current phase
     */
    public long getDaysRemainingForCurrentPhase() {
        LocalDate today = LocalDate.now();
        String currentPhase = getCurrentActivePhase();
        
        return switch (currentPhase) {
            case "STAFF_UPLOAD" -> today.until(staffUploadDeadline).getDays();
            case "HOD_DCM_ASSIGNMENT" -> today.until(hodDcmAssignmentDeadline).getDays();
            case "DCM_REVIEW" -> today.until(dcmReviewDeadline).getDays();
            case "HOD_REVIEW" -> today.until(hodReviewDeadline).getDays();
            case "COMMITTEE_REVIEW" -> today.until(committeeReviewDeadline).getDays();
            case "CHAIRPERSON_REVIEW" -> today.until(chairpersonReviewDeadline).getDays();
            case "PRINCIPAL_REVIEW" -> today.until(principalBulkSubmissionDate).getDays();
            default -> 0;
        };
    }
    
    /**
     * Check if timeline is overdue (past final deadline)
     */
    public boolean isOverdue() {
        return LocalDate.now().isAfter(principalBulkSubmissionDate) && isActive;
    }
    
    /**
     * Get total timeline duration in days
     */
    public long getTotalTimelineDurationDays() {
        return staffUploadStartDate.until(principalBulkSubmissionDate).getDays();
    }
    
    /**
     * Calculate completion percentage based on current date
     */
    public double getCompletionPercentage() {
        LocalDate today = LocalDate.now();
        
        if (today.isBefore(staffUploadStartDate)) {
            return 0.0;
        } else if (today.isAfter(principalBulkSubmissionDate)) {
            return 100.0;
        } else {
            long totalDays = getTotalTimelineDurationDays();
            long daysPassed = staffUploadStartDate.until(today).getDays();
            return totalDays > 0 ? (double) daysPassed / totalDays * 100.0 : 0.0;
        }
    }
    
    /**
     * Finalize timeline (lock it from further changes)
     */
    public void finalizeTimeline() {
        this.finalizedAt = LocalDateTime.now();
    }
    
    /**
     * Check if timeline is finalized (locked)
     */
    public boolean isFinalized() {
        return finalizedAt != null;
    }
} 