package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.CommitteeAssignment;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CommitteeAssignmentRepository extends JpaRepository<CommitteeAssignment, UUID> {
    
    // Find all active committee members for current academic year
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true")
    List<CommitteeAssignment> findActiveCommitteeMembersForYear(@Param("academicYear") String academicYear);
    
    // Find committee assignment for a specific user
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.committeeMember = :member AND ca.academicYear = :academicYear AND ca.isActive = true")
    Optional<CommitteeAssignment> findActiveCommitteeAssignmentByMemberAndYear(@Param("member") User member, @Param("academicYear") String academicYear);
    
    // Get committee members from specific department (to exclude them from reviewing their own dept)
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.department = :department AND ca.academicYear = :academicYear AND ca.isActive = true")
    List<CommitteeAssignment> findCommitteeMembersByDepartmentAndYear(@Param("department") Department department, @Param("academicYear") String academicYear);
    
    // Get committee members with lowest workload for assignment (load balancing)
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true ORDER BY ca.workloadCount ASC")
    List<CommitteeAssignment> findCommitteeMembersOrderByWorkload(@Param("academicYear") String academicYear);
    
    // Get available committee members who can review forms from a specific department
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true AND ca.department != :excludeDepartment AND ca.workloadCount < :maxWorkload ORDER BY ca.workloadCount ASC")
    List<CommitteeAssignment> findAvailableCommitteeMembersExcludingDepartment(@Param("academicYear") String academicYear, @Param("excludeDepartment") Department excludeDepartment, @Param("maxWorkload") int maxWorkload);
    
    // Deactivate all committee assignments for current year (when reassigning)
    @Modifying
    @Query("UPDATE CommitteeAssignment ca SET ca.isActive = false, ca.deactivatedAt = CURRENT_TIMESTAMP WHERE ca.academicYear = :academicYear AND ca.isActive = true")
    int deactivateAllCommitteeAssignmentsForYear(@Param("academicYear") String academicYear);
    
    // Increment workload for specific committee member
    @Modifying
    @Query("UPDATE CommitteeAssignment ca SET ca.workloadCount = ca.workloadCount + 1 WHERE ca.id = :assignmentId")
    int incrementWorkload(@Param("assignmentId") UUID assignmentId);
    
    // Complete review and update stats
    @Modifying
    @Query("UPDATE CommitteeAssignment ca SET ca.workloadCount = CASE WHEN ca.workloadCount > 0 THEN ca.workloadCount - 1 ELSE 0 END, ca.completedReviews = ca.completedReviews + 1 WHERE ca.id = :assignmentId")
    int completeReview(@Param("assignmentId") UUID assignmentId);
    
    // Count active committee members for current year
    @Query("SELECT COUNT(ca) FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true")
    long countActiveCommitteeMembersForYear(@Param("academicYear") String academicYear);
    
    // Count committee members by department
    @Query("SELECT ca.department.name, COUNT(ca) FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true GROUP BY ca.department.name")
    List<Object[]> countCommitteeMembersByDepartment(@Param("academicYear") String academicYear);
    
    // Check if user is currently a committee member
    @Query("SELECT COUNT(ca) > 0 FROM CommitteeAssignment ca WHERE ca.committeeMember = :member AND ca.academicYear = :academicYear AND ca.isActive = true")
    boolean isUserCommitteeMember(@Param("member") User member, @Param("academicYear") String academicYear);
    
    // Get committee member with specific workload range
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.academicYear = :academicYear AND ca.isActive = true AND ca.workloadCount >= :minWorkload AND ca.workloadCount <= :maxWorkload")
    List<CommitteeAssignment> findCommitteeMembersByWorkloadRange(@Param("academicYear") String academicYear, @Param("minWorkload") int minWorkload, @Param("maxWorkload") int maxWorkload);
    
    // Get committee assignment history for a user
    @Query("SELECT ca FROM CommitteeAssignment ca WHERE ca.committeeMember = :member ORDER BY ca.assignedAt DESC")
    List<CommitteeAssignment> findCommitteeAssignmentHistory(@Param("member") User member);
} 