package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.service.ChairpersonService;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChairpersonServiceImpl implements ChairpersonService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final AppraisalWorkflowService workflowService;

    @Override
    public Map<String, Object> getChairpersonDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        
        List<AppraisalForm> pendingForms = appraisalFormRepository.findByStatus(AppraisalStatus.CHAIRPERSON_REVIEW);
        long pendingEvaluations = pendingForms.size();
        long completedEvaluations = reviewRepository.count();
        long totalAppraisals = appraisalFormRepository.count();
        long escalatedCases = 0; // Placeholder
        
        dashboard.put("pendingEvaluations", pendingEvaluations);
        dashboard.put("completedEvaluations", completedEvaluations);
        dashboard.put("totalAppraisals", totalAppraisals);
        dashboard.put("escalatedCases", escalatedCases);
        dashboard.put("institutionalOverview", getInstitutionalPerformanceOverview("2023-24", "DEPARTMENT"));
        dashboard.put("lastUpdated", LocalDateTime.now());
        
        return dashboard;
    }

    @Override
    public Page<AppraisalFormDTO> getPendingEvaluations(Pageable pageable, String department, String priority) {
        List<AppraisalForm> pendingForms = appraisalFormRepository.findByStatus(AppraisalStatus.CHAIRPERSON_REVIEW);
        
        // Simple department filtering
        if (department != null) {
            pendingForms = pendingForms.stream()
                    .filter(form -> form.getUser().getDepartment().getName().equals(department))
                    .collect(Collectors.toList());
        }
        
        List<AppraisalFormDTO> dtoList = pendingForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Manual pagination
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    @Transactional
    public ReviewDTO submitChairpersonEvaluation(ReviewDTO evaluationDTO, String currentUserEmail) {
        AppraisalForm appraisal = appraisalFormRepository.findById(evaluationDTO.getAppraisalFormId())
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.CHAIRPERSON_REVIEW) {
            throw new IllegalStateException("Appraisal is not in correct state for chairperson review");
        }
        
        // SECURITY FIX: Get reviewer from authenticated user, not from client
        User reviewer = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current user not found: " + currentUserEmail));
        
        Review review = Review.builder()
                .reviewer(reviewer)
                .appraisalForm(appraisal)
                .decision(ReviewDecision.valueOf(evaluationDTO.getDecision()))
                .remarks(evaluationDTO.getRemarks())
                .level(ReviewLevel.CHAIRPERSON_REVIEW)
                .reviewedAt(LocalDateTime.now())
                .build();
        
        Review savedReview = reviewRepository.save(review);
        
        // Update appraisal status using workflow service
        AppraisalStatus newStatus = workflowService.transitionToNextStage(
            evaluationDTO.getAppraisalFormId(), 
            appraisal.getStatus(), 
            evaluationDTO.getDecision()
        );
        appraisal.setStatus(newStatus);
        appraisalFormRepository.save(appraisal);
        
        log.info("Chairperson submitted evaluation for appraisal {} by authenticated user {}", 
                evaluationDTO.getAppraisalFormId(), currentUserEmail);
        
        return mapReviewToDTO(savedReview);
    }

    @Override
    public Map<String, Object> getComprehensiveEvaluationSummary(UUID formId) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        List<Review> allReviews = reviewRepository.findByAppraisalFormId(formId);
        
        Map<String, Object> summary = new HashMap<>();
        summary.put("appraisal", mapToDTO(appraisal));
        summary.put("reviewHistory", allReviews.stream().map(this::mapReviewToDTO).collect(Collectors.toList()));
        summary.put("stakeholderInputs", getStakeholderInputs(formId));
        summary.put("performanceMetrics", calculatePerformanceMetrics(appraisal));
        summary.put("recommendedAction", determineRecommendedAction(appraisal, allReviews));
        
        return summary;
    }

    @Override
    @Transactional
    public void overridePreviousDecision(UUID formId, String newDecision, String justification) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        log.warn("Chairperson overriding decision for appraisal {}: {} - Justification: {}", 
                formId, newDecision, justification);
        
        // Create override review record (simplified)
        User chairperson = userRepository.findAll().stream().findFirst().orElse(null);
        if (chairperson != null) {
            Review overrideReview = Review.builder()
                    .reviewer(chairperson)
                    .appraisalForm(appraisal)
                    .decision(ReviewDecision.valueOf(newDecision))
                    .remarks("OVERRIDE: " + justification)
                    .level(ReviewLevel.CHAIRPERSON_REVIEW)
                    .reviewedAt(LocalDateTime.now())
                    .build();
            
            reviewRepository.save(overrideReview);
            
            // Update appraisal status using workflow service
            AppraisalStatus newStatus = workflowService.transitionToNextStage(
                formId, 
                appraisal.getStatus(), 
                newDecision
            );
            appraisal.setStatus(newStatus);
            appraisalFormRepository.save(appraisal);
        }
    }

    @Override
    public void requestExpertReview(UUID formId, String expertArea, String specificExpertId, String reason) {
        log.info("Chairperson requesting expert review for appraisal {}: Area: {}, Expert: {}, Reason: {}", 
                formId, expertArea, specificExpertId, reason);
    }

    @Override
    public Map<String, Object> getInstitutionalPerformanceOverview(String academicYear, String groupBy) {
        Map<String, Object> overview = new HashMap<>();
        
        // Simplified metrics
        long totalFaculty = userRepository.count(); // Simplified
        List<AppraisalForm> yearForms = appraisalFormRepository.findByAcademicYear(academicYear != null ? academicYear : "2023-24");
        long submittedAppraisals = yearForms.size();
        double submissionRate = totalFaculty > 0 ? (double) submittedAppraisals / totalFaculty : 0.0;
        
        overview.put("totalFaculty", totalFaculty);
        overview.put("submittedAppraisals", submittedAppraisals);
        overview.put("submissionRate", submissionRate);
        overview.put("groupBy", groupBy);
        overview.put("academicYear", academicYear);
        
        // Department-wise breakdown (dynamic)
        if ("DEPARTMENT".equals(groupBy)) {
            List<Department> allDepartments = departmentRepository.findAll();
            Map<String, Object> departmentBreakdown = new HashMap<>();
            
            for (Department department : allDepartments) {
                long deptFaculty = userRepository.countByDepartmentName(department.getName());
                long deptSubmitted = yearForms.stream()
                        .filter(form -> form.getUser().getDepartment().getId().equals(department.getId()))
                        .count();
                double deptRate = deptFaculty > 0 ? (double) deptSubmitted / deptFaculty : 0.0;
                
                departmentBreakdown.put(department.getName(), Map.of(
                        "faculty", deptFaculty,
                        "submitted", deptSubmitted,
                        "rate", Math.round(deptRate * 100.0) / 100.0
                ));
            }
            overview.put("breakdown", departmentBreakdown);
        }
        
        return overview;
    }

    @Override
    public Map<String, Object> generatePolicyRecommendations(String academicYear) {
        Map<String, Object> recommendations = new HashMap<>();
        
        List<String> policyRecommendations = Arrays.asList(
                "Implement automated reminder system for appraisal submissions",
                "Standardize review criteria across departments",
                "Introduce peer review component in evaluation process",
                "Establish clear timeline for each review stage",
                "Create dashboard for real-time tracking of appraisal progress"
        );
        
        recommendations.put("recommendations", policyRecommendations);
        recommendations.put("basedOnData", "Analysis of " + academicYear + " appraisal patterns");
        recommendations.put("confidence", "High");
        recommendations.put("generatedAt", LocalDateTime.now());
        
        return recommendations;
    }

    @Override
    public void scheduleReviewMeeting(Map<String, Object> meetingDetails) {
        log.info("Chairperson scheduling review meeting: {}", meetingDetails);
    }

    @Override
    public byte[] generateAnnualAppraisalReport(String academicYear, String format) {
        log.info("Generating annual appraisal report for {} in format {}", academicYear, format);
        
        String content = "Annual Appraisal Report for " + academicYear + "\n" +
                        "Generated by Chairperson\n" +
                        "Date: " + LocalDateTime.now();
        
        return content.getBytes();
    }

    @Override
    public void updateEvaluationCriteria(Map<String, Object> criteriaConfig) {
        log.info("Chairperson updating evaluation criteria: {}", criteriaConfig);
    }

    @Override
    public Map<String, Object> analyzeReviewerPerformance(String academicYear, String reviewerRole) {
        Map<String, Object> analysis = new HashMap<>();
        
        analysis.put("averageReviewTime", "2.3 days");
        analysis.put("consistencyScore", 0.87);
        analysis.put("reviewQualityScore", 0.92);
        analysis.put("totalReviewsCompleted", 45);
        analysis.put("onTimeCompletionRate", 0.95);
        analysis.put("academicYear", academicYear);
        analysis.put("reviewerRole", reviewerRole);
        
        return analysis;
    }

    private Map<String, Object> getStakeholderInputs(UUID formId) {
        Map<String, Object> inputs = new HashMap<>();
        inputs.put("dcmInput", "Thorough documentation, meets department standards");
        inputs.put("hodInput", "Strong performance in research and teaching");
        inputs.put("committeeInput", "Exemplary service contribution");
        return inputs;
    }

    private Map<String, Object> calculatePerformanceMetrics(AppraisalForm appraisal) {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("teachingScore", 85.5);
        metrics.put("researchScore", 92.0);
        metrics.put("serviceScore", 78.0);
        metrics.put("overallScore", appraisal.getTotalScore());
        return metrics;
    }

    private String determineRecommendedAction(AppraisalForm appraisal, List<Review> reviews) {
        double totalScore = appraisal.getTotalScore();
        if (totalScore >= 90) return "PROMOTION_RECOMMENDED";
        else if (totalScore >= 80) return "SATISFACTORY_PERFORMANCE";
        else if (totalScore >= 70) return "IMPROVEMENT_NEEDED";
        else return "PERFORMANCE_REVIEW_REQUIRED";
    }

    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .userFullName(form.getUser().getFullName())
                .build();
    }

    private ReviewDTO mapReviewToDTO(Review review) {
        ReviewDTO dto = new ReviewDTO();
        dto.setId(review.getId());
        dto.setAppraisalFormId(review.getAppraisalForm().getId());
        dto.setReviewerId(review.getReviewer().getId());
        dto.setDecision(review.getDecision().name());
        dto.setRemarks(review.getRemarks());
        dto.setLevel(review.getLevel().name());
        dto.setReviewedAt(review.getReviewedAt());
        return dto;
    }
} 