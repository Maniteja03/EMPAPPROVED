package com.cvrce.apraisal.service;

import com.cvrce.apraisal.entity.AuditLog;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.UUID;

public interface AuditService {
    
    void logUserAction(User user, String action, String entity, String entityId, String description);
    
    void logUserAction(User user, String action, String entity, String entityId, 
                      String oldValues, String newValues, String description);
    
    void logSystemAction(String action, String entity, String entityId, String description);
    
    void logSecurityEvent(User user, String action, String description, String ipAddress, String userAgent);
    
    void logCriticalEvent(User user, String action, String entity, String entityId, 
                         String description, String additionalData);
    
    Page<AuditLog> getUserAuditLogs(UUID userId, Pageable pageable);
    
    Page<AuditLog> getEntityAuditLogs(String entity, String entityId, Pageable pageable);
    
    Page<AuditLog> getAuditLogsByAction(String action, Pageable pageable);
    
    Page<AuditLog> getAuditLogsByDateRange(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    
    Page<AuditLog> getSecurityAuditLogs(Pageable pageable);
    
    long getAuditLogCount();
    
    void cleanupOldAuditLogs(int retentionDays);
} 