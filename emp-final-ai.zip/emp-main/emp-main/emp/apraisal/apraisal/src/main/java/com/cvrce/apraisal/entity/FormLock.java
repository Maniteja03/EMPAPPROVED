package com.cvrce.apraisal.entity;

import com.cvrce.apraisal.enums.ReviewLevel;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "form_locks")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormLock {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @Column(name = "form_id", nullable = false)
    private UUID formId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reviewer_id", nullable = false)
    private User reviewer;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "review_level", nullable = false)
    private ReviewLevel reviewLevel;
    
    @CreationTimestamp
    @Column(name = "locked_at", nullable = false)
    private LocalDateTime lockedAt;
    
    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;
    
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;
    
    // Constructor that automatically sets expiry to 30 minutes from now
    public static FormLock createLock(UUID formId, User reviewer, ReviewLevel reviewLevel) {
        LocalDateTime now = LocalDateTime.now();
        return FormLock.builder()
                .formId(formId)
                .reviewer(reviewer)
                .reviewLevel(reviewLevel)
                .lockedAt(now)
                .expiresAt(now.plusMinutes(30)) // 30-minute timeout
                .isActive(true)
                .build();
    }
    
    // Check if lock is still valid (not expired)
    public boolean isValid() {
        return isActive && LocalDateTime.now().isBefore(expiresAt);
    }
    
    // Check if lock belongs to specific reviewer
    public boolean belongsTo(User user) {
        return reviewer != null && reviewer.getId().equals(user.getId());
    }
} 