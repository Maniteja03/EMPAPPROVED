package com.cvrce.apraisal.dto.designation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DesignationDTO {
    
    private UUID id;
    private UUID userId;
    private String employeeId;
    private String fullName;
    private String email;
    private String departmentName;
    private String designationType;
    private String designationDisplayName;
    private String designationGroup;
    
    // Dates
    private LocalDate effectiveFromDate;
    private LocalDate effectiveToDate;
    private LocalDate promotionDate;
    private String academicYear;
    
    // Status
    private Boolean isCurrentDesignation;
    private String promotionOrderNumber;
    private String remarks;
    
    // Scoring limits for this designation
    private Integer partAMaxRaw;
    private Integer partBMaxRaw;
    private Integer partCMax;
    
    // Additional profile information
    private String contactNumber;
    private LocalDate dateOfJoining;
    private LocalDate dateOfPromotionAtCVR;
    private java.math.BigDecimal experienceAtCVRYears;
    private java.math.BigDecimal totalTeachingExpYears;
    private java.math.BigDecimal industryExpYears;
    private Boolean isHSFaculty;
    
    // Calculated fields
    private Integer yearsInCurrentDesignation;
    private Boolean isEligibleForPromotion;
} 