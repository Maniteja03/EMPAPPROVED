package com.cvrce.apraisal.dto.timeline;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimelineStatusDTO {
    
    private String academicYear;
    private String currentPhase;
    private String currentPhaseDescription;
    private LocalDate currentPhaseDeadline;
    private long daysRemainingForCurrentPhase;
    private double overallCompletionPercentage;
    
    // Current phase status
    private boolean isPhaseActive;
    private boolean isPhaseOverdue;
    private String phaseStatus; // "ACTIVE", "OVERDUE", "COMPLETED", "NOT_STARTED"
    
    // Allowed actions for current phase
    private List<String> allowedActions;
    private List<String> restrictedActions;
    
    // Progress indicators
    private PhaseProgress staffUploadProgress;
    private PhaseProgress hodDcmAssignmentProgress;
    private PhaseProgress dcmReviewProgress;
    private PhaseProgress hodReviewProgress;
    private PhaseProgress committeeReviewProgress;
    private PhaseProgress chairpersonReviewProgress;
    private PhaseProgress principalReviewProgress;
    
    // Upcoming deadlines
    private List<UpcomingDeadline> upcomingDeadlines;
    
    // System-wide statistics
    private int totalStaffInSystem;
    private int totalDepartments;
    private int activeCommitteeMembers;
    
    // Timeline metadata
    private boolean timelineExists;
    private boolean timelineIsActive;
    private boolean timelineIsFinalized;
    private String timelineCreatedBy;
    
    // Alerts and notifications
    private List<String> alerts;
    private List<String> warnings;
    private List<String> notifications;
    
    // Helper methods
    public boolean isActionAllowed(String action) {
        return allowedActions != null && allowedActions.contains(action);
    }
    
    public boolean hasUpcomingDeadlines() {
        return upcomingDeadlines != null && !upcomingDeadlines.isEmpty();
    }
    
    public boolean hasAlerts() {
        return alerts != null && !alerts.isEmpty();
    }
    
    public String getOverallStatus() {
        if (!timelineExists) return "NO_TIMELINE";
        if (!timelineIsActive) return "INACTIVE";
        if (isPhaseOverdue) return "OVERDUE";
        if (overallCompletionPercentage >= 100.0) return "COMPLETED";
        return "IN_PROGRESS";
    }
}

/**
 * DTO for individual phase progress
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class PhaseProgress {
    private String phaseName;
    private String phaseStatus; // "NOT_STARTED", "IN_PROGRESS", "COMPLETED", "OVERDUE"
    private LocalDate deadline;
    private long daysRemaining;
    private int totalItems;
    private int completedItems;
    private double completionPercentage;
    private boolean isCurrentPhase;
    private boolean isOverdue;
    
    public String getProgressSummary() {
        return String.format("%s: %d/%d completed (%.1f%%)", 
                phaseName, completedItems, totalItems, completionPercentage);
    }
}

/**
 * DTO for upcoming deadlines
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class UpcomingDeadline {
    private String phase;
    private String description;
    private LocalDate deadline;
    private long daysUntilDeadline;
    private String priority; // "HIGH", "MEDIUM", "LOW"
    private String stakeholder; // Who needs to take action
    
    public boolean isUrgent() {
        return daysUntilDeadline <= 3 || "HIGH".equals(priority);
    }
    
    public String getDeadlineStatus() {
        if (daysUntilDeadline < 0) return "OVERDUE";
        if (daysUntilDeadline == 0) return "TODAY";
        if (daysUntilDeadline <= 3) return "URGENT";
        if (daysUntilDeadline <= 7) return "SOON";
        return "UPCOMING";
    }
} 