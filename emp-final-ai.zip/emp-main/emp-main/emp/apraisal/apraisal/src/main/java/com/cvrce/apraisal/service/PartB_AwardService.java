package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.partb.AwardDTO;
import java.util.List;
import java.util.UUID;

public interface PartB_AwardService {
    AwardDTO addAward(AwardDTO dto);
    List<AwardDTO> getAwardsByFormId(UUID formId);
    AwardDTO updateAward(UUID id, AwardDTO dto);
    void deleteAward(UUID id);
    void deleteAward(UUID id, String currentUserEmail);
}
