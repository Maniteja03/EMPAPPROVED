package com.cvrce.apraisal.dto.department;

import lombok.Data;

@Data
public class DepartmentCreateDTO {
    private String name;
}
