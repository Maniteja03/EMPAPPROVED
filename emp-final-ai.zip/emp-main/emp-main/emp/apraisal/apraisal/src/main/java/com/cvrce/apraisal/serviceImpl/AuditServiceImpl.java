package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.entity.AuditLog;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.repo.AuditLogRepository;
import com.cvrce.apraisal.service.AuditService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditServiceImpl implements AuditService {

    private final AuditLogRepository auditLogRepository;

    @Override
    @Transactional
    public void logUserAction(User user, String action, String entity, String entityId, String description) {
        logUserAction(user, action, entity, entityId, null, null, description);
    }

    @Override
    @Transactional
    public void logUserAction(User user, String action, String entity, String entityId, 
                             String oldValues, String newValues, String description) {
        AuditLog auditLog = AuditLog.builder()
                .user(user)
                .action(action)
                .entity(entity)
                .entityId(entityId)
                .oldValues(oldValues)
                .newValues(newValues)
                .description(description)
                .level(AuditLog.AuditLevel.INFO)
                .build();

        auditLogRepository.save(auditLog);
        log.debug("Logged user action: {} on {} by user {}", action, entity, user.getEmail());
    }

    @Override
    @Transactional
    public void logSystemAction(String action, String entity, String entityId, String description) {
        AuditLog auditLog = AuditLog.builder()
                .user(null) // System action
                .action(action)
                .entity(entity)
                .entityId(entityId)
                .description(description)
                .level(AuditLog.AuditLevel.INFO)
                .build();

        auditLogRepository.save(auditLog);
        log.debug("Logged system action: {} on {}", action, entity);
    }

    @Override
    @Transactional
    public void logSecurityEvent(User user, String action, String description, String ipAddress, String userAgent) {
        AuditLog auditLog = AuditLog.builder()
                .user(user)
                .action(action)
                .entity("SECURITY")
                .description(description)
                .ipAddress(ipAddress)
                .userAgent(userAgent)
                .level(AuditLog.AuditLevel.CRITICAL)
                .build();

        auditLogRepository.save(auditLog);
        log.warn("Security event logged: {} for user {} from IP {}", action, 
                user != null ? user.getEmail() : "unknown", ipAddress);
    }

    @Override
    @Transactional
    public void logCriticalEvent(User user, String action, String entity, String entityId, 
                                String description, String additionalData) {
        AuditLog auditLog = AuditLog.builder()
                .user(user)
                .action(action)
                .entity(entity)
                .entityId(entityId)
                .description(description)
                .additionalData(additionalData)
                .level(AuditLog.AuditLevel.CRITICAL)
                .build();

        auditLogRepository.save(auditLog);
        log.error("Critical event logged: {} on {} by user {}", action, entity, 
                user != null ? user.getEmail() : "system");
    }

    @Override
    public Page<AuditLog> getUserAuditLogs(UUID userId, Pageable pageable) {
        return auditLogRepository.findByUserId(userId, pageable);
    }

    @Override
    public Page<AuditLog> getEntityAuditLogs(String entity, String entityId, Pageable pageable) {
        return auditLogRepository.findByEntityAndEntityId(entity, entityId, pageable);
    }

    @Override
    public Page<AuditLog> getAuditLogsByAction(String action, Pageable pageable) {
        return auditLogRepository.findByAction(action, pageable);
    }

    @Override
    public Page<AuditLog> getAuditLogsByDateRange(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable) {
        return auditLogRepository.findByCreatedAtBetween(startDate, endDate, pageable);
    }

    @Override
    public Page<AuditLog> getSecurityAuditLogs(Pageable pageable) {
        return auditLogRepository.findSecurityAuditLogs(pageable);
    }

    @Override
    public long getAuditLogCount() {
        return auditLogRepository.count();
    }

    @Override
    @Transactional
    public void cleanupOldAuditLogs(int retentionDays) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(retentionDays);
        int deletedCount = auditLogRepository.deleteOldAuditLogs(cutoffDate);
        log.info("Cleaned up {} old audit logs older than {} days", deletedCount, retentionDays);
    }
} 