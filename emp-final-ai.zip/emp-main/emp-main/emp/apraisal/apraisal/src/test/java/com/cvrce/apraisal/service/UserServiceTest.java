package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.user.UserCreateDTO;
import com.cvrce.apraisal.dto.user.UserResponseDTO;
import com.cvrce.apraisal.dto.user.UserUpdateDTO;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.DepartmentRepository;
import com.cvrce.apraisal.repo.RoleRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.serviceImpl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;
    
    @Mock
    private RoleRepository roleRepository;
    
    @Mock
    private DepartmentRepository departmentRepository;
    
    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    private User testUser;
    private Department testDepartment;
    private Role testRole;
    private UUID userId;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        
        testDepartment = Department.builder()
                .id(1L)
                .name("Computer Science")
                .build();
        
        testRole = Role.builder()
                .id(1L)
                .name("STAFF")
                .build();
        
        testUser = User.builder()
                .id(userId)
                .employeeId("EMP001")
                .fullName("John Doe")
                .email("john.doe@university.edu")
                .password("encodedPassword")
                .enabled(true)
                .deleted(false)
                .dateOfJoining(LocalDate.of(2020, 1, 15))
                .department(testDepartment)
                .roles(Set.of(testRole))
                .build();
    }

    @Test
    void getUserByEmail_Success() {
        // Given
        String email = "john.doe@university.edu";
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(testUser));

        // When
        UserResponseDTO result = userService.getUserByEmail(email);

        // Then
        assertNotNull(result);
        assertEquals(userId, result.getId());
        assertEquals("John Doe", result.getFullName());
        assertEquals(email, result.getEmail());
        assertEquals("EMP001", result.getEmployeeId());
        assertTrue(result.isEnabled());
        assertFalse(result.isDeleted());
        assertEquals("Computer Science", result.getDepartmentName());
        assertTrue(result.getRoles().contains("STAFF"));
        
        verify(userRepository).findByEmail(email);
    }

    @Test
    void getUserByEmail_UserNotFound() {
        // Given
        String email = "nonexistent@university.edu";
        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> userService.getUserByEmail(email));
        
        verify(userRepository).findByEmail(email);
    }

    @Test
    void getUserById_Success() {
        // Given
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));

        // When
        UserResponseDTO result = userService.getUserById(userId);

        // Then
        assertNotNull(result);
        assertEquals(userId, result.getId());
        assertEquals("John Doe", result.getFullName());
        assertEquals("john.doe@university.edu", result.getEmail());
        
        verify(userRepository).findById(userId);
    }

    @Test
    void getUserById_UserNotFound() {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        when(userRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> userService.getUserById(nonExistentId));
        
        verify(userRepository).findById(nonExistentId);
    }

    @Test
    void createUser_Success() {
        // Given
        UserCreateDTO createDTO = new UserCreateDTO();
        createDTO.setEmployeeId("EMP002");
        createDTO.setFullName("Jane Smith");
        createDTO.setEmail("jane.smith@university.edu");
        createDTO.setPassword("password123");
        createDTO.setDepartmentId(1L);
        createDTO.setDateOfJoining(LocalDate.now());
        createDTO.setRoles(Set.of("STAFF"));

        when(userRepository.existsByEmail(createDTO.getEmail())).thenReturn(false);
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(testDepartment));
        when(roleRepository.findByName("STAFF")).thenReturn(Optional.of(testRole));
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        
        User savedUser = User.builder()
                .id(UUID.randomUUID())
                .employeeId("EMP002")
                .fullName("Jane Smith")
                .email("jane.smith@university.edu")
                .password("encodedPassword")
                .enabled(true)
                .deleted(false)
                .department(testDepartment)
                .roles(Set.of(testRole))
                .dateOfJoining(LocalDate.now())
                .build();
        
        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        // When
        UserResponseDTO result = userService.createUser(createDTO);

        // Then
        assertNotNull(result);
        assertEquals("EMP002", result.getEmployeeId());
        assertEquals("Jane Smith", result.getFullName());
        assertEquals("jane.smith@university.edu", result.getEmail());
        assertTrue(result.isEnabled());
        assertFalse(result.isDeleted());
        
        verify(userRepository).existsByEmail(createDTO.getEmail());
        verify(departmentRepository).findById(1L);
        verify(roleRepository).findByName("STAFF");
        verify(passwordEncoder).encode("password123");
        verify(userRepository).save(any(User.class));
    }

    @Test
    void createUser_EmailAlreadyExists() {
        // Given
        UserCreateDTO createDTO = new UserCreateDTO();
        createDTO.setEmail("existing@university.edu");
        
        when(userRepository.existsByEmail(createDTO.getEmail())).thenReturn(true);

        // When & Then
        assertThrows(IllegalArgumentException.class, 
                () -> userService.createUser(createDTO));
        
        verify(userRepository).existsByEmail(createDTO.getEmail());
        verify(userRepository, never()).save(any());
    }

    @Test
    void createUser_InvalidDepartment() {
        // Given
        UserCreateDTO createDTO = new UserCreateDTO();
        createDTO.setEmail("jane.smith@university.edu");
        createDTO.setDepartmentId(999L);
        
        when(userRepository.existsByEmail(createDTO.getEmail())).thenReturn(false);
        when(departmentRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> userService.createUser(createDTO));
        
        verify(userRepository).existsByEmail(createDTO.getEmail());
        verify(departmentRepository).findById(999L);
        verify(userRepository, never()).save(any());
    }

    @Test
    void updateUser_Success() {
        // Given
        UserUpdateDTO updateDTO = new UserUpdateDTO();
        updateDTO.setFullName("John Updated");
        updateDTO.setDepartmentId(1L);
        
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(testDepartment));
        
        User updatedUser = User.builder()
                .id(userId)
                .employeeId("EMP001")
                .fullName("John Updated")
                .email("john.doe@university.edu")
                .password("encodedPassword")
                .enabled(true)
                .deleted(false)
                .department(testDepartment)
                .roles(Set.of(testRole))
                .build();
        
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        // When
        UserResponseDTO result = userService.updateUser(userId, updateDTO);

        // Then
        assertNotNull(result);
        assertEquals("John Updated", result.getFullName());
        
        verify(userRepository).findById(userId);
        verify(departmentRepository).findById(1L);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void updateUser_UserNotFound() {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        UserUpdateDTO updateDTO = new UserUpdateDTO();
        
        when(userRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> userService.updateUser(nonExistentId, updateDTO));
        
        verify(userRepository).findById(nonExistentId);
        verify(userRepository, never()).save(any());
    }

    @Test
    void setUserEnabled_Success() {
        // Given
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        userService.setUserEnabled(userId, false);

        // Then
        verify(userRepository).findById(userId);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void softDeleteUser_Success() {
        // Given
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        userService.softDeleteUser(userId);

        // Then
        verify(userRepository).findById(userId);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void getUsersByDepartment_Success() {
        // Given
        Long departmentId = 1L;
        List<User> users = Arrays.asList(testUser);
        when(userRepository.findByDepartmentId(departmentId)).thenReturn(users);

        // When
        List<UserResponseDTO> result = userService.getUsersByDepartment(departmentId);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(userId, result.get(0).getId());
        
        verify(userRepository).findByDepartmentId(departmentId);
    }

    @Test
    void getUsersByDepartment_WithPagination_Success() {
        // Given
        Long departmentId = 1L;
        List<User> users = Arrays.asList(testUser);
        when(userRepository.findByDepartmentId(departmentId)).thenReturn(users);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<UserResponseDTO> result = userService.getUsersByDepartment(departmentId, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertEquals(userId, result.getContent().get(0).getId());
        
        verify(userRepository).findByDepartmentId(departmentId);
    }

    @Test
    void searchUsers_Success() {
        // Given
        String query = "john";
        List<User> allUsers = Arrays.asList(testUser);
        when(userRepository.findAll()).thenReturn(allUsers);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<UserResponseDTO> result = userService.searchUsers(query, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertTrue(result.getContent().get(0).getFullName().toLowerCase().contains(query));
        
        verify(userRepository).findAll();
    }

    @Test
    void getUsersByRole_Success() {
        // Given
        String roleName = "STAFF";
        List<User> allUsers = Arrays.asList(testUser);
        when(userRepository.findAll()).thenReturn(allUsers);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<UserResponseDTO> result = userService.getUsersByRole(roleName, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertTrue(result.getContent().get(0).getRoles().contains(roleName));
        
        verify(userRepository).findAll();
    }

    @Test
    void getAllUsers_WithFilters_Success() {
        // Given
        List<User> allUsers = Arrays.asList(testUser);
        when(userRepository.findAll()).thenReturn(allUsers);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<UserResponseDTO> result = userService.getAllUsers(pageable, "john", 1L, true);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertEquals(userId, result.getContent().get(0).getId());
        
        verify(userRepository).findAll();
    }
} 