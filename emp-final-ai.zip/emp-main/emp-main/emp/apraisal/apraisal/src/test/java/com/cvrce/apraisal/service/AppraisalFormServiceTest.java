package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.Role;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.AppraisalVersionRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.serviceImpl.AppraisalFormServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AppraisalFormServiceTest {

    @Mock
    private AppraisalFormRepository formRepository;
    
    @Mock
    private AppraisalVersionRepository versionRepository;
    
    @Mock
    private UserRepository userRepository;
    
    @Mock
    private DeadlineService deadlineService;
    
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private AppraisalFormServiceImpl appraisalFormService;

    private User testUser;
    private AppraisalForm testForm;
    private UUID userId;
    private UUID formId;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        formId = UUID.randomUUID();
        
        Department department = Department.builder()
                .id(1L)
                .name("Computer Science")
                .build();
        
        Role staffRole = Role.builder()
                .id(1L)
                .name("STAFF")
                .build();
        
        testUser = User.builder()
                .id(userId)
                .employeeId("EMP001")
                .fullName("John Doe")
                .email("john.doe@university.edu")
                .enabled(true)
                .deleted(false)
                .department(department)
                .roles(Set.of(staffRole))
                .build();
        
        testForm = AppraisalForm.builder()
                .id(formId)
                .user(testUser)
                .academicYear("2024-25")
                .status(AppraisalStatus.DRAFT)
                .locked(false)
                .totalScore(0.0)
                .submittedAsRole("STAFF")
                .build();
    }

    @Test
    void createDraftForm_Success() {
        // Given
        String academicYear = "2024-25";
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(formRepository.findByUserIdAndAcademicYear(userId, academicYear)).thenReturn(Optional.empty());
        when(formRepository.save(any(AppraisalForm.class))).thenReturn(testForm);

        // When
        AppraisalFormDTO result = appraisalFormService.createDraftForm(academicYear, userId);

        // Then
        assertNotNull(result);
        assertEquals(formId, result.getId());
        assertEquals(academicYear, result.getAcademicYear());
        assertEquals(AppraisalStatus.DRAFT.name(), result.getStatus());
        assertEquals("STAFF", result.getSubmittedAsRole());
        assertFalse(result.isLocked());
        
        verify(userRepository).findById(userId);
        verify(formRepository).findByUserIdAndAcademicYear(userId, academicYear);
        verify(formRepository).save(any(AppraisalForm.class));
    }

    @Test
    void createDraftForm_UserNotFound() {
        // Given
        String academicYear = "2024-25";
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> appraisalFormService.createDraftForm(academicYear, userId));
        
        verify(userRepository).findById(userId);
        verifyNoInteractions(formRepository);
    }

    @Test
    void createDraftForm_FormAlreadyExists() {
        // Given
        String academicYear = "2024-25";
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(formRepository.findByUserIdAndAcademicYear(userId, academicYear))
                .thenReturn(Optional.of(testForm));

        // When & Then
        assertThrows(IllegalStateException.class, 
                () -> appraisalFormService.createDraftForm(academicYear, userId));
        
        verify(userRepository).findById(userId);
        verify(formRepository).findByUserIdAndAcademicYear(userId, academicYear);
        verify(formRepository, never()).save(any());
    }

    @Test
    void submitForm_Success() {
        // Given
        when(formRepository.findById(formId)).thenReturn(Optional.of(testForm));
        
        AppraisalForm submittedForm = AppraisalForm.builder()
                .id(formId)
                .user(testUser)
                .academicYear("2024-25")
                .status(AppraisalStatus.SUBMITTED)
                .locked(true)
                .submittedDate(LocalDate.now())
                .totalScore(0.0)
                .submittedAsRole("STAFF")
                .build();
        
        when(formRepository.save(any(AppraisalForm.class))).thenReturn(submittedForm);

        // When
        AppraisalFormDTO result = appraisalFormService.submit(formId);

        // Then
        assertNotNull(result);
        assertEquals(formId, result.getId());
        assertEquals(AppraisalStatus.SUBMITTED.name(), result.getStatus());
        assertTrue(result.isLocked());
        assertNotNull(result.getSubmittedDate());
        
        verify(formRepository).findById(formId);
        verify(formRepository).save(any(AppraisalForm.class));
    }

    @Test
    void submitForm_FormNotFound() {
        // Given
        when(formRepository.findById(formId)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> appraisalFormService.submit(formId));
        
        verify(formRepository).findById(formId);
        verify(formRepository, never()).save(any());
    }

    @Test
    void submitForm_FormAlreadyLocked() {
        // Given
        testForm.setLocked(true);
        when(formRepository.findById(formId)).thenReturn(Optional.of(testForm));

        // When & Then
        assertThrows(IllegalStateException.class, 
                () -> appraisalFormService.submit(formId));
        
        verify(formRepository).findById(formId);
        verify(formRepository, never()).save(any());
    }

    @Test
    void getMySubmissions_Success() {
        // Given
        List<AppraisalForm> forms = Arrays.asList(testForm);
        when(formRepository.findByUserId(userId)).thenReturn(forms);

        // When
        List<AppraisalFormDTO> result = appraisalFormService.getMySubmissions(userId);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(formId, result.get(0).getId());
        assertEquals(testUser.getFullName(), result.get(0).getUserFullName());
        
        verify(formRepository).findByUserId(userId);
    }

    @Test
    void getMySubmissions_WithPagination_Success() {
        // Given
        List<AppraisalForm> forms = Arrays.asList(testForm);
        when(formRepository.findByUserId(userId)).thenReturn(forms);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<AppraisalFormDTO> result = appraisalFormService.getMySubmissions(userId, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertEquals(formId, result.getContent().get(0).getId());
        
        verify(formRepository).findByUserId(userId);
    }

    @Test
    void filterByStatus_Success() {
        // Given
        AppraisalStatus status = AppraisalStatus.SUBMITTED;
        List<AppraisalForm> forms = Arrays.asList(testForm);
        when(formRepository.findByStatus(status)).thenReturn(forms);

        // When
        List<AppraisalFormDTO> result = appraisalFormService.filterByStatus(status);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(formId, result.get(0).getId());
        
        verify(formRepository).findByStatus(status);
    }

    @Test
    void filterByStatus_WithPagination_Success() {
        // Given
        AppraisalStatus status = AppraisalStatus.SUBMITTED;
        List<AppraisalForm> forms = Arrays.asList(testForm);
        when(formRepository.findByStatus(status)).thenReturn(forms);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<AppraisalFormDTO> result = appraisalFormService.filterByStatus(status, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertEquals(formId, result.getContent().get(0).getId());
        
        verify(formRepository).findByStatus(status);
    }

    @Test
    void getById_Success() {
        // Given
        when(formRepository.findById(formId)).thenReturn(Optional.of(testForm));

        // When
        AppraisalFormDTO result = appraisalFormService.getById(formId);

        // Then
        assertNotNull(result);
        assertEquals(formId, result.getId());
        assertEquals(testUser.getFullName(), result.getUserFullName());
        assertEquals("2024-25", result.getAcademicYear());
        
        verify(formRepository).findById(formId);
    }

    @Test
    void getById_FormNotFound() {
        // Given
        when(formRepository.findById(formId)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResourceNotFoundException.class, 
                () -> appraisalFormService.getById(formId));
        
        verify(formRepository).findById(formId);
    }

    @Test
    void searchAppraisals_Success() {
        // Given
        String query = "john";
        List<AppraisalForm> allForms = Arrays.asList(testForm);
        when(formRepository.findAll()).thenReturn(allForms);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<AppraisalFormDTO> result = appraisalFormService.searchAppraisals(query, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertTrue(result.getContent().get(0).getUserFullName().toLowerCase().contains(query));
        
        verify(formRepository).findAll();
    }

    @Test
    void getAllAppraisals_WithFilters_Success() {
        // Given
        String academicYear = "2024-25";
        AppraisalStatus status = AppraisalStatus.DRAFT;
        List<AppraisalForm> allForms = Arrays.asList(testForm);
        when(formRepository.findAll()).thenReturn(allForms);
        Pageable pageable = PageRequest.of(0, 10);

        // When
        Page<AppraisalFormDTO> result = appraisalFormService.getAllAppraisals(pageable, academicYear, status);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
        assertEquals(academicYear, result.getContent().get(0).getAcademicYear());
        assertEquals(status.name(), result.getContent().get(0).getStatus());
        
        verify(formRepository).findAll();
    }
} 