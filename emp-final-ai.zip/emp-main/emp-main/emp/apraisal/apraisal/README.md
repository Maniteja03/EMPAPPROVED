# 🎓 Employee Appraisal Management System - Production Ready

## 📋 System Overview

A comprehensive **Employee Appraisal Management System** built with **Spring Boot** that manages the complete employee performance evaluation workflow from staff submission to principal approval.

### ✨ Key Features
- **Role-Based Access Control** (Staff, DCM, HOD, Committee, Chairperson, Principal, Admin)
- **Automated Workflow Management** with status transitions
- **Load-Balanced Assignment System** for DCMs and Committee members
- **Form Locking Mechanism** to prevent concurrent reviews
- **Department-Based Data Isolation** 
- **Timeline Management** with deadline enforcement
- **Real-time Dashboard Analytics**
- **PDF Export & Document Management**
- **Comprehensive Security** with JWT authentication

---

## 🔄 Complete Workflow

### **1. Staff Submission → DCM Assignment**
```
Staff submits form (DRAFT → DEPARTMENT_REVIEW)
    ↓
System auto-assigns to specific DCM (load balancing)
    ↓
DCM receives notification & locks form for review
```

### **2. DCM Review → HOD Review**
```
DCM reviews & approves (DEPARTMENT_REVIEW → DCM_APPROVED)
    ↓
Form moves to HOD dashboard (DCM_APPROVED → HOD review queue)
    ↓
HOD reviews & makes decision
```

### **3. HOD Approval → Committee Assignment**
```
HOD approves (DCM_APPROVED → HOD_APPROVED)
    ↓  
System auto-assigns to Committee member (different dept)
    ↓
Committee member locks & reviews form
```

### **4. Committee → Chairperson → Principal**
```
Committee approves (COMMITTEE_REVIEW → CHAIRPERSON_REVIEW)
    ↓
Chairperson reviews (CHAIRPERSON_REVIEW → PRINCIPAL_REVIEW)
    ↓
Principal final approval (PRINCIPAL_REVIEW → COMPLETED)
```

---

## 🏗️ System Architecture

### **Backend Stack**
- **Framework**: Spring Boot 3.x
- **Security**: Spring Security + JWT
- **Database**: JPA/Hibernate
- **Build Tool**: Maven
- **Java Version**: 17+

### **Key Components**

#### **1. Service Layer**
- `AppraisalFormService` - Form creation & submission
- `FormAssignmentService` - **AUTO-ASSIGNMENT** with load balancing  
- `FormLockingService` - Concurrent access control
- `AppraisalWorkflowService` - Status transitions
- `DeadlineEnforcementService` - Timeline management

#### **2. Controllers (API Endpoints)**
- `/api/staff` - Staff form management
- `/api/dcm` - DCM review dashboard
- `/api/hod` - HOD approval system  
- `/api/committee` - Committee review workflow
- `/api/chairperson` - Chairperson dashboard
- `/api/principal` - Final approval system

#### **3. Security Features**  
- **Ownership Validation** - Users can only access their data
- **Department Isolation** - DCMs see only their dept forms
- **Role-Based Permissions** - Granular access control
- **JWT Authentication** - Secure API access

---

## 🎯 Critical Features Implemented

### **✅ 1. DCM Auto-Assignment System**
**Location**: `FormAssignmentServiceImpl.autoAssignToDCM()`

**How it works**:
- Staff submits form → Status changes to `DEPARTMENT_REVIEW`
- System finds all active DCMs in same department  
- Selects DCM with **least current workload**
- Creates `FormAssignment` record linking form to specific DCM
- DCM dashboard shows **only assigned forms** (not all dept forms)

```java
// Auto-assignment triggered in AppraisalFormServiceImpl.submit()
formAssignmentService.handleFormStatusChange(formId, "DEPARTMENT_REVIEW");
```

### **✅ 2. Committee Auto-Assignment System** 
**Location**: `FormAssignmentServiceImpl.autoAssignToCommitteeMember()`

**How it works**:
- HOD approves form → Status changes to `COMMITTEE_REVIEW`
- System finds committee members from **different departments**
- Selects member with least workload
- Handles reassignment if HOD updates after committee rejection

### **✅ 3. Form Locking Mechanism**
**Location**: `FormLockingService` & implemented in all review services

**Features**:
- **DCM Form Locking** - Prevents multiple DCMs reviewing same form
- **Committee Form Locking** - Prevents concurrent committee reviews  
- **Auto-expiry** - Locks expire after timeout
- **Lock Extension** - Active reviewers can extend locks

### **✅ 4. Dashboard Consistency**
**Problem Fixed**: DCM dashboard was showing all department forms
**Solution**: Now shows only forms assigned to that specific DCM

```java
// DCMServiceImpl.getDCMDashboard() - FIXED
long assignedReviews = formAssignmentRepository
    .findActiveAssignmentsByReviewer(currentDCM)
    .stream()
    .filter(assignment -> "DCM_REVIEW".equals(assignment.getAssignmentType()))
    .count();
```

---

## 🔐 Security Implementation

### **1. Ownership Validation**
```java
// Every service validates user ownership
if (!form.getUser().getId().equals(currentUserId)) {
    throw new SecurityException("Access denied");
}
```

### **2. Department Security**
```java
// DCMs can only review forms from their department
if (!dcmDepartment.equals(formDepartment)) {
    throw new SecurityException("Cross-department access denied");
}
```

### **3. Role-Based Access**
```java
@PreAuthorize("hasRole('DCM')")
@PreAuthorize("hasRole('HOD') and @hodService.canReviewForm(#formId, authentication.name)")
```

---

## 📊 Database Schema

### **Key Entities**
- `AppraisalForm` - Main form entity with status tracking
- `FormAssignment` - **Critical**: Links forms to specific reviewers  
- `FormLock` - Manages concurrent access control
- `DCMAssignment` - Maps staff members to DCM roles by department
- `CommitteeAssignment` - Maps committee members with workload tracking
- `AppraisalTimeline` - Chairperson-defined deadlines

### **Status Flow**
```
DRAFT → DEPARTMENT_REVIEW → DCM_APPROVED → HOD_APPROVED → 
COMMITTEE_REVIEW → CHAIRPERSON_REVIEW → PRINCIPAL_REVIEW → COMPLETED
```

---

## 🚀 Deployment Instructions

### **1. Prerequisites**
```bash
Java 17+
Maven 3.8+
MySQL 8.0+ (or PostgreSQL)
```

### **2. Database Setup**
```sql
CREATE DATABASE employee_appraisal;
-- Application will auto-create tables via JPA
```

### **3. Configuration**
Update `application.properties`:
```properties
# Database
spring.datasource.url=jdbc:mysql://localhost:3306/employee_appraisal
spring.datasource.username=your_username
spring.datasource.password=your_password

# JWT
jwt.secret=your-secret-key-here
jwt.expiration=86400000

# File upload
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB
```

### **4. Build & Deploy**
```bash
# Build the application
mvn clean package -DskipTests

# Run the application  
java -jar target/apraisal-1.0.0.jar

# Or deploy to production server
# Copy JAR to server and run with production profile
java -jar -Dspring.profiles.active=production apraisal-1.0.0.jar
```

### **5. Initial Data Setup**
```sql
-- Create admin user
INSERT INTO users (email, password, full_name, role) VALUES 
('admin@college.edu', '$2a$10$encodedPassword', 'System Admin', 'ADMIN');

-- Create departments
INSERT INTO departments (name, code) VALUES 
('Computer Science', 'CSE'),
('Mechanical Engineering', 'MECH'),
-- Add other departments as needed
```

---

## 🧪 API Testing

### **1. Authentication**
```bash
# Login
POST /api/auth/login
{
  "email": "staff@college.edu",
  "password": "password123"
}
```

### **2. Staff Workflow**  
```bash
# Create draft form
POST /api/staff/appraisal/create
Authorization: Bearer <token>

# Submit form (triggers DCM auto-assignment)
POST /api/staff/appraisal/{formId}/submit
Authorization: Bearer <token>
```

### **3. DCM Workflow**
```bash
# Get DCM dashboard (shows only assigned forms)
GET /api/dcm/dashboard
Authorization: Bearer <token>

# Start form review (locks form)
POST /api/dcm/start-review/{formId}
Authorization: Bearer <token>

# Submit DCM review
POST /api/dcm/review
Authorization: Bearer <token>
{
  "appraisalFormId": "uuid",
  "decision": "APPROVED",
  "remarks": "Good performance"
}
```

---

## 🐛 Troubleshooting

### **Common Issues**

#### **1. DCM Not Getting Assigned Forms**
**Check**: 
- Is DCM properly assigned to department in `DCMAssignment` table?
- Is `FormAssignmentService.handleFormStatusChange()` being called?
- Check logs for auto-assignment errors

#### **2. Committee Member Can't Lock Form**  
**Check**:
- Is committee member from different department than form owner?
- Is form in `COMMITTEE_REVIEW` status?
- Check `FormLock` table for existing locks

#### **3. Dashboard Shows Wrong Counts**
**Check**:
- Verify `FormAssignment` records are being created properly
- Check dashboard queries are filtering by specific reviewer
- Ensure status transitions are working correctly

---

## 📈 Monitoring & Logs

### **Key Log Patterns**
```bash
# Auto-assignment success
grep "Auto-assigned form" application.log

# Security violations  
grep "SECURITY VIOLATION" application.log

# Form locking issues
grep "Form is not locked" application.log

# Workflow transitions
grep "submitted.*review for appraisal" application.log
```

### **Health Check Endpoints**
```bash
GET /actuator/health
GET /actuator/metrics
GET /actuator/info
```

---

## 🔧 Configuration Options

### **Form Assignment Settings**
```properties
# DCM workload balancing
appraisal.dcm.max-concurrent-reviews=15

# Committee assignment
appraisal.committee.exclude-same-department=true
appraisal.committee.max-workload=10

# Form locking
appraisal.form-lock.default-timeout-minutes=30
appraisal.form-lock.max-concurrent-locks-per-user=5
```

### **Timeline Management**
```properties
# Deadline enforcement
appraisal.timeline.enforce-deadlines=true
appraisal.timeline.grace-period-hours=24
```

---

## 📞 Support & Maintenance

### **Log Locations**
- Application logs: `/var/log/appraisal/application.log`
- Access logs: `/var/log/appraisal/access.log`
- Error logs: `/var/log/appraisal/error.log`

### **Database Maintenance**
```sql
-- Clean up expired locks (run daily)
DELETE FROM form_locks WHERE expires_at < NOW() AND is_active = false;

-- Archive completed appraisals (run annually)
UPDATE appraisal_forms SET archived = true 
WHERE status = 'COMPLETED' AND created_at < DATE_SUB(NOW(), INTERVAL 2 YEAR);
```

### **Performance Tuning**
- Monitor `FormAssignment` table growth
- Index `FormLock.expires_at` for cleanup queries
- Archive old appraisal data annually
- Monitor DCM workload distribution

---

## ✅ Production Checklist

### **Pre-Deployment**
- [ ] Database schema created and migrated
- [ ] Initial admin user created
- [ ] Department data populated
- [ ] JWT secret configured (production-grade)
- [ ] File upload directories created with proper permissions
- [ ] SSL certificate configured
- [ ] Firewall rules configured

### **Post-Deployment**  
- [ ] Health check endpoints responding
- [ ] Admin login working
- [ ] Staff can create and submit forms
- [ ] DCM auto-assignment working
- [ ] Committee assignment working  
- [ ] Form locking mechanism working
- [ ] Dashboard statistics accurate
- [ ] PDF export functional
- [ ] Email notifications working (if configured)

### **Monitoring Setup**
- [ ] Application performance monitoring
- [ ] Database performance monitoring  
- [ ] Log aggregation configured
- [ ] Alert rules for critical errors
- [ ] Backup procedures tested

---

## 🚨 Emergency Procedures

### **1. System Down**
1. Check application health: `curl /actuator/health`
2. Check database connectivity  
3. Review recent logs for errors
4. Restart application if needed

### **2. Form Assignment Issues**
```sql
-- Manually assign form to DCM
INSERT INTO form_assignments (appraisal_form_id, assigned_reviewer_id, assignment_type, is_active)
VALUES ('form-uuid', 'dcm-user-uuid', 'DCM_REVIEW', true);
```

### **3. Lock Issues**
```sql
-- Force unlock form
UPDATE form_locks SET is_active = false WHERE form_id = 'form-uuid';
```

---

**🎯 SYSTEM STATUS: PRODUCTION READY**

**All critical workflow issues have been resolved:**
✅ DCM Auto-Assignment with Load Balancing  
✅ Committee Auto-Assignment with Department Exclusion  
✅ Form Locking for All Review Stages  
✅ Dashboard Consistency (Individual Assignments)  
✅ Complete Status Workflow (Staff → Principal)  
✅ Security & Department Isolation  
✅ Timeline Management & Deadline Enforcement  

**Contact**: Development Team  
**Version**: 1.0.0  
**Last Updated**: December 2024