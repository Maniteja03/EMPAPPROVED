package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "committee_assignments")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeAssignment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "committee_member_id", nullable = false)
    private User committeeMember; // The staff member assigned as committee member
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department; // Their original department
    
    @Column(name = "academic_year", nullable = false, length = 20)
    private String academicYear; // e.g., "2023-24"
    
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;
    
    @CreationTimestamp
    @Column(name = "assigned_at", nullable = false)
    private LocalDateTime assignedAt;
    
    @Column(name = "selection_method", nullable = false, length = 50)
    @Builder.Default
    private String selectionMethod = "RANDOM"; // How they were selected
    
    @Column(name = "workload_count", nullable = false)
    @Builder.Default
    private Integer workloadCount = 0; // Number of forms currently assigned to review
    
    @Column(name = "completed_reviews", nullable = false)
    @Builder.Default
    private Integer completedReviews = 0; // Number of reviews completed
    
    @Column(name = "deactivated_at")
    private LocalDateTime deactivatedAt;
    
    // Helper method to deactivate committee assignment
    public void deactivate() {
        this.isActive = false;
        this.deactivatedAt = LocalDateTime.now();
    }
    
    // Increment workload when form is assigned
    public void incrementWorkload() {
        this.workloadCount++;
    }
    
    // Decrement workload and increment completed when review is done
    public void completeReview() {
        if (this.workloadCount > 0) {
            this.workloadCount--;
        }
        this.completedReviews++;
    }
    
    // Check if assignment is currently active
    public boolean isCurrentlyActive() {
        return isActive && deactivatedAt == null;
    }
    
    // Check if this is for current academic year
    public boolean isForCurrentYear(String currentAcademicYear) {
        return isActive && academicYear.equals(currentAcademicYear);
    }
    
    // Check if member can take more assignments (reasonable workload limit)
    public boolean canTakeMoreWork(int maxWorkload) {
        return isCurrentlyActive() && workloadCount < maxWorkload;
    }
} 