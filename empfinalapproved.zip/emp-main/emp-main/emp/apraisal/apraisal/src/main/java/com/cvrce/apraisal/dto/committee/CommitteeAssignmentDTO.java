package com.cvrce.apraisal.dto.committee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeAssignmentDTO {
    
    private UUID assignmentId;
    private UUID committeeMemberId;
    private String memberFullName;
    private String memberEmail;
    private String memberEmployeeId;
    private String memberDepartmentName;
    private String memberDesignation;
    private String academicYear;
    private boolean isActive;
    private LocalDateTime assignedAt;
    private LocalDateTime deactivatedAt;
    private String selectionMethod; // "RANDOM", "MANUAL"
    
    // Workload information
    private int currentWorkload;
    private int completedReviews;
    private double completionRate;
    private int totalAssignedForms;
    
    // Status information
    private String status; // "ACTIVE", "INACTIVE", "OVERLOADED"
    private boolean canTakeMoreWork;
    private int maxWorkloadCapacity;
    
    // Review statistics
    private int formsApproved;
    private int formsRejected;
    private double approvalRate;
    
    // Helper methods
    public boolean isCurrentlyActive() {
        return isActive && deactivatedAt == null;
    }
    
    public String getDisplayInfo() {
        return memberFullName + " (" + memberEmployeeId + ") - " + memberDepartmentName;
    }
    
    public String getWorkloadInfo() {
        return "Current: " + currentWorkload + ", Completed: " + completedReviews + 
               " (" + String.format("%.1f%%", completionRate) + ")";
    }
    
    public boolean isOverloaded() {
        return currentWorkload > maxWorkloadCapacity;
    }
    
    public String getWorkloadStatus() {
        if (!isCurrentlyActive()) return "INACTIVE";
        if (isOverloaded()) return "OVERLOADED";
        if (currentWorkload == 0) return "AVAILABLE";
        return "WORKING";
    }
} 