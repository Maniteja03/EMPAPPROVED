package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "teaching_performance_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TeachingPerformanceScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Subject Details
    @Column(name = "academic_year", nullable = false, length = 10)
    private String academicYear;
    
    @Column(name = "class_section", length = 50)
    private String classSection;
    
    @Column(name = "semester", length = 20)
    private String semester;
    
    @Column(name = "theory_subject_name", nullable = false, length = 200)
    private String theorySubjectName;
    
    @Column(name = "students_registered", nullable = false)
    private Integer studentsRegistered;
    
    @Column(name = "students_passed", nullable = false)
    private Integer studentsPassed;
    
    @Column(name = "pass_percentage", precision = 5, scale = 2, nullable = false)
    private BigDecimal passPercentage;
    
    // Scoring
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // External examination flag
    @Column(name = "is_external_examination", nullable = false)
    @Builder.Default
    private Boolean isExternalExamination = true;
    
    // Verification
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points based on pass percentage
    public void calculatePoints() {
        if (passPercentage != null && isExternalExamination) {
            this.autoCalculatedPoints = calculatePointsBasedOnPassPercentage(passPercentage);
            
            if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
                this.pointsClaimed = autoCalculatedPoints;
            }
        }
    }
    
    private BigDecimal calculatePointsBasedOnPassPercentage(BigDecimal percentage) {
        // Points based on pass percentage from Annexure VI - Table 4
        if (percentage.compareTo(new BigDecimal("90")) >= 0) {
            return new BigDecimal("20"); // 90-100% = 20 points
        } else if (percentage.compareTo(new BigDecimal("80")) >= 0) {
            return new BigDecimal("19"); // 80-89% = 19 points
        } else if (percentage.compareTo(new BigDecimal("70")) >= 0) {
            return new BigDecimal("18"); // 70-79% = 18 points
        } else if (percentage.compareTo(new BigDecimal("60")) >= 0) {
            return new BigDecimal("17"); // 60-69% = 17 points
        } else if (percentage.compareTo(new BigDecimal("50")) >= 0) {
            return new BigDecimal("16"); // 50-59% = 16 points
        } else {
            return new BigDecimal("15"); // Less than 50% = 15 points
        }
    }
    
    // Calculate pass percentage automatically
    public void calculatePassPercentage() {
        if (studentsRegistered != null && studentsPassed != null && studentsRegistered > 0) {
            this.passPercentage = new BigDecimal(studentsPassed)
                    .divide(new BigDecimal(studentsRegistered), 2, java.math.RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("100"));
        }
    }
    
    // Validation
    public boolean isValidForScoring() {
        return theorySubjectName != null && !theorySubjectName.trim().isEmpty() &&
               studentsRegistered != null && studentsRegistered > 0 &&
               studentsPassed != null && studentsPassed >= 0 &&
               isExternalExamination; // Only external examinations count
    }
} 