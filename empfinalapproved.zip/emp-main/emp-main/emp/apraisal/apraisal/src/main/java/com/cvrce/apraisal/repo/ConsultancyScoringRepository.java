package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.ConsultancyScoring;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Repository
public interface ConsultancyScoringRepository extends JpaRepository<ConsultancyScoring, UUID> {
    
    List<ConsultancyScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT cs FROM ConsultancyScoring cs WHERE cs.appraisalScoring.id = :scoringId ORDER BY cs.sanctionedDate DESC")
    List<ConsultancyScoring> findByAppraisalScoringIdOrderByDate(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT cs FROM ConsultancyScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<ConsultancyScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT SUM(cs.consultancyAmountLakhs) FROM ConsultancyScoring cs WHERE cs.appraisalScoring.appraisalForm.academicYear = :academicYear")
    BigDecimal getTotalConsultancyByAcademicYear(@Param("academicYear") String academicYear);
} 