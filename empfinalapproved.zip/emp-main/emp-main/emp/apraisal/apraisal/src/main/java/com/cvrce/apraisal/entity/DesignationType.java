package com.cvrce.apraisal.entity;

public enum DesignationType {
    ASSISTANT_PROFESSOR("Assistant Professor"),
    SR_ASSOCIATE_PROFESSOR("Sr. Associate Professor"), 
    ASSOCIATE_PROFESSOR("Associate Professor"),
    DOCTORATE("Doctorate"),
    PROFESSOR("Professor");
    
    private final String displayName;
    
    DesignationType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
} 