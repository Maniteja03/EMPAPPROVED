package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.PublicationScoring;
import com.cvrce.apraisal.enums.PublicationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PublicationScoringRepository extends JpaRepository<PublicationScoring, UUID> {
    
    List<PublicationScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT ps FROM PublicationScoring ps WHERE ps.appraisalScoring.id = :scoringId ORDER BY ps.yearOfPublication DESC")
    List<PublicationScoring> findByAppraisalScoringIdOrderByYear(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT ps FROM PublicationScoring ps WHERE ps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<PublicationScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT ps FROM PublicationScoring ps WHERE ps.isVerified = false")
    List<PublicationScoring> findUnverifiedPublications();
    
    @Query("SELECT ps FROM PublicationScoring ps WHERE ps.publicationType = :publicationType " +
           "AND ps.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<PublicationScoring> findByTypeAndAcademicYear(
            @Param("publicationType") PublicationType publicationType, 
            @Param("academicYear") String academicYear);
} 