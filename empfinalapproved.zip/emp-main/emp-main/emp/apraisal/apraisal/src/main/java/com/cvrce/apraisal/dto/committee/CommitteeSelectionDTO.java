package com.cvrce.apraisal.dto.committee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommitteeSelectionDTO {
    
    private UUID staffId;
    private String fullName;
    private String email;
    private String employeeId;
    private String departmentName;
    private String designation;
    private boolean isCurrentlyCommitteeMember;
    private boolean isEligible;
    private String ineligibilityReason;
    private int yearsOfExperience;
    private boolean isDCM;
    private boolean isHOD;
    private boolean hasSubmittedOwnAppraisal;
    private int previousCommitteeAssignments;
    
    // Helper methods
    public boolean canBeAssignedAsCommitteeMember() {
        return isEligible && !isCurrentlyCommitteeMember && !isHOD;
    }
    
    public String getDisplayName() {
        return fullName + " (" + employeeId + ") - " + departmentName;
    }
    
    public String getRoleInfo() {
        StringBuilder roles = new StringBuilder();
        if (isDCM) roles.append("DCM ");
        if (isHOD) roles.append("HOD ");
        if (roles.length() == 0) roles.append("STAFF");
        return roles.toString().trim();
    }
} 