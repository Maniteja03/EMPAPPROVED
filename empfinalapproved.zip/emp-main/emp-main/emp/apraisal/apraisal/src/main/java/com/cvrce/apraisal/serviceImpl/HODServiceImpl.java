package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.entity.AppraisalForm;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.entity.review.Review;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.enums.ReviewDecision;
import com.cvrce.apraisal.enums.ReviewLevel;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.HODService;
import com.cvrce.apraisal.service.AppraisalWorkflowService;
import com.cvrce.apraisal.service.FormAssignmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class HODServiceImpl implements HODService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final AppraisalWorkflowService workflowService;
    private final FormAssignmentService formAssignmentService;

    @Override
    public Map<String, Object> getHODDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        
        // Get current HOD and their department
        User currentHOD = getCurrentHOD();
        String departmentName = currentHOD.getDepartment().getName();
        
        log.info("Getting HOD dashboard for {} from {} department", currentHOD.getFullName(), departmentName);
        
        // Get pending approvals ONLY from HOD's department  
        List<AppraisalForm> departmentForms = appraisalFormRepository
                .findByStatusAndUserDepartmentName(AppraisalStatus.DCM_APPROVED, departmentName);
        long pendingApprovals = departmentForms.size();
        
        // Get completed approvals by current HOD
        long completedApprovals = reviewRepository.countByReviewerAndLevel(currentHOD, ReviewLevel.HOD_REVIEW);
        
        // Get total staff in department
        long totalStaff = userRepository.countByDepartmentName(departmentName);
        
        dashboard.put("pendingApprovals", pendingApprovals);
        dashboard.put("completedApprovals", completedApprovals);
        dashboard.put("totalStaff", totalStaff);
        dashboard.put("department", departmentName);
        dashboard.put("hodName", currentHOD.getFullName());
        dashboard.put("completionRate", totalStaff > 0 ? (double) completedApprovals / totalStaff * 100 : 0.0);
        
        return dashboard;
    }

    @Override
    public Page<AppraisalFormDTO> getPendingApprovals(Pageable pageable, String department) {
        // Get current HOD and their department
        User currentHOD = getCurrentHOD();
        String hodDepartment = currentHOD.getDepartment().getName();
        
        // Security check: HOD can only see their own department
        if (department != null && !department.equals(hodDepartment)) {
            log.warn("SECURITY VIOLATION: HOD {} from {} tried to access {} department forms", 
                    currentHOD.getFullName(), hodDepartment, department);
            throw new SecurityException("You can only view approvals from your own department");
        }
        
        // Get forms ONLY from HOD's department with HOD_APPROVED status
        List<AppraisalForm> pendingForms = appraisalFormRepository
                .findByStatusAndUserDepartmentName(AppraisalStatus.HOD_APPROVED, hodDepartment);
        
        List<AppraisalFormDTO> dtoList = pendingForms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        // Apply pagination
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<AppraisalFormDTO> pageContent = start < dtoList.size() ? dtoList.subList(start, end) : new ArrayList<>();
        
        log.info("Found {} pending approvals for HOD in {} department", dtoList.size(), hodDepartment);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    @Transactional
    public ReviewDTO submitHODDecision(ReviewDTO reviewDTO, String currentUserEmail) {
        AppraisalForm appraisal = appraisalFormRepository.findById(reviewDTO.getAppraisalFormId())
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.DCM_APPROVED) {
            throw new IllegalStateException("Appraisal is not in correct state for HOD decision");
        }
        
        // Get current HOD
        User reviewer = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current user not found: " + currentUserEmail));
        
        // DEPARTMENT SECURITY: Ensure HOD can only review forms from their department
        String hodDepartment = reviewer.getDepartment().getName();
        String formDepartment = appraisal.getUser().getDepartment().getName();
        
        if (!hodDepartment.equals(formDepartment)) {
            log.warn("SECURITY VIOLATION: HOD {} from {} tried to review form from {} department", 
                    reviewer.getFullName(), hodDepartment, formDepartment);
            throw new SecurityException("You can only review appraisals from your own department");
        }
        
        // Validate user has HOD role
        boolean hasHODRole = reviewer.getRoles().stream()
                .anyMatch(role -> "HOD".equals(role.getName()));
        if (!hasHODRole) {
            throw new SecurityException("User does not have HOD role");
        }
        
        // Check if HOD already reviewed this form
        Optional<Review> existingReview = reviewRepository.findByReviewerAndAppraisalForm(reviewer, appraisal);
        if (existingReview.isPresent()) {
            throw new IllegalStateException("You have already reviewed this appraisal form");
        }
        
        // Create review
        Review review = Review.builder()
                .reviewer(reviewer)
                .appraisalForm(appraisal)
                .decision(ReviewDecision.valueOf(reviewDTO.getDecision()))
                .remarks(reviewDTO.getRemarks())
                .level(ReviewLevel.HOD_REVIEW)
                .reviewedAt(LocalDateTime.now())
                .build();
        
        Review savedReview = reviewRepository.save(review);
        
        // Update appraisal status using workflow service
        AppraisalStatus newStatus = workflowService.transitionToNextStage(
            reviewDTO.getAppraisalFormId(), 
            appraisal.getStatus(), 
            reviewDTO.getDecision()
        );
        appraisal.setStatus(newStatus);
        appraisalFormRepository.save(appraisal);
        
        // AUTO-ASSIGNMENT: If approved, trigger committee assignment
        if ("APPROVED".equalsIgnoreCase(reviewDTO.getDecision()) && 
            newStatus == AppraisalStatus.COMMITTEE_REVIEW) {
            try {
                formAssignmentService.handleFormStatusChange(appraisal.getId(), newStatus.name());
                log.info("Auto-assigned form {} to committee member after HOD approval", 
                        appraisal.getId());
            } catch (Exception e) {
                log.error("Failed to auto-assign form {} to committee member: {}", 
                        appraisal.getId(), e.getMessage());
            }
        }
        
        log.info("HOD {} from {} department submitted {} decision for appraisal {} (Staff: {})", 
                reviewer.getFullName(), hodDepartment, reviewDTO.getDecision(), 
                reviewDTO.getAppraisalFormId(), appraisal.getUser().getFullName());
        
        return mapReviewToDTO(savedReview);
    }

    @Override
    public AppraisalFormDTO getAppraisalForHODReview(UUID formId) {
        AppraisalForm appraisal = appraisalFormRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        if (appraisal.getStatus() != AppraisalStatus.HOD_APPROVED) {
            throw new IllegalStateException("Appraisal is not available for HOD review");
        }
        
        return mapToDTO(appraisal);
    }

    @Override
    public Page<ReviewDTO> getHODReviewHistory(Pageable pageable, String academicYear) {
        // Get all reviews by HODs (could be filtered by academic year)
        List<Review> reviews = reviewRepository.findAll().stream()
                .filter(review -> ReviewLevel.HOD_REVIEW.equals(review.getLevel()))
                .collect(Collectors.toList());
        
        if (academicYear != null) {
            reviews = reviews.stream()
                    .filter(review -> academicYear.equals(review.getAppraisalForm().getAcademicYear()))
                    .collect(Collectors.toList());
        }
        
        List<ReviewDTO> dtoList = reviews.stream()
                .map(this::mapReviewToDTO)
                .collect(Collectors.toList());
        
        // Manual pagination
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), dtoList.size());
        List<ReviewDTO> pageContent = dtoList.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, dtoList.size());
    }

    @Override
    public Map<String, Object> getDepartmentStatistics(String academicYear, String department) {
        Map<String, Object> stats = new HashMap<>();
        
        // Get department-specific statistics
        List<AppraisalForm> departmentAppraisals = appraisalFormRepository.findByAcademicYear(academicYear)
                .stream()
                .filter(form -> department == null || department.equals(form.getUser().getDepartment().getName()))
                .collect(Collectors.toList());
        
        long totalAppraisals = departmentAppraisals.size();
        long approvedAppraisals = departmentAppraisals.stream()
                .mapToLong(form -> form.getStatus() == AppraisalStatus.COMPLETED ? 1 : 0)
                .sum();
        
        stats.put("totalAppraisals", totalAppraisals);
        stats.put("approvedAppraisals", approvedAppraisals);
        stats.put("pendingAppraisals", totalAppraisals - approvedAppraisals);
        stats.put("approvalRate", totalAppraisals > 0 ? (double) approvedAppraisals / totalAppraisals : 0.0);
        stats.put("department", department);
        stats.put("academicYear", academicYear);
        
        return stats;
    }

    @Override
    public Map<String, Object> getStaffPerformanceOverview(String academicYear, String department) {
        Map<String, Object> overview = new HashMap<>();
        
        // Get staff performance metrics for the department
        List<AppraisalForm> staffAppraisals = appraisalFormRepository.findByAcademicYear(academicYear)
                .stream()
                .filter(form -> department == null || department.equals(form.getUser().getDepartment().getName()))
                .collect(Collectors.toList());
        
        double averageScore = staffAppraisals.stream()
                .filter(form -> Objects.nonNull(form.getTotalScore()) && form.getTotalScore() > 0)
                .mapToDouble(AppraisalForm::getTotalScore)
                .average()
                .orElse(0.0);
        
        long highPerformers = staffAppraisals.stream()
                .filter(form -> Objects.nonNull(form.getTotalScore()) && form.getTotalScore() >= 80.0)
                .count();
        
        overview.put("totalStaff", staffAppraisals.size());
        overview.put("averageScore", Math.round(averageScore * 100.0) / 100.0);
        overview.put("highPerformers", highPerformers);
        overview.put("performanceRate", staffAppraisals.size() > 0 ? 
                (double) highPerformers / staffAppraisals.size() : 0.0);
        overview.put("department", department);
        overview.put("academicYear", academicYear);
        
        return overview;
    }

    private AppraisalFormDTO mapToDTO(AppraisalForm form) {
        return AppraisalFormDTO.builder()
                .id(form.getId())
                .academicYear(form.getAcademicYear())
                .status(form.getStatus().name())
                .submittedDate(form.getSubmittedDate())
                .totalScore(form.getTotalScore())
                .userFullName(form.getUser().getFullName())
                .userId(form.getUser().getId())
                .build();
    }

    private ReviewDTO mapReviewToDTO(Review review) {
        return ReviewDTO.builder()
                .id(review.getId())
                .appraisalFormId(review.getAppraisalForm().getId())
                .reviewerId(review.getReviewer().getId())
                .decision(review.getDecision().name())
                .remarks(review.getRemarks())
                .level(review.getLevel().name())
                .reviewedAt(review.getReviewedAt())
                .reviewerName(review.getReviewer().getFullName())
                .reviewerDepartment(review.getReviewer().getDepartment().getName())
                .build();
    }

    /**
     * Get current authenticated HOD user
     */
    private User getCurrentHOD() {
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Current HOD user not found"));
    }
} 