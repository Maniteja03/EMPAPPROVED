package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.scoring.ComponentScoreBreakdown;
import com.cvrce.apraisal.dto.scoring.ScoringCalculationResult;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.*;
import com.cvrce.apraisal.service.ScoringCalculationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ScoringCalculationServiceImpl implements ScoringCalculationService {
    
    private final AppraisalFormRepository appraisalFormRepository;
    private final AppraisalScoringRepository appraisalScoringRepository;
    private final PublicationScoringRepository publicationScoringRepository;
    private final CitationScoringRepository citationScoringRepository;
    private final PatentScoringRepository patentScoringRepository;
    private final ProjectScoringRepository projectScoringRepository;
    private final ConsultancyScoringRepository consultancyScoringRepository;
    private final TeachingPerformanceScoringRepository teachingPerformanceScoringRepository;
    private final ConferenceScoringRepository conferenceScoringRepository;
    private final AdministrativeScoringRepository administrativeScoringRepository;
    private final StudentTrainingScoringRepository studentTrainingScoringRepository;
    
    @Override
    public ScoringCalculationResult calculateCompleteScoring(UUID appraisalFormId) {
        log.info("Starting complete scoring calculation for appraisal form: {}", appraisalFormId);
        
        AppraisalForm form = appraisalFormRepository.findById(appraisalFormId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal form not found"));
        
        AppraisalScoring scoring = appraisalScoringRepository.findByAppraisalForm(form)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal scoring not found"));
        
        // Auto-calculate all component scores
        autoCalculateAllScores(scoring);
        
        // Calculate part totals
        BigDecimal partAScore = calculatePartAScoring(scoring);
        BigDecimal partBScore = calculatePartBScoring(scoring);
        BigDecimal partCScore = calculatePartCScoring(scoring);
        
        // Update scoring entity
        scoring.setPartARawScore(calculatePartARawTotal(scoring));
        scoring.calculatePartAFinalScore();
        scoring.setPartBRawScore(calculatePartBRawTotal(scoring));
        scoring.calculatePartBFinalScore();
        scoring.setPartCScore(partCScore);
        scoring.calculateTotalScore();
        
        // Apply H&S Faculty special logic if applicable
        if (scoring.getIsHSFaculty()) {
            applyHSFacultyLogic(scoring);
        }
        
        appraisalScoringRepository.save(scoring);
        
        // Build result
        return buildCalculationResult(scoring);
    }
    
    @Override
    public BigDecimal calculatePartAScoring(AppraisalScoring appraisalScoring) {
        log.debug("Calculating Part A scoring for appraisal: {}", appraisalScoring.getId());
        
        BigDecimal publicationsScore = calculatePublicationsScoring(appraisalScoring);
        BigDecimal citationsScore = calculateCitationsScoring(appraisalScoring);
        BigDecimal patentsScore = calculatePatentsScoring(appraisalScoring);
        BigDecimal projectsScore = calculateProjectsScoring(appraisalScoring);
        BigDecimal consultancyScore = calculateConsultancyScoring(appraisalScoring);
        
        BigDecimal rawTotal = publicationsScore.add(citationsScore)
                .add(patentsScore).add(projectsScore).add(consultancyScore);
        
        // Scale to 40 points
        if (appraisalScoring.getPartAMaxRaw() != null && appraisalScoring.getPartAMaxRaw().compareTo(BigDecimal.ZERO) > 0) {
            return rawTotal.divide(appraisalScoring.getPartAMaxRaw(), 2, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("40"));
        }
        
        return BigDecimal.ZERO;
    }
    
    @Override
    public BigDecimal calculatePartBScoring(AppraisalScoring appraisalScoring) {
        log.debug("Calculating Part B scoring for appraisal: {}", appraisalScoring.getId());
        
        BigDecimal teachingScore = calculateTeachingPerformanceScoring(appraisalScoring);
        BigDecimal conferenceScore = calculateConferenceScoring(appraisalScoring);
        BigDecimal administrativeScore = calculateAdministrativeScoring(appraisalScoring);
        
        BigDecimal rawTotal = teachingScore.add(conferenceScore).add(administrativeScore);
        
        // Scale to 60 points
        if (appraisalScoring.getPartBMaxRaw() != null && appraisalScoring.getPartBMaxRaw().compareTo(BigDecimal.ZERO) > 0) {
            return rawTotal.divide(appraisalScoring.getPartBMaxRaw(), 2, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("60"));
        }
        
        return BigDecimal.ZERO;
    }
    
    @Override
    public BigDecimal calculatePartCScoring(AppraisalScoring appraisalScoring) {
        log.debug("Calculating Part C scoring for appraisal: {}", appraisalScoring.getId());
        return calculateStudentTrainingScoring(appraisalScoring);
    }
    
    @Override
    public BigDecimal calculatePublicationsScoring(AppraisalScoring appraisalScoring) {
        List<PublicationScoring> publications = publicationScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return publications.stream()
                .peek(PublicationScoring::calculatePoints)
                .map(pub -> pub.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     pub.getPointsAwarded() : pub.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateCitationsScoring(AppraisalScoring appraisalScoring) {
        List<CitationScoring> citations = citationScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return citations.stream()
                .peek(CitationScoring::calculatePoints)
                .map(cit -> cit.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     cit.getPointsAwarded() : cit.getPointsClaimed())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculatePatentsScoring(AppraisalScoring appraisalScoring) {
        List<PatentScoring> patents = patentScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return patents.stream()
                .peek(PatentScoring::calculatePoints)
                .map(pat -> pat.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     pat.getPointsAwarded() : pat.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateProjectsScoring(AppraisalScoring appraisalScoring) {
        List<ProjectScoring> projects = projectScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return projects.stream()
                .peek(ProjectScoring::calculatePoints)
                .map(proj -> proj.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     proj.getPointsAwarded() : proj.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateConsultancyScoring(AppraisalScoring appraisalScoring) {
        List<ConsultancyScoring> consultancies = consultancyScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return consultancies.stream()
                .peek(ConsultancyScoring::calculatePoints)
                .map(cons -> cons.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     cons.getPointsAwarded() : cons.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateTeachingPerformanceScoring(AppraisalScoring appraisalScoring) {
        List<TeachingPerformanceScoring> teachings = teachingPerformanceScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        // Calculate average pass percentage and get corresponding points
        if (teachings.isEmpty()) {
            return BigDecimal.ZERO;
        }
        
        BigDecimal totalPercentage = teachings.stream()
                .peek(TeachingPerformanceScoring::calculatePoints)
                .map(TeachingPerformanceScoring::getPassPercentage)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal avgPercentage = totalPercentage.divide(new BigDecimal(teachings.size()), 2, RoundingMode.HALF_UP);
        
        // Convert average percentage to points based on Annexure VI table
        return convertPassPercentageToPoints(avgPercentage);
    }
    
    @Override
    public BigDecimal calculateConferenceScoring(AppraisalScoring appraisalScoring) {
        List<ConferenceScoring> conferences = conferenceScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return conferences.stream()
                .peek(ConferenceScoring::calculatePoints)
                .map(conf -> conf.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     conf.getPointsAwarded() : conf.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateAdministrativeScoring(AppraisalScoring appraisalScoring) {
        List<AdministrativeScoring> administratives = administrativeScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return administratives.stream()
                .map(admin -> admin.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     admin.getPointsAwarded() : admin.getPointsClaimed())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public BigDecimal calculateStudentTrainingScoring(AppraisalScoring appraisalScoring) {
        List<StudentTrainingScoring> trainings = studentTrainingScoringRepository.findByAppraisalScoring(appraisalScoring);
        
        return trainings.stream()
                .peek(StudentTrainingScoring::calculatePoints)
                .map(train -> train.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     train.getPointsAwarded() : train.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public void applyHSFacultyLogic(AppraisalScoring appraisalScoring) {
        if (!appraisalScoring.getIsHSFaculty()) {
            return;
        }
        
        log.info("Applying H&S Faculty special logic for scoring: {}", appraisalScoring.getId());
        
        // Calculate organizing events score (from conferences organized)
        List<ConferenceScoring> organizedConferences = conferenceScoringRepository.findByAppraisalScoring(appraisalScoring)
                .stream()
                .filter(conf -> conf.getParticipationType() == ParticipationType.ORGANIZED)
                .toList();
        
        BigDecimal organizingScore = organizedConferences.stream()
                .map(conf -> conf.getPointsAwarded().compareTo(BigDecimal.ZERO) > 0 ? 
                     conf.getPointsAwarded() : conf.getAutoCalculatedPoints())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // H&S Faculty can get up to 50% of Part A points from organizing events
        BigDecimal maxFromOrganizing = appraisalScoring.getPartAFinalScore().multiply(new BigDecimal("0.5"));
        BigDecimal hsBonus = organizingScore.min(maxFromOrganizing);
        
        appraisalScoring.setHsOrganizingEventsScore(hsBonus);
        appraisalScoring.setPartAFinalScore(appraisalScoring.getPartAFinalScore().add(hsBonus));
        appraisalScoring.calculateTotalScore();
    }
    
    @Override
    public List<ComponentScoreBreakdown> getDetailedScoreBreakdown(UUID appraisalFormId) {
        // Implementation for detailed breakdown
        List<ComponentScoreBreakdown> breakdowns = new ArrayList<>();
        
        AppraisalScoring scoring = appraisalScoringRepository.findByAppraisalFormId(appraisalFormId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal scoring not found"));
        
        // Add breakdown for each component
        breakdowns.add(createPublicationBreakdown(scoring));
        breakdowns.add(createCitationBreakdown(scoring));
        breakdowns.add(createPatentBreakdown(scoring));
        // ... Add other components
        
        return breakdowns;
    }
    
    @Override
    public boolean validateScoringLimits(AppraisalScoring appraisalScoring) {
        DesignationGroup group = appraisalScoring.getDesignationAtSubmission().getDesignationGroup();
        
        boolean partAValid = appraisalScoring.getPartARawScore().compareTo(appraisalScoring.getPartAMaxRaw()) <= 0;
        boolean partBValid = appraisalScoring.getPartBRawScore().compareTo(appraisalScoring.getPartBMaxRaw()) <= 0;
        boolean partCValid = appraisalScoring.getPartCScore().compareTo(new BigDecimal("25")) <= 0;
        
        return partAValid && partBValid && partCValid;
    }
    
    @Override
    public void autoCalculateAllScores(AppraisalScoring appraisalScoring) {
        log.debug("Auto-calculating all scores for appraisal: {}", appraisalScoring.getId());
        
        // Calculate all individual component scores
        calculatePublicationsScoring(appraisalScoring);
        calculateCitationsScoring(appraisalScoring);
        calculatePatentsScoring(appraisalScoring);
        calculateProjectsScoring(appraisalScoring);
        calculateConsultancyScoring(appraisalScoring);
        calculateTeachingPerformanceScoring(appraisalScoring);
        calculateConferenceScoring(appraisalScoring);
        calculateStudentTrainingScoring(appraisalScoring);
        
        appraisalScoring.setLastCalculatedAt(LocalDateTime.now());
    }
    
    @Override
    public void applyManualOverride(UUID appraisalFormId, String componentType, BigDecimal overrideScore, String reason) {
        AppraisalScoring scoring = appraisalScoringRepository.findByAppraisalFormId(appraisalFormId)
                .orElseThrow(() -> new ResourceNotFoundException("Appraisal scoring not found"));
        
        scoring.setIsAutoCalculated(false);
        scoring.setManualOverrideReason(reason);
        
        // Apply override based on component type
        // Implementation would handle different component types
        
        appraisalScoringRepository.save(scoring);
        log.info("Applied manual override for component {} in appraisal {}: {} points", 
                componentType, appraisalFormId, overrideScore);
    }
    
    @Override
    public ComponentScoreBreakdown getMaxScoresForDesignation(StaffDesignation designation) {
        DesignationGroup group = designation.getDesignationGroup();
        
        return ComponentScoreBreakdown.builder()
                .componentName("Maximum Scores")
                .maxPossibleScore(new BigDecimal("125")) // Total max
                .calculationNotes("Part A: 40, Part B: 60, Part C: 25")
                .build();
    }
    
    @Override
    public void recalculateScoring(UUID appraisalFormId) {
        log.info("Recalculating scoring for appraisal form: {}", appraisalFormId);
        calculateCompleteScoring(appraisalFormId);
    }
    
    // Helper methods
    private BigDecimal calculatePartARawTotal(AppraisalScoring scoring) {
        return calculatePublicationsScoring(scoring)
                .add(calculateCitationsScoring(scoring))
                .add(calculatePatentsScoring(scoring))
                .add(calculateProjectsScoring(scoring))
                .add(calculateConsultancyScoring(scoring));
    }
    
    private BigDecimal calculatePartBRawTotal(AppraisalScoring scoring) {
        return calculateTeachingPerformanceScoring(scoring)
                .add(calculateConferenceScoring(scoring))
                .add(calculateAdministrativeScoring(scoring));
    }
    
    private BigDecimal convertPassPercentageToPoints(BigDecimal percentage) {
        if (percentage.compareTo(new BigDecimal("90")) >= 0) return new BigDecimal("20");
        if (percentage.compareTo(new BigDecimal("80")) >= 0) return new BigDecimal("19");
        if (percentage.compareTo(new BigDecimal("70")) >= 0) return new BigDecimal("18");
        if (percentage.compareTo(new BigDecimal("60")) >= 0) return new BigDecimal("17");
        if (percentage.compareTo(new BigDecimal("50")) >= 0) return new BigDecimal("16");
        return new BigDecimal("15");
    }
    
    private ScoringCalculationResult buildCalculationResult(AppraisalScoring scoring) {
        return ScoringCalculationResult.builder()
                .appraisalFormId(scoring.getAppraisalForm().getId())
                .facultyName(scoring.getAppraisalForm().getUser().getFullName())
                .employeeId(scoring.getAppraisalForm().getUser().getEmployeeId())
                .academicYear(scoring.getAppraisalForm().getAcademicYear())
                .designationType(scoring.getDesignationAtSubmission().getDesignationType().getDisplayName())
                .partARawScore(scoring.getPartARawScore())
                .partAMaxRaw(scoring.getPartAMaxRaw())
                .partAFinalScore(scoring.getPartAFinalScore())
                .partBRawScore(scoring.getPartBRawScore())
                .partBMaxRaw(scoring.getPartBMaxRaw())
                .partBFinalScore(scoring.getPartBFinalScore())
                .partCScore(scoring.getPartCScore())
                .totalScore(scoring.getTotalScore())
                .maxPossibleScore(scoring.getMaxPossibleScore())
                .scorePercentage(scoring.getScorePercentage())
                .isAutoCalculated(scoring.getIsAutoCalculated())
                .calculatedAt(scoring.getLastCalculatedAt())
                .isHSFaculty(scoring.getIsHSFaculty())
                .hsOrganizingEventsScore(scoring.getHsOrganizingEventsScore())
                .isValid(validateScoringLimits(scoring))
                .build();
    }
    
    private ComponentScoreBreakdown createPublicationBreakdown(AppraisalScoring scoring) {
        List<PublicationScoring> publications = publicationScoringRepository.findByAppraisalScoring(scoring);
        BigDecimal totalScore = calculatePublicationsScoring(scoring);
        
        return ComponentScoreBreakdown.builder()
                .componentName("Publications")
                .annexureReference("Annexure I")
                .partName("Part A")
                .maxPossibleScore(getMaxPublicationScore(scoring.getDesignationAtSubmission()))
                .awardedScore(totalScore)
                .calculationFormula("Based on publication type and author count")
                .build();
    }
    
    private ComponentScoreBreakdown createCitationBreakdown(AppraisalScoring scoring) {
        List<CitationScoring> citations = citationScoringRepository.findByAppraisalScoring(scoring);
        BigDecimal totalScore = calculateCitationsScoring(scoring);
        
        return ComponentScoreBreakdown.builder()
                .componentName("Citations")
                .annexureReference("Annexure II")
                .partName("Part A")
                .maxPossibleScore(getMaxCitationScore(scoring.getDesignationAtSubmission()))
                .awardedScore(totalScore)
                .calculationFormula("1 point per citation")
                .build();
    }
    
    private ComponentScoreBreakdown createPatentBreakdown(AppraisalScoring scoring) {
        List<PatentScoring> patents = patentScoringRepository.findByAppraisalScoring(scoring);
        BigDecimal totalScore = calculatePatentsScoring(scoring);
        
        return ComponentScoreBreakdown.builder()
                .componentName("Patents")
                .annexureReference("Annexure III")
                .partName("Part A")
                .maxPossibleScore(getMaxPatentScore(scoring.getDesignationAtSubmission()))
                .awardedScore(totalScore)
                .calculationFormula("Based on patent status and inventor count")
                .build();
    }
    
    private BigDecimal getMaxPublicationScore(StaffDesignation designation) {
        return switch (designation.getDesignationGroup()) {
            case PROFESSOR -> new BigDecimal("35");
            case ASSOCIATE_LEVEL -> new BigDecimal("27");
            case ASSISTANT_LEVEL -> new BigDecimal("18");
        };
    }
    
    private BigDecimal getMaxCitationScore(StaffDesignation designation) {
        return switch (designation.getDesignationGroup()) {
            case PROFESSOR -> new BigDecimal("40");
            case ASSOCIATE_LEVEL -> new BigDecimal("30");
            case ASSISTANT_LEVEL -> new BigDecimal("20");
        };
    }
    
    private BigDecimal getMaxPatentScore(StaffDesignation designation) {
        return switch (designation.getDesignationGroup()) {
            case PROFESSOR -> new BigDecimal("15");
            case ASSOCIATE_LEVEL -> new BigDecimal("12");
            case ASSISTANT_LEVEL -> new BigDecimal("10");
        };
    }
} 