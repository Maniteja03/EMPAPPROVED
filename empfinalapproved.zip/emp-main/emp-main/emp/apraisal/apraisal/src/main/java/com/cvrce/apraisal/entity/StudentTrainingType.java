package com.cvrce.apraisal.entity;

import java.math.BigDecimal;

public enum StudentTrainingType {
    E_BOX_TRAINING("E-Box Training", new BigDecimal("15")),
    STUDENT_CERTIFICATION("Student Certification", new BigDecimal("10"));
    
    private final String displayName;
    private final BigDecimal maxPoints;
    
    StudentTrainingType(String displayName, BigDecimal maxPoints) {
        this.displayName = displayName;
        this.maxPoints = maxPoints;
    }
    
    public String getDisplayName() { return displayName; }
    public BigDecimal getMaxPoints() { return maxPoints; }
} 