package com.cvrce.apraisal.controller;

import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;

@RestController
@RequestMapping("/api/files")
@Slf4j
public class FileDownloadController {

    @Value("${file.upload.directory:C:/temp/uploads}")
    private String baseUploadDir;
    
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("pdf", "jpg", "jpeg", "png", "doc", "docx", "txt");

    @GetMapping("/download")
    @PreAuthorize("hasRole('STAFF') or hasRole('DCM') or hasRole('HOD') or hasRole('COMMITTEE') or hasRole('CHAIRPERSON') or hasRole('PRINCIPAL') or hasRole('ADMIN')")
    public ResponseEntity<Resource> downloadFile(
            @RequestParam("formId") String formId,
            @RequestParam("section") String section,
            @RequestParam("filename") String filename
    ) {
        try {
            // Sanitize inputs to prevent path traversal attacks
            String safeFormId = formId.replaceAll("[^a-zA-Z0-9_-]", "_");
            String safeSection = section.toUpperCase().replaceAll("[^A-Z0-9_]", "_");
            String safeFilename = sanitizeFilename(filename);
            
            // Validate file extension
            if (!isAllowedFileExtension(safeFilename)) {
                log.warn("Blocked download attempt for disallowed file type: {}", filename);
                return ResponseEntity.badRequest().build();
            }
            
            String fullPath = baseUploadDir + "/" + safeFormId + "/" + safeSection + "/" + safeFilename;
            
            // Additional path validation to prevent directory traversal
            if (!isPathSafe(fullPath)) {
                log.warn("Path traversal attempt blocked: {}", fullPath);
                return ResponseEntity.badRequest().build();
            }

            File file = new File(fullPath);
            if (!file.exists()) {
                log.warn("File not found: {}", fullPath);
                return ResponseEntity.notFound().build();
            }

            FileSystemResource resource = new FileSystemResource(file);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.attachment().filename(file.getName()).build());
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return new ResponseEntity<>(resource, headers, HttpStatus.OK);

        } catch (Exception e) {
            log.error("File download failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    /**
     * Sanitize filename to prevent path traversal attacks
     * @param filename the original filename
     * @return sanitized filename
     */
    private String sanitizeFilename(String filename) {
        if (filename == null || filename.trim().isEmpty()) {
            throw new IllegalArgumentException("Filename cannot be null or empty");
        }
        
        String sanitized = filename.trim();
        
        // Remove any path traversal attempts
        sanitized = sanitized.replaceAll("\\.\\./", "");
        sanitized = sanitized.replaceAll("\\.\\.", "");
        sanitized = sanitized.replaceAll("\\\\", "");
        sanitized = sanitized.replaceAll("/", "");
        
        // Allow only safe characters: letters, numbers, dots, hyphens, underscores
        sanitized = sanitized.replaceAll("[^a-zA-Z0-9._-]", "_");
        
        // Ensure filename doesn't start with dot (hidden files)
        if (sanitized.startsWith(".")) {
            sanitized = "file" + sanitized;
        }
        
        // Limit filename length
        if (sanitized.length() > 100) {
            String extension = "";
            int dotIndex = sanitized.lastIndexOf('.');
            if (dotIndex > 0) {
                extension = sanitized.substring(dotIndex);
                sanitized = sanitized.substring(0, Math.min(95, dotIndex)) + extension;
            } else {
                sanitized = sanitized.substring(0, 100);
            }
        }
        
        return sanitized;
    }
    
    /**
     * Check if file extension is allowed
     * @param filename the filename to check
     * @return true if extension is allowed
     */
    private boolean isAllowedFileExtension(String filename) {
        if (filename == null || !filename.contains(".")) {
            return false;
        }
        
        String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
        return ALLOWED_EXTENSIONS.contains(extension);
    }
    
    /**
     * Validate that the resolved path is within allowed directory
     * @param filePath the file path to validate
     * @return true if path is safe
     */
    private boolean isPathSafe(String filePath) {
        try {
            Path normalizedPath = Paths.get(filePath).normalize();
            Path allowedBasePath = Paths.get(baseUploadDir).normalize();
            return normalizedPath.startsWith(allowedBasePath);
        } catch (Exception e) {
            log.error("Path validation failed", e);
            return false;
        }
    }
}
