package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;
    
    @Value("${spring.mail.username}")
    private String fromEmail;
    
    @Value("${app.name:Employee Appraisal System}")
    private String appName;

    @Override
    public void sendOtpEmail(String email, String otp, String userName) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(email);
            message.setSubject("Password Reset OTP - " + appName);
            
            String emailBody = String.format(
                "Dear %s,\n\n" +
                "You have requested to reset your password for %s.\n\n" +
                "Your OTP is: %s\n\n" +
                "This OTP is valid for 5 minutes only.\n\n" +
                "If you did not request this password reset, please ignore this email.\n\n" +
                "Best regards,\n" +
                "%s Team",
                userName, appName, otp, appName
            );
            
            message.setText(emailBody);
            mailSender.send(message);
            
            log.info("OTP email sent successfully to {}", email);
        } catch (Exception e) {
            log.error("Failed to send OTP email to {}: {}", email, e.getMessage());
            throw new RuntimeException("Failed to send OTP email", e);
        }
    }

    @Override
    public void sendWelcomeEmail(String email, String userName, String temporaryPassword, String employeeId) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(email);
            message.setSubject("Welcome to " + appName + " - Your Account Details");
            
            String emailBody = String.format(
                "Dear %s,\n\n" +
                "Welcome to %s!\n\n" +
                "Your account has been created successfully. Here are your login credentials:\n\n" +
                "Employee ID: %s\n" +
                "Email: %s\n" +
                "Temporary Password: %s\n\n" +
                "IMPORTANT SECURITY NOTICE:\n" +
                "- This is a temporary password\n" +
                "- Please change your password immediately after first login\n" +
                "- Use the 'Forgot Password' feature to set a new secure password\n\n" +
                "Login URL: [Your Application URL]\n\n" +
                "For any assistance, please contact the system administrator.\n\n" +
                "Best regards,\n" +
                "%s Admin Team",
                userName, appName, employeeId, email, temporaryPassword, appName
            );
            
            message.setText(emailBody);
            mailSender.send(message);
            
            log.info("Welcome email sent successfully to {} ({})", email, employeeId);
        } catch (Exception e) {
            log.error("Failed to send welcome email to {}: {}", email, e.getMessage());
            throw new RuntimeException("Failed to send welcome email", e);
        }
    }

    @Override
    public void sendNotificationEmail(String email, String subject, String messageBody) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(email);
            message.setSubject(subject + " - " + appName);
            message.setText(messageBody);
            
            mailSender.send(message);
            log.info("Notification email sent to {}: {}", email, subject);
        } catch (Exception e) {
            log.error("Failed to send notification email to {}: {}", email, e.getMessage());
            throw new RuntimeException("Failed to send notification email", e);
        }
    }
} 