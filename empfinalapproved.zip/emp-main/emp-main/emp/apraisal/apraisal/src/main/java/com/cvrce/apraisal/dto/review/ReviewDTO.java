package com.cvrce.apraisal.dto.review;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDTO {
    private UUID id;
    private UUID reviewerId;
    private UUID appraisalFormId;
    private String decision;
    private String remarks;
    private String level;
    private LocalDateTime reviewedAt;
    private String reviewerName;
    private String reviewerDepartment;
}
