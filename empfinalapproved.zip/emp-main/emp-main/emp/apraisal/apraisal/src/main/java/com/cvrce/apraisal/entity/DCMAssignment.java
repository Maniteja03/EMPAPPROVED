package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "dcm_assignments")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DCMAssignment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "staff_member_id", nullable = false)
    private User staffMember; // The staff member assigned as DCM
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_by_hod_id", nullable = false)
    private User assignedByHod; // The HOD who made this assignment
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department; // Department this DCM assignment is for
    
    @Column(name = "academic_year", nullable = false, length = 20)
    private String academicYear; // e.g., "2023-24"
    
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;
    
    @CreationTimestamp
    @Column(name = "assigned_at", nullable = false)
    private LocalDateTime assignedAt;
    
    @Column(name = "deactivated_at")
    private LocalDateTime deactivatedAt;
    
    // Helper method to deactivate DCM assignment
    public void deactivate() {
        this.isActive = false;
        this.deactivatedAt = LocalDateTime.now();
    }
    
    // Check if assignment is currently active
    public boolean isCurrentlyActive() {
        return isActive && deactivatedAt == null;
    }
    
    // Check if this is for current academic year (you'll need to implement getCurrentAcademicYear somewhere)
    public boolean isForCurrentYear(String currentAcademicYear) {
        return isActive && academicYear.equals(currentAcademicYear);
    }
} 