package com.cvrce.apraisal.dto.dcm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DCMSelectionDTO {
    
    private UUID staffId;
    private String fullName;
    private String email;
    private String employeeId;
    private String departmentName;
    private boolean isCurrentlyDCM;
    private boolean isEligible;
    private String ineligibilityReason;
    private int yearsOfExperience;
    private String designation;
    private boolean hasSubmittedOwnAppraisal;
    private int previousDCMAssignments;
    
    // Helper methods
    public boolean canBeAssignedAsDCM() {
        return isEligible && !isCurrentlyDCM;
    }
    
    public String getDisplayName() {
        return fullName + " (" + employeeId + ")";
    }
} 