package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.SystemMetrics;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface SystemMetricsRepository extends JpaRepository<SystemMetrics, UUID> {
    
    Page<SystemMetrics> findByType(SystemMetrics.MetricType type, Pageable pageable);
    
    Page<SystemMetrics> findByCategory(String category, Pageable pageable);
    
    Page<SystemMetrics> findByRecordedAtBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    
    List<SystemMetrics> findByMetricNameAndRecordedAtBetween(String metricName, LocalDateTime startDate, LocalDateTime endDate);
    
    @Query("SELECT m.metricName, AVG(m.metricValue) FROM SystemMetrics m WHERE m.type = :type AND m.recordedAt >= :since GROUP BY m.metricName")
    List<Object[]> findAverageMetricsByTypeSince(@Param("type") SystemMetrics.MetricType type, @Param("since") LocalDateTime since);
    
    @Query("SELECT m FROM SystemMetrics m WHERE m.metricName = :metricName ORDER BY m.recordedAt DESC")
    List<SystemMetrics> findLatestByMetricName(@Param("metricName") String metricName, Pageable pageable);
    
    @Modifying
    @Query("DELETE FROM SystemMetrics m WHERE m.recordedAt < :cutoffDate")
    int deleteOldMetrics(@Param("cutoffDate") LocalDateTime cutoffDate);
} 