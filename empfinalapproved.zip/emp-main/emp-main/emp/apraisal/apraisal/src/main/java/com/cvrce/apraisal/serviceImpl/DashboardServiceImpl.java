package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.*;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.entity.review.ReviewerAssignment;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.ReviewerAssignmentRepository;
import com.cvrce.apraisal.repo.UserRepository;
//import com.cvrce.apraisal.repository.*;
import com.cvrce.apraisal.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final ReviewerAssignmentRepository reviewerAssignmentRepository;

    @Override
    public DashboardSummaryDTO getDashboardSummary() {
        // Use efficient counting queries instead of findAll()
        long totalAppraisals = appraisalFormRepository.count();
        long submittedAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.SUBMITTED);
        long completedAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.COMPLETED);
        long pendingAppraisals = appraisalFormRepository.countByStatus(AppraisalStatus.DEPARTMENT_REVIEW);
        
        long totalUsers = userRepository.count();
        long totalDepartments = userRepository.countDepartments();
        
        // Use efficient query for reviewer load instead of findAll()
        List<ReviewerLoadDTO> reviewerLoad = getReviewerLoadEfficiently();
        
        return DashboardSummaryDTO.builder()
                .totalSubmissions(totalAppraisals)
                .submittedToday(submittedAppraisals)
                .pendingDepartmentReviews(pendingAppraisals)
                .pendingCommitteeReviews(appraisalFormRepository.countByStatus(AppraisalStatus.COLLEGE_REVIEW))
                .pendingChairpersonReviews(appraisalFormRepository.countByStatus(AppraisalStatus.CHAIRPERSON_REVIEW))
                .totalApproved(completedAppraisals)
                .totalReuploadRequested(appraisalFormRepository.countByStatus(AppraisalStatus.REUPLOAD_REQUIRED))
                .totalDepartments(totalDepartments)
                .reviewerLoad(reviewerLoad)
                .build();
    }
    
    private List<ReviewerLoadDTO> getReviewerLoadEfficiently() {
        // Implement efficient reviewer load calculation
        // Instead of loading all assignments, use aggregate queries
        return List.of(); // Placeholder - implement based on actual ReviewerLoadDTO structure
    }
}
