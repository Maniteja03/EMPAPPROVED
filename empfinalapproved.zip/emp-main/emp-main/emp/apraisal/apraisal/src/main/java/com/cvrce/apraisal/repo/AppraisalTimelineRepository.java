package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalTimeline;
import com.cvrce.apraisal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AppraisalTimelineRepository extends JpaRepository<AppraisalTimeline, UUID> {
    
    // Find active timeline for academic year
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.academicYear = :academicYear AND at.isActive = true")
    Optional<AppraisalTimeline> findByAcademicYearAndActive(@Param("academicYear") String academicYear);
    
    // Find all timelines for academic year (including inactive)
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.academicYear = :academicYear ORDER BY at.createdAt DESC")
    List<AppraisalTimeline> findByAcademicYearOrderByCreatedAtDesc(@Param("academicYear") String academicYear);
    
    // Find timelines created by specific chairperson
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.createdByChairperson = :chairperson ORDER BY at.createdAt DESC")
    List<AppraisalTimeline> findByCreatedByChairpersonOrderByCreatedAtDesc(@Param("chairperson") User chairperson);
    
    // Find all active timelines
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true ORDER BY at.academicYear DESC")
    List<AppraisalTimeline> findAllActiveOrderByAcademicYearDesc();
    
    // Find timelines where current date is within specific phase
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate >= at.staffUploadStartDate AND :currentDate <= at.staffUploadDeadline")
    List<AppraisalTimeline> findTimelinesInStaffUploadPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.staffUploadDeadline AND :currentDate <= at.hodDcmAssignmentDeadline")
    List<AppraisalTimeline> findTimelinesInHodDcmAssignmentPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.hodDcmAssignmentDeadline AND :currentDate <= at.dcmReviewDeadline")
    List<AppraisalTimeline> findTimelinesInDcmReviewPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.dcmReviewDeadline AND :currentDate <= at.hodReviewDeadline")
    List<AppraisalTimeline> findTimelinesInHodReviewPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.hodReviewDeadline AND :currentDate <= at.committeeReviewDeadline")
    List<AppraisalTimeline> findTimelinesInCommitteeReviewPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.committeeReviewDeadline AND :currentDate <= at.chairpersonReviewDeadline")
    List<AppraisalTimeline> findTimelinesInChairpersonReviewPhase(@Param("currentDate") LocalDate currentDate);
    
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate > at.chairpersonReviewDeadline AND :currentDate <= at.principalBulkSubmissionDate")
    List<AppraisalTimeline> findTimelinesInPrincipalReviewPhase(@Param("currentDate") LocalDate currentDate);
    
    // Find overdue timelines
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND :currentDate > at.principalBulkSubmissionDate")
    List<AppraisalTimeline> findOverdueTimelines(@Param("currentDate") LocalDate currentDate);
    
    // Find timelines with upcoming deadlines (for reminder notifications)
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND at.sendDeadlineReminders = true AND " +
           "((:currentDate = at.staffUploadDeadline - :reminderDays) OR " +
           "(:currentDate = at.hodDcmAssignmentDeadline - :reminderDays) OR " +
           "(:currentDate = at.dcmReviewDeadline - :reminderDays) OR " +
           "(:currentDate = at.hodReviewDeadline - :reminderDays) OR " +
           "(:currentDate = at.committeeReviewDeadline - :reminderDays) OR " +
           "(:currentDate = at.chairpersonReviewDeadline - :reminderDays) OR " +
           "(:currentDate = at.principalBulkSubmissionDate - :reminderDays))")
    List<AppraisalTimeline> findTimelinesNeedingDeadlineReminders(@Param("currentDate") LocalDate currentDate, 
                                                                 @Param("reminderDays") int reminderDays);
    
    // Deactivate all timelines for academic year (when creating new one)
    @Modifying
    @Query("UPDATE AppraisalTimeline at SET at.isActive = false WHERE at.academicYear = :academicYear AND at.isActive = true")
    int deactivateAllTimelinesForYear(@Param("academicYear") String academicYear);
    
    // Finalize timeline
    @Modifying
    @Query("UPDATE AppraisalTimeline at SET at.finalizedAt = CURRENT_TIMESTAMP WHERE at.id = :timelineId")
    int finalizeTimeline(@Param("timelineId") UUID timelineId);
    
    // Update current phase
    @Modifying
    @Query("UPDATE AppraisalTimeline at SET at.currentPhase = :phase WHERE at.id = :timelineId")
    int updateCurrentPhase(@Param("timelineId") UUID timelineId, @Param("phase") String phase);
    
    // Check if academic year has active timeline
    @Query("SELECT COUNT(at) > 0 FROM AppraisalTimeline at WHERE at.academicYear = :academicYear AND at.isActive = true")
    boolean existsByAcademicYearAndActive(@Param("academicYear") String academicYear);
    
    // Get timeline statistics
    @Query("SELECT COUNT(at) FROM AppraisalTimeline at WHERE at.isActive = true")
    long countActiveTimelines();
    
    @Query("SELECT COUNT(at) FROM AppraisalTimeline at WHERE at.createdByChairperson = :chairperson")
    long countByCreatedByChairperson(@Param("chairperson") User chairperson);
    
    @Query("SELECT DISTINCT at.academicYear FROM AppraisalTimeline at WHERE at.isActive = true ORDER BY at.academicYear DESC")
    List<String> findDistinctActiveAcademicYears();
    
    // Find timeline by current date (which timeline is currently active)
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND " +
           ":currentDate >= at.staffUploadStartDate AND :currentDate <= at.principalBulkSubmissionDate")
    Optional<AppraisalTimeline> findCurrentActiveTimeline(@Param("currentDate") LocalDate currentDate);
    
    // Find timelines that need phase updates
    @Query("SELECT at FROM AppraisalTimeline at WHERE at.isActive = true AND at.currentPhase != " +
           "CASE " +
           "WHEN :currentDate < at.staffUploadStartDate THEN 'TIMELINE_SET' " +
           "WHEN :currentDate <= at.staffUploadDeadline THEN 'STAFF_UPLOAD' " +
           "WHEN :currentDate <= at.hodDcmAssignmentDeadline THEN 'HOD_DCM_ASSIGNMENT' " +
           "WHEN :currentDate <= at.dcmReviewDeadline THEN 'DCM_REVIEW' " +
           "WHEN :currentDate <= at.hodReviewDeadline THEN 'HOD_REVIEW' " +
           "WHEN :currentDate <= at.committeeReviewDeadline THEN 'COMMITTEE_REVIEW' " +
           "WHEN :currentDate <= at.chairpersonReviewDeadline THEN 'CHAIRPERSON_REVIEW' " +
           "WHEN :currentDate <= at.principalBulkSubmissionDate THEN 'PRINCIPAL_REVIEW' " +
           "ELSE 'COMPLETED' END")
    List<AppraisalTimeline> findTimelinesNeedingPhaseUpdate(@Param("currentDate") LocalDate currentDate);
} 