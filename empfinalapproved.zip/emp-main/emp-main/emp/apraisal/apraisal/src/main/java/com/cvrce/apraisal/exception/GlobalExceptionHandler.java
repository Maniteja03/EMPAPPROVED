package com.cvrce.apraisal.exception;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private Map<String, Object> buildResponse(HttpStatus status, String message, HttpServletRequest request) {
        return buildResponse(status, message, request, null, null);
    }

    private Map<String, Object> buildResponse(HttpStatus status, String message, HttpServletRequest request, 
                                            String errorCode, Map<String, Object> details) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("message", message);
        body.put("path", request.getRequestURI());
        
        if (errorCode != null) {
            body.put("errorCode", errorCode);
        }
        if (details != null && !details.isEmpty()) {
            body.put("details", details);
        }
        
        return body;
    }

    // ==================== BUSINESS EXCEPTIONS ====================
    
    @ExceptionHandler(AppraisalBusinessException.class)
    public ResponseEntity<Map<String, Object>> handleBusinessException(AppraisalBusinessException ex, HttpServletRequest req) {
        log.warn("Business exception [{}]: {}", ex.getErrorCode(), ex.getMessage());
        
        Map<String, Object> details = new HashMap<>();
        if (ex.getArgs() != null && ex.getArgs().length > 0) {
            details.put("arguments", Arrays.asList(ex.getArgs()));
        }
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), req, ex.getErrorCode(), details), 
            HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(FormSubmissionException.class)
    public ResponseEntity<Map<String, Object>> handleFormSubmission(FormSubmissionException ex, HttpServletRequest req) {
        log.warn("Form submission error: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.UNPROCESSABLE_ENTITY
        );
    }

    @ExceptionHandler(ReviewWorkflowException.class)
    public ResponseEntity<Map<String, Object>> handleReviewWorkflow(ReviewWorkflowException ex, HttpServletRequest req) {
        log.warn("Review workflow error: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.CONFLICT, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.CONFLICT
        );
    }

    @ExceptionHandler(DeadlineViolationException.class)
    public ResponseEntity<Map<String, Object>> handleDeadlineViolation(DeadlineViolationException ex, HttpServletRequest req) {
        log.warn("Deadline violation: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.PRECONDITION_FAILED, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.PRECONDITION_FAILED
        );
    }

    @ExceptionHandler(UnauthorizedAccessException.class)
    public ResponseEntity<Map<String, Object>> handleUnauthorizedAccess(UnauthorizedAccessException ex, HttpServletRequest req) {
        log.warn("Unauthorized access attempt: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.FORBIDDEN, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.FORBIDDEN
        );
    }

    @ExceptionHandler(InvalidAppraisalStateException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidState(InvalidAppraisalStateException ex, HttpServletRequest req) {
        log.warn("Invalid appraisal state: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.CONFLICT, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.CONFLICT
        );
    }

    @ExceptionHandler(DuplicateReviewException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateReview(DuplicateReviewException ex, HttpServletRequest req) {
        log.warn("Duplicate review attempt: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.CONFLICT, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.CONFLICT
        );
    }

    @ExceptionHandler(InsufficientPermissionsException.class)
    public ResponseEntity<Map<String, Object>> handleInsufficientPermissions(InsufficientPermissionsException ex, HttpServletRequest req) {
        log.warn("Insufficient permissions: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.FORBIDDEN, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.FORBIDDEN
        );
    }

    // ==================== SYSTEM EXCEPTIONS ====================
    
    @ExceptionHandler(SystemException.class)
    public ResponseEntity<Map<String, Object>> handleSystemException(SystemException ex, HttpServletRequest req) {
        log.error("System exception in [{}]: {}", ex.getSystemComponent(), ex.getMessage(), ex);
        
        Map<String, Object> details = new HashMap<>();
        details.put("component", ex.getSystemComponent());
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, "System error occurred", req, ex.getErrorCode(), details), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /*
    @ExceptionHandler(DatabaseException.class)
    public ResponseEntity<Map<String, Object>> handleDatabaseError(DatabaseException ex, HttpServletRequest req) {
        log.error("Database error: {}", ex.getMessage(), ex);
        return new ResponseEntity<>(
            buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Database operation failed", req, ex.getErrorCode(), null), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    @ExceptionHandler(ExternalServiceException.class)
    public ResponseEntity<Map<String, Object>> handleExternalService(ExternalServiceException ex, HttpServletRequest req) {
        log.error("External service error [{}]: {}", ex.getSystemComponent(), ex.getMessage(), ex);
        
        Map<String, Object> details = new HashMap<>();
        details.put("service", ex.getSystemComponent());
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.SERVICE_UNAVAILABLE, "External service unavailable", req, ex.getErrorCode(), details), 
            HttpStatus.SERVICE_UNAVAILABLE
        );
    }

    @ExceptionHandler(NotificationException.class)
    public ResponseEntity<Map<String, Object>> handleNotificationError(NotificationException ex, HttpServletRequest req) {
        log.error("Notification error: {}", ex.getMessage(), ex);
        return new ResponseEntity<>(
            buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Notification service error", req, ex.getErrorCode(), null), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    @ExceptionHandler(PdfGenerationException.class)
    public ResponseEntity<Map<String, Object>> handlePdfGeneration(PdfGenerationException ex, HttpServletRequest req) {
        log.error("PDF generation error: {}", ex.getMessage(), ex);
        return new ResponseEntity<>(
            buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, "PDF generation failed", req, ex.getErrorCode(), null), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
    */

    // ==================== VALIDATION EXCEPTIONS ====================
    
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Map<String, Object>> handleValidationException(ValidationException ex, HttpServletRequest req) {
        log.warn("Validation error: {}", ex.getMessage());
        
        Map<String, Object> details = new HashMap<>();
        if (ex.getField() != null) {
            details.put("field", ex.getField());
            details.put("rejectedValue", ex.getRejectedValue());
        }
        if (ex.getFieldErrors() != null) {
            details.put("fieldErrors", ex.getFieldErrors());
        }
        if (ex.getGlobalErrors() != null) {
            details.put("globalErrors", ex.getGlobalErrors());
        }
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), req, "VALIDATION_ERROR", details), 
            HttpStatus.BAD_REQUEST
        );
    }

    /*
    @ExceptionHandler(InvalidFileFormatException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidFileFormat(InvalidFileFormatException ex, HttpServletRequest req) {
        log.warn("Invalid file format: {}", ex.getMessage());
        
        Map<String, Object> details = new HashMap<>();
        details.put("field", ex.getField());
        details.put("rejectedValue", ex.getRejectedValue());
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), req, "INVALID_FILE_FORMAT", details), 
            HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(FileSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> handleFileSizeExceeded(FileSizeExceededException ex, HttpServletRequest req) {
        log.warn("File size exceeded: {}", ex.getMessage());
        
        Map<String, Object> details = new HashMap<>();
        details.put("field", ex.getField());
        details.put("rejectedValue", ex.getRejectedValue());
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.PAYLOAD_TOO_LARGE, ex.getMessage(), req, "FILE_SIZE_EXCEEDED", details), 
            HttpStatus.PAYLOAD_TOO_LARGE
        );
    }
    */

    @ExceptionHandler(FileProcessingException.class)
    public ResponseEntity<Map<String, Object>> handleFileProcessing(FileProcessingException ex, HttpServletRequest req) {
        log.error("File processing error: {}", ex.getMessage(), ex);
        return new ResponseEntity<>(
            buildResponse(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage(), req, ex.getErrorCode(), null), 
            HttpStatus.UNPROCESSABLE_ENTITY
        );
    }

    // ==================== SECURITY EXCEPTIONS ====================
    
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<Map<String, Object>> handleAuthentication(AuthenticationException ex, HttpServletRequest req) {
        log.warn("Authentication failed: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.UNAUTHORIZED, "Authentication failed", req, "AUTHENTICATION_ERROR", null), 
            HttpStatus.UNAUTHORIZED
        );
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDenied(AccessDeniedException ex, HttpServletRequest req) {
        log.warn("Access denied: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.FORBIDDEN, "Access denied", req, "ACCESS_DENIED", null), 
            HttpStatus.FORBIDDEN
        );
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<Map<String, Object>> handleBadCredentials(BadCredentialsException ex, HttpServletRequest req) {
        log.warn("Bad credentials: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.UNAUTHORIZED, "Invalid credentials", req, "BAD_CREDENTIALS", null), 
            HttpStatus.UNAUTHORIZED
        );
    }

    // ==================== SPRING FRAMEWORK EXCEPTIONS ====================
    
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> handleMaxUploadSize(MaxUploadSizeExceededException ex, HttpServletRequest req) {
        log.warn("Max upload size exceeded: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.PAYLOAD_TOO_LARGE, "File size exceeds maximum allowed", req, "MAX_UPLOAD_SIZE_EXCEEDED", null), 
            HttpStatus.PAYLOAD_TOO_LARGE
        );
    }

    // ==================== EXISTING EXCEPTIONS (ENHANCED) ====================

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(ResourceNotFoundException ex, HttpServletRequest req) {
        log.warn("Resource not found: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.NOT_FOUND, ex.getMessage(), req, "RESOURCE_NOT_FOUND", null), 
            HttpStatus.NOT_FOUND
        );
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalState(IllegalStateException ex, HttpServletRequest req) {
        log.warn("Illegal state: {}", ex.getMessage());
        return new ResponseEntity<>(
            buildResponse(HttpStatus.CONFLICT, ex.getMessage(), req, "ILLEGAL_STATE", null), 
            HttpStatus.CONFLICT
        );
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest req) {
        Map<String, String> fieldErrors = ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(
                    err -> err.getField(),
                    err -> err.getDefaultMessage(),
                    (existing, replacement) -> existing
                ));

        List<String> globalErrors = ex.getBindingResult().getGlobalErrors().stream()
                .map(err -> err.getDefaultMessage())
                .collect(Collectors.toList());

        Map<String, Object> details = new HashMap<>();
        if (!fieldErrors.isEmpty()) {
            details.put("fieldErrors", fieldErrors);
        }
        if (!globalErrors.isEmpty()) {
            details.put("globalErrors", globalErrors);
        }

        String errorMsg = fieldErrors.values().stream().findFirst().orElse("Invalid input");
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.BAD_REQUEST, errorMsg, req, "VALIDATION_ERROR", details), 
            HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, Object>> handleTypeMismatch(MethodArgumentTypeMismatchException ex, HttpServletRequest req) {
        String msg = "Invalid value for parameter: " + ex.getName();
        
        Map<String, Object> details = new HashMap<>();
        details.put("parameter", ex.getName());
        details.put("rejectedValue", ex.getValue());
        details.put("expectedType", ex.getRequiredType() != null ? ex.getRequiredType().getSimpleName() : "unknown");
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.BAD_REQUEST, msg, req, "TYPE_MISMATCH", details), 
            HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleAll(Exception ex, HttpServletRequest req) {
        log.error("Unexpected error: {}", ex.getMessage(), ex);
        
        // In production, don't expose internal error details
        String message = "An unexpected error occurred";
        Map<String, Object> details = new HashMap<>();
        details.put("type", ex.getClass().getSimpleName());
        
        return new ResponseEntity<>(
            buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, message, req, "INTERNAL_ERROR", details), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}
