package com.cvrce.apraisal.repo;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.StudentTrainingScoring;
import com.cvrce.apraisal.entity.StudentTrainingType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StudentTrainingScoringRepository extends JpaRepository<StudentTrainingScoring, UUID> {
    
    List<StudentTrainingScoring> findByAppraisalScoring(AppraisalScoring appraisalScoring);
    
    @Query("SELECT sts FROM StudentTrainingScoring sts WHERE sts.appraisalScoring.id = :scoringId ORDER BY sts.trainingType, sts.academicYear")
    List<StudentTrainingScoring> findByAppraisalScoringIdOrderByType(@Param("scoringId") UUID scoringId);
    
    @Query("SELECT sts FROM StudentTrainingScoring sts WHERE sts.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<StudentTrainingScoring> findByAcademicYear(@Param("academicYear") String academicYear);
    
    @Query("SELECT sts FROM StudentTrainingScoring sts WHERE sts.trainingType = :trainingType")
    List<StudentTrainingScoring> findByTrainingType(@Param("trainingType") StudentTrainingType trainingType);
    
    @Query("SELECT SUM(sts.studentsAllotted), SUM(sts.studentsCertified) FROM StudentTrainingScoring sts WHERE sts.trainingType = 'STUDENT_CERTIFICATION' AND sts.appraisalScoring.appraisalForm.academicYear = :academicYear")
    List<Object[]> getCertificationStatisticsByAcademicYear(@Param("academicYear") String academicYear);
} 