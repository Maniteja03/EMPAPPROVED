package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.dcm.DCMAssignmentDTO;
import com.cvrce.apraisal.dto.dcm.DCMSelectionDTO;
import com.cvrce.apraisal.dto.dcm.DCMValidationResult;
import com.cvrce.apraisal.dto.dcm.DCMWorkloadStats;
import com.cvrce.apraisal.entity.DCMAssignment;
import com.cvrce.apraisal.entity.Department;
import com.cvrce.apraisal.entity.User;
import com.cvrce.apraisal.enums.AppraisalStatus;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.AppraisalFormRepository;
import com.cvrce.apraisal.repo.DCMAssignmentRepository;
import com.cvrce.apraisal.repo.ReviewRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.DCMManagementService;
import com.cvrce.apraisal.service.DeadlineEnforcementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import com.cvrce.apraisal.enums.ReviewLevel;

@Service
@RequiredArgsConstructor
@Slf4j
public class DCMManagementServiceImpl implements DCMManagementService {
    
    private final DCMAssignmentRepository dcmAssignmentRepository;
    private final UserRepository userRepository;
    private final AppraisalFormRepository appraisalFormRepository;
    private final ReviewRepository reviewRepository;
    private final DeadlineEnforcementService deadlineEnforcementService;
    
    @Override
    public List<DCMSelectionDTO> getEligibleStaffForDCM(String hodEmail, String academicYear) {
        // Get HOD and their department
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        Department department = hod.getDepartment();
        
        log.info("Getting eligible staff for DCM assignment in {} department by HOD {}", 
                department.getName(), hod.getFullName());
        
        // Get all staff in the department (exclude HODs, Principals, etc.)
        List<User> departmentStaff = userRepository.findByDepartmentId(department.getId())
                .stream()
                .filter(user -> !user.getId().equals(hod.getId())) // Exclude HOD themselves
                .filter(user -> hasOnlyStaffRole(user)) // Only regular staff or staff with DCM role
                .collect(Collectors.toList());
        
        // Get current DCM assignments
        List<DCMAssignment> currentDCMs = dcmAssignmentRepository
                .findActiveDCMsByDepartmentAndYear(department, academicYear);
        
        List<UUID> currentDCMIds = currentDCMs.stream()
                .map(dcm -> dcm.getStaffMember().getId())
                .collect(Collectors.toList());
        
        // Convert to DTOs with eligibility information
        return departmentStaff.stream()
                .map(staff -> createDCMSelectionDTO(staff, currentDCMIds.contains(staff.getId()), academicYear))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<DCMAssignmentDTO> getCurrentDCMAssignments(String hodEmail, String academicYear) {
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        List<DCMAssignment> assignments = dcmAssignmentRepository
                .findAssignmentsByHODAndYear(hod, academicYear);
        
        return assignments.stream()
                .map(this::createDCMAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public List<DCMAssignmentDTO> assignDCMs(String hodEmail, List<UUID> staffIds, String academicYear) {
        // TIMELINE ENFORCEMENT: Check if HOD DCM assignment is currently allowed
        if (!deadlineEnforcementService.isHodDcmAssignmentAllowed(academicYear)) {
            String message = deadlineEnforcementService.getDeadlineEnforcementMessage(academicYear, "HOD_DCM_ASSIGNMENT");
            throw new IllegalStateException("DCM assignment not allowed at this time: " + message);
        }
        
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        Department department = hod.getDepartment();
        
        log.info("HOD {} assigning {} staff members as DCMs for {} department in {} (Timeline: {})", 
                hod.getFullName(), staffIds.size(), department.getName(), academicYear,
                deadlineEnforcementService.getCurrentPhase(academicYear));
        
        // Validate assignments
        DCMValidationResult validation = validateDCMAssignments(hodEmail, staffIds, academicYear);
        if (!validation.isValid()) {
            throw new IllegalArgumentException("DCM assignment validation failed: " + 
                    String.join(", ", validation.getErrorMessages()));
        }
        
        List<DCMAssignment> newAssignments = new ArrayList<>();
        
        for (UUID staffId : staffIds) {
            User staffMember = userRepository.findById(staffId)
                    .orElseThrow(() -> new ResourceNotFoundException("Staff member not found: " + staffId));
            
            // Check if already assigned as DCM
            if (!dcmAssignmentRepository.canStaffBeAssignedAsDCM(staffMember, academicYear)) {
                log.warn("Staff member {} is already assigned as DCM for {}", staffMember.getFullName(), academicYear);
                continue;
            }
            
            DCMAssignment assignment = DCMAssignment.builder()
                    .staffMember(staffMember)
                    .assignedByHod(hod)
                    .department(department)
                    .academicYear(academicYear)
                    .isActive(true)
                    .assignedAt(LocalDateTime.now())
                    .build();
            
            DCMAssignment saved = dcmAssignmentRepository.save(assignment);
            newAssignments.add(saved);
            
            log.info("Assigned {} as DCM for {} department in {} by HOD {}", 
                    staffMember.getFullName(), department.getName(), academicYear, hod.getFullName());
        }
        
        return newAssignments.stream()
                .map(this::createDCMAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public boolean removeDCMAssignment(String hodEmail, UUID dcmAssignmentId) {
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        DCMAssignment assignment = dcmAssignmentRepository.findById(dcmAssignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("DCM assignment not found: " + dcmAssignmentId));
        
        // Verify HOD owns this assignment
        if (!assignment.getAssignedByHod().getId().equals(hod.getId())) {
            throw new SecurityException("HOD can only remove their own DCM assignments");
        }
        
        // Deactivate the assignment
        assignment.deactivate();
        dcmAssignmentRepository.save(assignment);
        
        log.info("HOD {} removed DCM assignment for {} in {} department", 
                hod.getFullName(), assignment.getStaffMember().getFullName(), 
                assignment.getDepartment().getName());
        
        return true;
    }
    
    @Override
    @Transactional
    public List<DCMAssignmentDTO> replaceDCMAssignments(String hodEmail, List<UUID> staffIds, String academicYear) {
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        Department department = hod.getDepartment();
        
        log.info("HOD {} replacing all DCM assignments for {} department in {}", 
                hod.getFullName(), department.getName(), academicYear);
        
        // Deactivate all current DCM assignments for the department
        dcmAssignmentRepository.deactivateAllDCMsForDepartmentAndYear(department, academicYear);
        
        // Create new assignments
        return assignDCMs(hodEmail, staffIds, academicYear);
    }
    
    @Override
    public boolean isStaffMemberDCM(User staffMember, String academicYear) {
        return dcmAssignmentRepository.findActiveDCMAssignmentByStaffAndYear(staffMember, academicYear)
                .isPresent();
    }
    
    @Override
    public List<DCMAssignmentDTO> getDCMAssignmentHistory(UUID staffId) {
        User staff = userRepository.findById(staffId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff member not found: " + staffId));
        
        List<DCMAssignment> history = dcmAssignmentRepository.findDCMAssignmentHistory(staff);
        
        return history.stream()
                .map(this::createDCMAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<DCMAssignmentDTO> getAllDCMsForYear(String academicYear) {
        List<DCMAssignment> assignments = dcmAssignmentRepository.findAllActiveDCMsForYear(academicYear);
        
        return assignments.stream()
                .map(this::createDCMAssignmentDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public DCMValidationResult validateDCMAssignments(String hodEmail, List<UUID> staffIds, String academicYear) {
        DCMValidationResult result = new DCMValidationResult(true);
        
        try {
            User hod = userRepository.findByEmail(hodEmail)
                    .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
            
            Department department = hod.getDepartment();
            
            // Check minimum and maximum DCM limits
            if (staffIds.isEmpty()) {
                result.setValid(false);
                result.addError("At least one DCM must be assigned");
                return result;
            }
            
            if (staffIds.size() > 5) { // Reasonable maximum
                result.addWarning("Assigning " + staffIds.size() + " DCMs might create management overhead");
            }
            
            // Validate each staff member
            for (UUID staffId : staffIds) {
                User staff = userRepository.findById(staffId)
                        .orElse(null);
                
                if (staff == null) {
                    result.setValid(false);
                    result.addError("Staff member not found: " + staffId);
                    continue;
                }
                
                // Check if staff belongs to HOD's department
                if (!staff.getDepartment().getId().equals(department.getId())) {
                    result.setValid(false);
                    result.addError(staff.getFullName() + " does not belong to your department");
                }
                
                // Check if staff has appropriate role
                if (!hasOnlyStaffRole(staff)) {
                    result.addWarning(staff.getFullName() + " has additional roles beyond STAFF");
                }
                
                // Check if already a DCM
                if (!dcmAssignmentRepository.canStaffBeAssignedAsDCM(staff, academicYear)) {
                    result.addWarning(staff.getFullName() + " is already assigned as DCM for " + academicYear);
                }
            }
            
            // Check for workload balance
            long totalStaff = userRepository.countByDepartmentName(department.getName());
            if (staffIds.size() * 10 < totalStaff) { // Each DCM should handle ~10 forms max
                result.addWarning("Consider assigning more DCMs for better workload distribution");
            }
            
        } catch (Exception e) {
            result.setValid(false);
            result.addError("Validation error: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public DCMWorkloadStats getDCMWorkloadStats(String hodEmail, String academicYear) {
        User hod = userRepository.findByEmail(hodEmail)
                .orElseThrow(() -> new ResourceNotFoundException("HOD not found: " + hodEmail));
        
        Department department = hod.getDepartment();
        
        DCMWorkloadStats stats = new DCMWorkloadStats();
        stats.setDepartmentName(department.getName());
        stats.setAcademicYear(academicYear);
        
        // Get DCM count
        long dcmCount = dcmAssignmentRepository.countActiveDCMsByDepartmentAndYear(department, academicYear);
        stats.setTotalDCMs((int) dcmCount);
        stats.setActiveDCMs((int) dcmCount);
        
        // Get forms counts (simplified approach)
        long formsToReview = appraisalFormRepository.countByStatusAndDepartment(
                AppraisalStatus.DEPARTMENT_REVIEW, department.getName());
        stats.setTotalFormsAssigned((int) formsToReview);
        stats.setFormsPending((int) formsToReview);
        stats.setFormsCompleted(0); // Simplified for now
        
        // Calculate rates
        stats.setCompletionRate(0.0); // Will be calculated properly later
        if (dcmCount > 0) {
            stats.setAverageFormsPerDCM((double) formsToReview / dcmCount);
        } else {
            stats.setAverageFormsPerDCM(0.0);
        }
        
        // Initialize empty details list
        stats.setDcmDetails(new ArrayList<>());
        
        return stats;
    }
    
    // Helper methods
    
    private boolean hasOnlyStaffRole(User user) {
        return user.getRoles().stream()
                .allMatch(role -> "STAFF".equals(role.getName()) || "DCM".equals(role.getName()));
    }
    
    private DCMSelectionDTO createDCMSelectionDTO(User staff, boolean isCurrentlyDCM, String academicYear) {
        // Check if staff has submitted their own appraisal
        boolean hasSubmittedOwn = appraisalFormRepository.existsByUserAndAcademicYear(staff, academicYear);
        
        // Get previous DCM assignment count
        int previousAssignments = dcmAssignmentRepository.findDCMAssignmentHistory(staff).size();
        
        return DCMSelectionDTO.builder()
                .staffId(staff.getId())
                .fullName(staff.getFullName())
                .email(staff.getEmail())
                .employeeId(staff.getEmployeeId())
                .departmentName(staff.getDepartment().getName())
                .isCurrentlyDCM(isCurrentlyDCM)
                .isEligible(!isCurrentlyDCM && hasOnlyStaffRole(staff))
                .ineligibilityReason(isCurrentlyDCM ? "Already assigned as DCM" : null)
                .yearsOfExperience(calculateExperience(staff))
                .designation("Staff") // Default since User entity doesn't have designation field
                .hasSubmittedOwnAppraisal(hasSubmittedOwn)
                .previousDCMAssignments(previousAssignments)
                .build();
    }
    
    private DCMAssignmentDTO createDCMAssignmentDTO(DCMAssignment assignment) {
        // Get review statistics
        long formsReviewed = reviewRepository.countByReviewerAndLevel(
                assignment.getStaffMember(), com.cvrce.apraisal.enums.ReviewLevel.DEPARTMENT_REVIEW);
        
        return DCMAssignmentDTO.builder()
                .assignmentId(assignment.getId())
                .staffMemberId(assignment.getStaffMember().getId())
                .staffFullName(assignment.getStaffMember().getFullName())
                .staffEmail(assignment.getStaffMember().getEmail())
                .staffEmployeeId(assignment.getStaffMember().getEmployeeId())
                .departmentName(assignment.getDepartment().getName())
                .academicYear(assignment.getAcademicYear())
                .isActive(assignment.isCurrentlyActive())
                .assignedAt(assignment.getAssignedAt())
                .deactivatedAt(assignment.getDeactivatedAt())
                .assignedByHodId(assignment.getAssignedByHod().getId())
                .assignedByHodName(assignment.getAssignedByHod().getFullName())
                .formsReviewed((int) formsReviewed)
                .status(assignment.isCurrentlyActive() ? "ACTIVE" : "INACTIVE")
                .currentWorkload(0) // Would need to implement workload tracking
                .build();
    }
    
    private int calculateExperience(User staff) {
        // Placeholder - would need to implement based on joining date or other criteria
        return 5; // Default to 5 years
    }
} 