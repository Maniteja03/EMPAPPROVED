package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.partb.AwardDTO;
import com.cvrce.apraisal.service.PartB_AwardService;
import com.cvrce.apraisal.service.AppraisalFormService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/partb/awards")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
public class PartB_AwardController {

    private final PartB_AwardService awardService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping
    public ResponseEntity<AwardDTO> add(@RequestBody AwardDTO dto) {
        // SECURITY FIX: Validate ownership before allowing data modification
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized award creation attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Adding award to form {} by authorized user {}", dto.getAppraisalFormId(), currentUserEmail);
        return new ResponseEntity<>(awardService.addAward(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<AwardDTO>> getByForm(@PathVariable UUID formId) {
        // SECURITY FIX: Validate access before allowing data retrieval
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized award access attempt on form {} by user {}", 
                    formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Fetching awards for form {} by authorized user {}", formId, currentUserEmail);
        return ResponseEntity.ok(awardService.getAwardsByFormId(formId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AwardDTO> update(@PathVariable UUID id, @RequestBody AwardDTO dto) {
        // SECURITY FIX: Validate ownership before allowing updates
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized award update attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Updating award {} by authorized user {}", id, currentUserEmail);
        return ResponseEntity.ok(awardService.updateAward(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        // SECURITY FIX: Validate ownership before allowing deletion
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            awardService.deleteAward(id, currentUserEmail);
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            log.warn("Unauthorized award deletion attempt for ID {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}
