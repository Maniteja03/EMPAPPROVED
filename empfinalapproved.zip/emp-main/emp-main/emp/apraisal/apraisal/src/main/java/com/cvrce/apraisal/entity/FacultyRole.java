package com.cvrce.apraisal.entity;

public enum FacultyRole {
    CONFERENCE_CHAIR("Conference Chair"),
    CONVENER("Convener"),
    COORDINATOR("Coordinator"),
    GUEST_EDITOR("Guest Editor of Conference Proceedings"),
    CO_CHAIR("Co-chair"),
    CO_CONVENER("Co-convener"),
    CO_COORDINATOR("Co-coordinator"),
    ORGANIZING_COMMITTEE_MEMBER("Organizing Committee Member"),
    ADVISORY_MEMBER("Advisory Member"),
    TECHNICAL_COMMITTEE_MEMBER("Technical Committee Member");
    
    private final String displayName;
    
    FacultyRole(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() { return displayName; }
} 