package com.cvrce.apraisal.dto.designation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DesignationHistoryDTO {
    
    private UUID id;
    private String designationType;
    private String designationDisplayName;
    private LocalDate effectiveFromDate;
    private LocalDate effectiveToDate;
    private String academicYear;
    private Boolean isCurrentDesignation;
    private String promotionOrderNumber;
    private LocalDate promotionDate;
    private String remarks;
    private LocalDateTime createdAt;
    
    // Calculated duration
    private Integer durationInYears;
    private Integer durationInMonths;
    private String durationDescription;
} 