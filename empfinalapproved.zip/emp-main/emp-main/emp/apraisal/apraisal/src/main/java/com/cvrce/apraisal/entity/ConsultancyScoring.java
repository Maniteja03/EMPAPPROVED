package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "consultancy_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ConsultancyScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Consultancy Details
    @Column(name = "consultancy_details", nullable = false, columnDefinition = "TEXT")
    private String consultancyDetails;
    
    @Column(name = "sanctioned_date")
    private LocalDate sanctionedDate;
    
    @Column(name = "sanctioned_year", length = 10)
    private String sanctionedYear;
    
    @Column(name = "consultancy_amount_lakhs", precision = 10, scale = 2, nullable = false)
    private BigDecimal consultancyAmountLakhs;
    
    // Principal Investigator and Co-investigators
    @Column(name = "principal_investigator_names", columnDefinition = "TEXT")
    private String principalInvestigatorNames;
    
    @Column(name = "co_investigator_names", columnDefinition = "TEXT")
    private String coInvestigatorNames;
    
    // Scoring
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // Verification
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points based on consultancy amount
    public void calculatePoints() {
        if (consultancyAmountLakhs != null) {
            this.autoCalculatedPoints = calculatePointsBasedOnAmount(consultancyAmountLakhs);
            
            if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
                this.pointsClaimed = autoCalculatedPoints;
            }
        }
    }
    
    private BigDecimal calculatePointsBasedOnAmount(BigDecimal amountLakhs) {
        // Points based on consultancy amount from Annexure V
        if (amountLakhs.compareTo(new BigDecimal("5")) > 0) {
            return new BigDecimal("5"); // Above 5 Lakhs = 5 points
        } else if (amountLakhs.compareTo(new BigDecimal("1")) >= 0) {
            return new BigDecimal("3"); // 1-5 Lakhs = 3 points
        } else {
            return new BigDecimal("1"); // Below 1 Lakh = 1 point
        }
    }
    
    // Validation
    public boolean isValidForScoring() {
        return consultancyDetails != null && !consultancyDetails.trim().isEmpty() &&
               consultancyAmountLakhs != null && consultancyAmountLakhs.compareTo(BigDecimal.ZERO) > 0;
    }
} 