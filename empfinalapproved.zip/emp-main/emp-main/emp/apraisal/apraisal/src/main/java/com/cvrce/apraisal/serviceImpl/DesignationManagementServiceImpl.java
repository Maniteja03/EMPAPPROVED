package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.designation.DesignationDTO;
import com.cvrce.apraisal.dto.designation.DesignationHistoryDTO;
import com.cvrce.apraisal.dto.designation.PromotionRequestDTO;
import com.cvrce.apraisal.entity.*;
import com.cvrce.apraisal.exception.ResourceNotFoundException;
import com.cvrce.apraisal.repo.StaffDesignationRepository;
import com.cvrce.apraisal.repo.UserRepository;
import com.cvrce.apraisal.service.DesignationManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.Period;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class DesignationManagementServiceImpl implements DesignationManagementService {
    
    private final StaffDesignationRepository staffDesignationRepository;
    private final UserRepository userRepository;
    
    @Override
    public DesignationDTO getCurrentDesignation(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        StaffDesignation currentDesignation = staffDesignationRepository.findCurrentDesignationByUser(user)
                .orElse(null);
        
        return mapToDTO(currentDesignation, user);
    }
    
    @Override
    public List<DesignationHistoryDTO> getDesignationHistory(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<StaffDesignation> history = staffDesignationRepository.findAllDesignationsByUser(user);
        
        return history.stream()
                .map(this::mapToHistoryDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public Page<DesignationDTO> getAllCurrentDesignations(String searchTerm, Pageable pageable) {
        Page<StaffDesignation> designations;
        
        if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            designations = staffDesignationRepository.findCurrentDesignationsWithSearch(searchTerm, pageable);
        } else {
            designations = staffDesignationRepository.findAll(pageable);
        }
        
        return designations.map(designation -> mapToDTO(designation, designation.getUser()));
    }
    
    @Override
    public List<DesignationDTO> getDesignationsByDepartment(UUID departmentId) {
        List<StaffDesignation> designations = staffDesignationRepository.findCurrentDesignationsByDepartment(departmentId);
        
        return designations.stream()
                .map(designation -> mapToDTO(designation, designation.getUser()))
                .collect(Collectors.toList());
    }
    
    @Override
    public DesignationDTO promoteUser(PromotionRequestDTO promotionRequest) {
        User user = userRepository.findById(promotionRequest.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // End current designation
        staffDesignationRepository.endCurrentDesignation(user, promotionRequest.getEffectiveFromDate().minusDays(1));
        
        // Create new designation
        StaffDesignation newDesignation = StaffDesignation.builder()
                .user(user)
                .designationType(DesignationType.valueOf(promotionRequest.getNewDesignationType()))
                .effectiveFromDate(promotionRequest.getEffectiveFromDate())
                .promotionDate(promotionRequest.getPromotionDate())
                .academicYear(promotionRequest.getAcademicYear())
                .promotionOrderNumber(promotionRequest.getPromotionOrderNumber())
                .remarks(promotionRequest.getRemarks())
                .isCurrentDesignation(true)
                .build();
        
        StaffDesignation saved = staffDesignationRepository.save(newDesignation);
        
        log.info("Promoted user {} to {} effective from {}", 
                user.getEmployeeId(), promotionRequest.getNewDesignationType(), promotionRequest.getEffectiveFromDate());
        
        return mapToDTO(saved, user);
    }
    
    @Override
    public Map<String, Object> getDesignationStatistics() {
        List<Object[]> stats = staffDesignationRepository.getDesignationStatistics();
        
        Map<String, Long> designationCounts = new HashMap<>();
        long totalStaff = 0;
        
        for (Object[] stat : stats) {
            DesignationType type = (DesignationType) stat[0];
            Long count = (Long) stat[1];
            designationCounts.put(type.getDisplayName(), count);
            totalStaff += count;
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("designationCounts", designationCounts);
        result.put("totalStaff", totalStaff);
        result.put("lastUpdated", java.time.LocalDateTime.now());
        
        return result;
    }
    
    @Override
    public List<DesignationDTO> getUsersEligibleForPromotion(int yearsInCurrentDesignation) {
        LocalDate thresholdDate = LocalDate.now().minusYears(yearsInCurrentDesignation);
        List<StaffDesignation> eligibleDesignations = staffDesignationRepository.findUsersEligibleForPromotion(thresholdDate);
        
        return eligibleDesignations.stream()
                .map(designation -> {
                    DesignationDTO dto = mapToDTO(designation, designation.getUser());
                    dto.setIsEligibleForPromotion(true);
                    return dto;
                })
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Map<String, String>> getDesignationTypes() {
        return Arrays.stream(DesignationType.values())
                .map(type -> Map.of(
                        "value", type.name(),
                        "displayName", type.getDisplayName()
                ))
                .collect(Collectors.toList());
    }
    
    @Override
    public DesignationDTO updateDesignationDetails(UUID designationId, DesignationDTO designationDTO) {
        StaffDesignation designation = staffDesignationRepository.findById(designationId)
                .orElseThrow(() -> new ResourceNotFoundException("Designation not found"));
        
        // Update non-critical fields only
        designation.setPromotionOrderNumber(designationDTO.getPromotionOrderNumber());
        designation.setRemarks(designationDTO.getRemarks());
        
        StaffDesignation saved = staffDesignationRepository.save(designation);
        return mapToDTO(saved, saved.getUser());
    }
    
    @Override
    public DesignationDTO initializeDesignationForUser(UUID userId, String designationType, String academicYear) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // Check if user already has a designation for this academic year
        if (staffDesignationRepository.hasDesignationInAcademicYear(user, academicYear)) {
            throw new IllegalStateException("User already has designation for academic year: " + academicYear);
        }
        
        StaffDesignation designation = StaffDesignation.builder()
                .user(user)
                .designationType(DesignationType.valueOf(designationType))
                .effectiveFromDate(LocalDate.now())
                .academicYear(academicYear)
                .isCurrentDesignation(true)
                .build();
        
        StaffDesignation saved = staffDesignationRepository.save(designation);
        
        log.info("Initialized designation {} for user {} in academic year {}", 
                designationType, user.getEmployeeId(), academicYear);
        
        return mapToDTO(saved, user);
    }
    
    @Override
    public DesignationDTO getDesignationForScoring(UUID userId, LocalDate date) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        StaffDesignation designation = staffDesignationRepository.findDesignationByUserAndDate(user, date)
                .orElseThrow(() -> new ResourceNotFoundException("No designation found for the specified date"));
        
        return mapToDTO(designation, user);
    }
    
    // Helper methods
    private DesignationDTO mapToDTO(StaffDesignation designation, User user) {
        if (designation == null) {
            return null;
        }
        
        DesignationGroup group = designation.getDesignationGroup();
        
        DesignationDTO dto = DesignationDTO.builder()
                .id(designation.getId())
                .userId(user.getId())
                .employeeId(user.getEmployeeId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .departmentName(user.getDepartment() != null ? user.getDepartment().getName() : null)
                .designationType(designation.getDesignationType().name())
                .designationDisplayName(designation.getDesignationType().getDisplayName())
                .designationGroup(group.getDisplayName())
                .effectiveFromDate(designation.getEffectiveFromDate())
                .effectiveToDate(designation.getEffectiveToDate())
                .promotionDate(designation.getPromotionDate())
                .academicYear(designation.getAcademicYear())
                .isCurrentDesignation(designation.getIsCurrentDesignation())
                .promotionOrderNumber(designation.getPromotionOrderNumber())
                .remarks(designation.getRemarks())
                .partAMaxRaw(group.getPartAMaxRaw())
                .partBMaxRaw(group.getPartBMaxRaw())
                .partCMax(group.getPartCMax())
                .contactNumber(user.getContactNumber())
                .dateOfJoining(user.getDateOfJoining())
                .dateOfPromotionAtCVR(user.getDateOfPromotionAtCVR())
                .experienceAtCVRYears(user.getExperienceAtCVRYears())
                .totalTeachingExpYears(user.getTotalTeachingExpYears())
                .industryExpYears(user.getIndustryExpYears())
                .isHSFaculty(user.getIsHSFaculty())
                .build();
        
        // Calculate years in current designation
        if (designation.getIsCurrentDesignation()) {
            Period period = Period.between(designation.getEffectiveFromDate(), LocalDate.now());
            dto.setYearsInCurrentDesignation(period.getYears());
            dto.setIsEligibleForPromotion(period.getYears() >= 3); // 3+ years eligibility
        }
        
        return dto;
    }
    
    private DesignationHistoryDTO mapToHistoryDTO(StaffDesignation designation) {
        DesignationHistoryDTO dto = DesignationHistoryDTO.builder()
                .id(designation.getId())
                .designationType(designation.getDesignationType().name())
                .designationDisplayName(designation.getDesignationType().getDisplayName())
                .effectiveFromDate(designation.getEffectiveFromDate())
                .effectiveToDate(designation.getEffectiveToDate())
                .academicYear(designation.getAcademicYear())
                .isCurrentDesignation(designation.getIsCurrentDesignation())
                .promotionOrderNumber(designation.getPromotionOrderNumber())
                .promotionDate(designation.getPromotionDate())
                .remarks(designation.getRemarks())
                .createdAt(designation.getCreatedAt())
                .build();
        
        // Calculate duration
        LocalDate endDate = designation.getEffectiveToDate() != null ? designation.getEffectiveToDate() : LocalDate.now();
        Period period = Period.between(designation.getEffectiveFromDate(), endDate);
        dto.setDurationInYears(period.getYears());
        dto.setDurationInMonths(period.getMonths());
        dto.setDurationDescription(String.format("%d years, %d months", period.getYears(), period.getMonths()));
        
        return dto;
    }
} 