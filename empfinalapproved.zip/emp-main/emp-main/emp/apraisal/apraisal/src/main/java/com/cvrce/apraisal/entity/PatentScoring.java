package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "patent_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PatentScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    // Patent Details
    @Column(name = "patent_title", nullable = false, columnDefinition = "TEXT")
    private String patentTitle;
    
    @Column(name = "application_number", length = 100)
    private String applicationNumber;
    
    @Column(name = "filing_date")
    private LocalDate filingDate;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "patent_status", nullable = false)
    private PatentStatus patentStatus;
    
    @Column(name = "published_granted_date")
    private LocalDate publishedGrantedDate;
    
    // Inventors
    @Column(name = "total_cvr_inventors", nullable = false)
    @Builder.Default
    private Integer totalCVRInventors = 1;
    
    @Column(name = "cvr_inventor_names", columnDefinition = "TEXT")
    private String cvrInventorNames; // Comma-separated
    
    @Column(name = "faculty_inventor_position", nullable = false)
    @Builder.Default
    private Integer facultyInventorPosition = 1;
    
    // Scoring
    @Column(name = "max_points_for_status", precision = 10, scale = 2)
    private BigDecimal maxPointsForStatus;
    
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    @Column(name = "auto_calculated_points", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal autoCalculatedPoints = BigDecimal.ZERO;
    
    // Verification
    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private Boolean isVerified = false;
    
    @Column(name = "verification_source", length = 100)
    @Builder.Default
    private String verificationSource = "https://ipindiaservices.gov.in/publicsearch";
    
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Auto-calculate points based on status and inventor count
    public void calculatePoints() {
        if (patentStatus != null && totalCVRInventors != null && totalCVRInventors > 0) {
            BigDecimal basePoints = getBasePointsForStatus();
            this.autoCalculatedPoints = calculatePointsBasedOnInventors(basePoints, totalCVRInventors);
            
            if (pointsClaimed.compareTo(BigDecimal.ZERO) == 0) {
                this.pointsClaimed = autoCalculatedPoints;
            }
        }
    }
    
    private BigDecimal getBasePointsForStatus() {
        return switch (patentStatus) {
            case PUBLISHED -> new BigDecimal("7.5");
            case GRANTED -> new BigDecimal("15.0");
        };
    }
    
    private BigDecimal calculatePointsBasedOnInventors(BigDecimal basePoints, int inventorCount) {
        // Points distribution based on Table 3 from Annexure III
        return switch (inventorCount) {
            case 1 -> basePoints; // Full points
            case 2 -> basePoints.multiply(new BigDecimal("0.5")); // 50%
            case 3 -> basePoints.multiply(new BigDecimal("0.333")); // 33.3%
            case 4 -> basePoints.multiply(new BigDecimal("0.25")); // 25%
            case 5 -> basePoints.multiply(new BigDecimal("0.2")); // 20%
            default -> basePoints.multiply(new BigDecimal("0.167")); // 16.7% for 6+ inventors
        };
    }
    
    // Validation
    public boolean isValidForScoring() {
        return patentTitle != null && !patentTitle.trim().isEmpty() &&
               patentStatus != null &&
               totalCVRInventors != null && totalCVRInventors > 0;
    }
}

enum PatentStatus {
    PUBLISHED("Published", new BigDecimal("7.5")),
    GRANTED("Granted", new BigDecimal("15.0"));
    
    private final String displayName;
    private final BigDecimal maxPoints;
    
    PatentStatus(String displayName, BigDecimal maxPoints) {
        this.displayName = displayName;
        this.maxPoints = maxPoints;
    }
    
    public String getDisplayName() { return displayName; }
    public BigDecimal getMaxPoints() { return maxPoints; }
} 