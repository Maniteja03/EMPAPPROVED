package com.cvrce.apraisal.dto.department;

import lombok.Data;

@Data
public class DepartmentDTO {
    private Long id;
    private String name;
}
