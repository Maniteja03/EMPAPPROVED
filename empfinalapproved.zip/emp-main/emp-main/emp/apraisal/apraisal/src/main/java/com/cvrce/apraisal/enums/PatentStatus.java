package com.cvrce.apraisal.enums;

public enum PatentStatus {
    FILED,
    PUBLISHED,
    GRANTED
}
