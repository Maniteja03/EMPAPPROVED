package com.cvrce.apraisal.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "administrative_scoring")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AdministrativeScoring {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appraisal_scoring_id", nullable = false)
    private AppraisalScoring appraisalScoring;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "component_type", nullable = false)
    private AdministrativeComponent componentType;
    
    @Column(name = "work_details", nullable = false, columnDefinition = "TEXT")
    private String workDetails;
    
    @Column(name = "responsibilities", columnDefinition = "TEXT")
    private String responsibilities;
    
    // Scoring
    @Column(name = "max_points_for_component", precision = 10, scale = 2)
    private BigDecimal maxPointsForComponent;
    
    @Column(name = "points_claimed", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsClaimed = BigDecimal.ZERO;
    
    @Column(name = "points_awarded", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal pointsAwarded = BigDecimal.ZERO;
    
    // HOD Feedback (for component 4)
    @Column(name = "hod_feedback_score", precision = 10, scale = 2)
    private BigDecimal hodFeedbackScore;
    
    @Column(name = "hod_comments", columnDefinition = "TEXT")
    private String hodComments;
    
    // Verification
    @Column(name = "proof_document_path", columnDefinition = "TEXT")
    private String proofDocumentPath;
    
    // Review Comments
    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;
    
    @Column(name = "principal_remarks", columnDefinition = "TEXT")
    private String principalRemarks;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    // Initialize with component max points
    public void initializeWithComponent() {
        if (componentType != null) {
            this.maxPointsForComponent = new BigDecimal(componentType.getMaxPoints());
        }
    }
    
    // Validation
    public boolean isValidForScoring() {
        return componentType != null &&
               workDetails != null && !workDetails.trim().isEmpty();
    }
} 