package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.designation.DesignationDTO;
import com.cvrce.apraisal.dto.designation.DesignationHistoryDTO;
import com.cvrce.apraisal.dto.designation.PromotionRequestDTO;
import com.cvrce.apraisal.service.DesignationManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/designations")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class DesignationController {
    
    private final DesignationManagementService designationManagementService;
    
    // Get current designation for a user
    @GetMapping("/current/{userId}")
    @PreAuthorize("hasAnyRole('HOD', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<DesignationDTO> getCurrentDesignation(@PathVariable UUID userId) {
        log.info("Getting current designation for user: {}", userId);
        DesignationDTO designation = designationManagementService.getCurrentDesignation(userId);
        return ResponseEntity.ok(designation);
    }
    
    // Get designation history for a user
    @GetMapping("/history/{userId}")
    @PreAuthorize("hasAnyRole('HOD', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<DesignationHistoryDTO>> getDesignationHistory(@PathVariable UUID userId) {
        log.info("Getting designation history for user: {}", userId);
        List<DesignationHistoryDTO> history = designationManagementService.getDesignationHistory(userId);
        return ResponseEntity.ok(history);
    }
    
    // Get all current designations with pagination
    @GetMapping("/current")
    @PreAuthorize("hasAnyRole('HOD', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Page<DesignationDTO>> getAllCurrentDesignations(
            @RequestParam(required = false) String searchTerm,
            Pageable pageable) {
        
        log.info("Getting all current designations with search: {}", searchTerm);
        Page<DesignationDTO> designations = designationManagementService.getAllCurrentDesignations(searchTerm, pageable);
        return ResponseEntity.ok(designations);
    }
    
    // Get designations by department
    @GetMapping("/department/{departmentId}")
    @PreAuthorize("hasAnyRole('HOD', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<DesignationDTO>> getDesignationsByDepartment(@PathVariable UUID departmentId) {
        log.info("Getting designations for department: {}", departmentId);
        List<DesignationDTO> designations = designationManagementService.getDesignationsByDepartment(departmentId);
        return ResponseEntity.ok(designations);
    }
    
    // Promote user to new designation
    @PostMapping("/promote")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<DesignationDTO> promoteUser(@RequestBody PromotionRequestDTO promotionRequest) {
        log.info("Promoting user {} to designation {}", 
                promotionRequest.getUserId(), promotionRequest.getNewDesignationType());
        
        DesignationDTO newDesignation = designationManagementService.promoteUser(promotionRequest);
        return ResponseEntity.ok(newDesignation);
    }
    
    // Get designation statistics
    @GetMapping("/statistics")
    @PreAuthorize("hasAnyRole('CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<Map<String, Object>> getDesignationStatistics() {
        log.info("Getting designation statistics");
        Map<String, Object> statistics = designationManagementService.getDesignationStatistics();
        return ResponseEntity.ok(statistics);
    }
    
    // Get users eligible for promotion
    @GetMapping("/eligible-for-promotion")
    @PreAuthorize("hasAnyRole('CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<DesignationDTO>> getUsersEligibleForPromotion(
            @RequestParam(defaultValue = "3") int yearsInCurrentDesignation) {
        
        log.info("Getting users eligible for promotion ({}+ years)", yearsInCurrentDesignation);
        List<DesignationDTO> eligibleUsers = designationManagementService.getUsersEligibleForPromotion(yearsInCurrentDesignation);
        return ResponseEntity.ok(eligibleUsers);
    }
    
    // Get designation types
    @GetMapping("/types")
    @PreAuthorize("hasAnyRole('HOD', 'CHAIRPERSON', 'PRINCIPAL', 'ADMIN')")
    public ResponseEntity<List<Map<String, String>>> getDesignationTypes() {
        log.info("Getting all designation types");
        List<Map<String, String>> types = designationManagementService.getDesignationTypes();
        return ResponseEntity.ok(types);
    }
    
    // Update designation details (not promotion)
    @PutMapping("/{designationId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<DesignationDTO> updateDesignationDetails(
            @PathVariable UUID designationId,
            @RequestBody DesignationDTO designationDTO) {
        
        log.info("Updating designation details for: {}", designationId);
        DesignationDTO updated = designationManagementService.updateDesignationDetails(designationId, designationDTO);
        return ResponseEntity.ok(updated);
    }
} 