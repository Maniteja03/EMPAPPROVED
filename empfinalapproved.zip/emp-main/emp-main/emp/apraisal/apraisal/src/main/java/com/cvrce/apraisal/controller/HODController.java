package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.appraisal.AppraisalFormDTO;
import com.cvrce.apraisal.dto.review.ReviewDTO;
import com.cvrce.apraisal.service.HODService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/hod")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('HOD')")
public class HODController {

    private final HODService hodService;

    // Get HOD dashboard data
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getHODDashboard() {
        log.info("Fetching HOD dashboard data");
        return ResponseEntity.ok(hodService.getHODDashboard());
    }

    // Get appraisals pending HOD approval
    @GetMapping("/pending-approvals")
    public ResponseEntity<Page<AppraisalFormDTO>> getPendingApprovals(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submittedDate") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String department) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AppraisalFormDTO> pendingApprovals = hodService.getPendingApprovals(pageable, department);
        return ResponseEntity.ok(pendingApprovals);
    }

    // Submit HOD approval/rejection
    @PostMapping("/decision")
    public ResponseEntity<ReviewDTO> submitHODDecision(@Valid @RequestBody ReviewDTO reviewDTO) {
        // Get current authenticated user email
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        log.info("HOD submitting decision for appraisal: {} by authenticated user: {}", 
                reviewDTO.getAppraisalFormId(), currentUserEmail);
        
        ReviewDTO submittedDecision = hodService.submitHODDecision(reviewDTO, currentUserEmail);
        return ResponseEntity.ok(submittedDecision);
    }

    // Get specific appraisal for HOD review
    @GetMapping("/review/{formId}")
    public ResponseEntity<AppraisalFormDTO> getAppraisalForReview(@PathVariable UUID formId) {
        log.info("HOD accessing appraisal {} for review", formId);
        AppraisalFormDTO appraisal = hodService.getAppraisalForHODReview(formId);
        return ResponseEntity.ok(appraisal);
    }

    // Get HOD review history
    @GetMapping("/review-history")
    public ResponseEntity<Page<ReviewDTO>> getReviewHistory(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String academicYear) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("reviewedAt").descending());
        Page<ReviewDTO> reviewHistory = hodService.getHODReviewHistory(pageable, academicYear);
        return ResponseEntity.ok(reviewHistory);
    }

    // Get department statistics
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getDepartmentStatistics(
            @RequestParam(required = false) String academicYear,
            @RequestParam(required = false) String department) {
        log.info("Fetching department statistics for academic year: {} and department: {}", 
                academicYear, department);
        Map<String, Object> statistics = hodService.getDepartmentStatistics(academicYear, department);
        return ResponseEntity.ok(statistics);
    }

    // Get staff performance overview
    @GetMapping("/staff-performance")
    public ResponseEntity<Map<String, Object>> getStaffPerformanceOverview(
            @RequestParam(required = false) String academicYear,
            @RequestParam(required = false) String department) {
        log.info("Fetching staff performance overview for academic year: {} and department: {}", 
                academicYear, department);
        Map<String, Object> overview = hodService.getStaffPerformanceOverview(academicYear, department);
        return ResponseEntity.ok(overview);
    }
} 