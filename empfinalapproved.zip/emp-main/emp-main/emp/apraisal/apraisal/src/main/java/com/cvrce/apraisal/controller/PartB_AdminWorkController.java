package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.partb.AdminWorkDTO;
import com.cvrce.apraisal.service.PartB_AdminWorkService;
import com.cvrce.apraisal.service.AppraisalFormService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/partb/admin-work")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
public class PartB_AdminWorkController {

    private final PartB_AdminWorkService adminWorkService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping
    public ResponseEntity<AdminWorkDTO> add(@Valid @RequestBody AdminWorkDTO dto) {
        // SECURITY FIX: Validate ownership before allowing data modification
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized admin work creation attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Adding admin work to form {} by authorized user {}", dto.getAppraisalFormId(), currentUserEmail);
        return new ResponseEntity<>(adminWorkService.add(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<AdminWorkDTO>> getByForm(@PathVariable UUID formId) {
        // SECURITY FIX: Validate access before allowing data retrieval
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized admin work access attempt on form {} by user {}", 
                    formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Fetching admin work for form {} by authorized user {}", formId, currentUserEmail);
        return ResponseEntity.ok(adminWorkService.getByFormId(formId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AdminWorkDTO> update(@PathVariable UUID id, @RequestBody AdminWorkDTO dto) {
        // SECURITY FIX: Validate ownership before allowing updates
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized admin work update attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Updating admin work with ID {} by authorized user {}", id, currentUserEmail);
        return ResponseEntity.ok(adminWorkService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        // SECURITY FIX: Validate ownership before allowing deletion
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            adminWorkService.delete(id, currentUserEmail);
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            log.warn("Unauthorized admin work deletion attempt for ID {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}
