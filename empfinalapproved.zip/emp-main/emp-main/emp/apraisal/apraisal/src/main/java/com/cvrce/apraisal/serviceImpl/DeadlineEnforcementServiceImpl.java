package com.cvrce.apraisal.serviceImpl;

import com.cvrce.apraisal.dto.timeline.AppraisalTimelineDTO;
import com.cvrce.apraisal.entity.AppraisalTimeline;
import com.cvrce.apraisal.repo.AppraisalTimelineRepository;
import com.cvrce.apraisal.service.DeadlineEnforcementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class DeadlineEnforcementServiceImpl implements DeadlineEnforcementService {
    
    private final AppraisalTimelineRepository timelineRepository;
    
    @Override
    public boolean isStaffUploadAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            log.warn("No timeline found for academic year: {}", academicYear);
            return true; // Default to allowing if no timeline configured
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getStaffUploadDeadline()) || today.isEqual(t.getStaffUploadDeadline());
    }
    
    @Override
    public boolean isHodDcmAssignmentAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true; // Default to allowing if no timeline configured
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getHodDcmAssignmentDeadline()) || today.isEqual(t.getHodDcmAssignmentDeadline());
    }
    
    @Override
    public boolean isDcmReviewAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getDcmReviewDeadline()) || today.isEqual(t.getDcmReviewDeadline());
    }
    
    @Override
    public boolean isHodReviewAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getHodReviewDeadline()) || today.isEqual(t.getHodReviewDeadline());
    }
    
    @Override
    public boolean isCommitteeReviewAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getCommitteeReviewDeadline()) || today.isEqual(t.getCommitteeReviewDeadline());
    }
    
    @Override
    public boolean isChairpersonReviewAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getChairpersonReviewDeadline()) || today.isEqual(t.getChairpersonReviewDeadline());
    }
    
    @Override
    public boolean isPrincipalReviewAllowed(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return true;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        return today.isBefore(t.getPrincipalBulkSubmissionDate()) || today.isEqual(t.getPrincipalBulkSubmissionDate());
    }
    
    @Override
    public String getDeadlineEnforcementMessage(String academicYear, String action) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return "No timeline configured for academic year " + academicYear;
        }
        
        AppraisalTimeline t = timeline.get();
        LocalDate today = LocalDate.now();
        
        switch (action) {
            case "STAFF_UPLOAD":
                return today.isAfter(t.getStaffUploadDeadline()) ? 
                    "Staff upload deadline passed on " + t.getStaffUploadDeadline() : 
                    "Staff upload allowed until " + t.getStaffUploadDeadline();
            case "HOD_DCM_ASSIGNMENT":
                return today.isAfter(t.getHodDcmAssignmentDeadline()) ? 
                    "HOD DCM assignment deadline passed on " + t.getHodDcmAssignmentDeadline() : 
                    "HOD DCM assignment allowed until " + t.getHodDcmAssignmentDeadline();
            case "COMMITTEE_REVIEW":
                return today.isAfter(t.getCommitteeReviewDeadline()) ? 
                    "Committee review deadline passed on " + t.getCommitteeReviewDeadline() : 
                    "Committee review allowed until " + t.getCommitteeReviewDeadline();
            default:
                return "Timeline action not recognized: " + action;
        }
    }
    
    @Override
    public void validateFormSubmissionDeadline(UUID formId, String academicYear, String action) {
        boolean allowed = false;
        String currentPhase = getCurrentPhase(academicYear);
        
        switch (action) {
            case "STAFF_UPLOAD":
                allowed = isStaffUploadAllowed(academicYear);
                break;
            case "DCM_REVIEW":
                allowed = isDcmReviewAllowed(academicYear);
                break;
            case "HOD_REVIEW":
                allowed = isHodReviewAllowed(academicYear);
                break;
            case "COMMITTEE_REVIEW":
                allowed = isCommitteeReviewAllowed(academicYear);
                break;
            case "CHAIRPERSON_REVIEW":
                allowed = isChairpersonReviewAllowed(academicYear);
                break;
            case "PRINCIPAL_REVIEW":
                allowed = isPrincipalReviewAllowed(academicYear);
                break;
        }
        
        if (!allowed) {
            String message = getDeadlineEnforcementMessage(academicYear, action);
            throw new DeadlineViolationException(message, academicYear, action, currentPhase);
        }
    }
    
    @Override
    public AppraisalTimelineDTO getActiveTimeline(String academicYear) {
        return timelineRepository.findByAcademicYearAndActive(academicYear)
                .map(this::mapToDTO)
                .orElse(null);
    }
    
    @Override
    public boolean isDeadlineApproaching(String academicYear, int daysAhead) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return false;
        }
        
        LocalDate today = LocalDate.now();
        LocalDate checkDate = today.plusDays(daysAhead);
        AppraisalTimeline t = timeline.get();
        
        // Check if any deadline falls within the next 'daysAhead' days
        return checkDate.isAfter(t.getStaffUploadDeadline()) ||
               checkDate.isAfter(t.getHodDcmAssignmentDeadline()) ||
               checkDate.isAfter(t.getDcmReviewDeadline()) ||
               checkDate.isAfter(t.getHodReviewDeadline()) ||
               checkDate.isAfter(t.getCommitteeReviewDeadline()) ||
               checkDate.isAfter(t.getChairpersonReviewDeadline()) ||
               checkDate.isAfter(t.getPrincipalBulkSubmissionDate());
    }
    
    @Override
    public boolean forceAllowAction(String academicYear, String action, String adminEmail, String reason) {
        log.warn("ADMIN OVERRIDE: {} forcing action '{}' for {} - Reason: {}", 
                adminEmail, action, academicYear, reason);
        // TODO: Implement admin override logic (audit logging, temporary permits)
        return true;
    }
    
    @Override
    public String getCurrentPhase(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return "NO_TIMELINE";
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        
        if (today.isBefore(t.getStaffUploadDeadline()) || today.isEqual(t.getStaffUploadDeadline())) {
            return "STAFF_UPLOAD";
        } else if (today.isBefore(t.getHodDcmAssignmentDeadline()) || today.isEqual(t.getHodDcmAssignmentDeadline())) {
            return "HOD_DCM_ASSIGNMENT";
        } else if (today.isBefore(t.getDcmReviewDeadline()) || today.isEqual(t.getDcmReviewDeadline())) {
            return "DCM_REVIEW";
        } else if (today.isBefore(t.getHodReviewDeadline()) || today.isEqual(t.getHodReviewDeadline())) {
            return "HOD_REVIEW";
        } else if (today.isBefore(t.getCommitteeReviewDeadline()) || today.isEqual(t.getCommitteeReviewDeadline())) {
            return "COMMITTEE_REVIEW";
        } else if (today.isBefore(t.getChairpersonReviewDeadline()) || today.isEqual(t.getChairpersonReviewDeadline())) {
            return "CHAIRPERSON_REVIEW";
        } else if (today.isBefore(t.getPrincipalBulkSubmissionDate()) || today.isEqual(t.getPrincipalBulkSubmissionDate())) {
            return "PRINCIPAL_REVIEW";
        } else {
            return "CLOSED";
        }
    }
    
    @Override
    public long getDaysRemainingForCurrentPhase(String academicYear) {
        Optional<AppraisalTimeline> timeline = timelineRepository.findByAcademicYearAndActive(academicYear);
        if (timeline.isEmpty()) {
            return -1;
        }
        
        LocalDate today = LocalDate.now();
        AppraisalTimeline t = timeline.get();
        String currentPhase = getCurrentPhase(academicYear);
        
        switch (currentPhase) {
            case "STAFF_UPLOAD":
                return ChronoUnit.DAYS.between(today, t.getStaffUploadDeadline());
            case "HOD_DCM_ASSIGNMENT":
                return ChronoUnit.DAYS.between(today, t.getHodDcmAssignmentDeadline());
            case "DCM_REVIEW":
                return ChronoUnit.DAYS.between(today, t.getDcmReviewDeadline());
            case "HOD_REVIEW":
                return ChronoUnit.DAYS.between(today, t.getHodReviewDeadline());
            case "COMMITTEE_REVIEW":
                return ChronoUnit.DAYS.between(today, t.getCommitteeReviewDeadline());
            case "CHAIRPERSON_REVIEW":
                return ChronoUnit.DAYS.between(today, t.getChairpersonReviewDeadline());
            case "PRINCIPAL_REVIEW":
                return ChronoUnit.DAYS.between(today, t.getPrincipalBulkSubmissionDate());
            default:
                return 0;
        }
    }
    
    private AppraisalTimelineDTO mapToDTO(AppraisalTimeline timeline) {
        return AppraisalTimelineDTO.builder()
                .id(timeline.getId())
                .academicYear(timeline.getAcademicYear())
                .createdByChairpersonId(timeline.getCreatedByChairperson().getId())
                .createdByChairpersonName(timeline.getCreatedByChairperson().getFullName())
                .staffUploadStartDate(timeline.getStaffUploadStartDate())
                .staffUploadDeadline(timeline.getStaffUploadDeadline())
                .hodDcmAssignmentDeadline(timeline.getHodDcmAssignmentDeadline())
                .dcmReviewDeadline(timeline.getDcmReviewDeadline())
                .hodReviewDeadline(timeline.getHodReviewDeadline())
                .committeeReviewDeadline(timeline.getCommitteeReviewDeadline())
                .chairpersonReviewDeadline(timeline.getChairpersonReviewDeadline())
                .principalBulkSubmissionDate(timeline.getPrincipalBulkSubmissionDate())
                .isActive(timeline.getIsActive())
                .currentPhase(timeline.getCurrentPhase())
                .timelineDescription(timeline.getTimelineDescription())
                .createdAt(timeline.getCreatedAt())
                .updatedAt(timeline.getUpdatedAt())
                .finalizedAt(timeline.getFinalizedAt())
                .sendDeadlineReminders(timeline.getSendDeadlineReminders())
                .reminderDaysBeforeDeadline(timeline.getReminderDaysBeforeDeadline())
                .totalStaffCount(timeline.getTotalStaffCount())
                .totalDepartmentsCount(timeline.getTotalDepartmentsCount())
                .isFinalized(timeline.isFinalized())
                .build();
    }
}

/**
 * Exception thrown when deadline is violated
 */
class DeadlineViolationException extends RuntimeException {
    private final String academicYear;
    private final String action;
    private final String currentPhase;
    
    public DeadlineViolationException(String message, String academicYear, String action, String currentPhase) {
        super(message);
        this.academicYear = academicYear;
        this.action = action;
        this.currentPhase = currentPhase;
    }
    
    public String getAcademicYear() { return academicYear; }
    public String getAction() { return action; }
    public String getCurrentPhase() { return currentPhase; }
} 