package com.cvrce.apraisal.entity;

public enum DesignationGroup {
    PROFESSOR("Professor Level", 100, 100, 25), // Part A raw, Part B raw, Part C
    ASSOCIATE_LEVEL("Associate Level", 75, 95, 25), // Sr.Assoc, Assoc, Doctorate
    ASSISTANT_LEVEL("Assistant Level", 50, 85, 25); // Assistant Professor
    
    private final String displayName;
    private final int partAMaxRaw;
    private final int partBMaxRaw; 
    private final int partCMax;
    
    DesignationGroup(String displayName, int partAMaxRaw, int partBMaxRaw, int partCMax) {
        this.displayName = displayName;
        this.partAMaxRaw = partAMaxRaw;
        this.partBMaxRaw = partBMaxRaw;
        this.partCMax = partCMax;
    }
    
    public String getDisplayName() { return displayName; }
    public int getPartAMaxRaw() { return partAMaxRaw; }
    public int getPartBMaxRaw() { return partBMaxRaw; }
    public int getPartCMax() { return partCMax; }
} 