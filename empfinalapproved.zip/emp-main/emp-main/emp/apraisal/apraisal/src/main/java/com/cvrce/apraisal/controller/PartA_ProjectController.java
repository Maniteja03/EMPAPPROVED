package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.parta.ProjectDTO;
import com.cvrce.apraisal.service.PartA_ProjectService;
import com.cvrce.apraisal.service.AppraisalFormService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/parta/projects")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('STAFF') or hasRole('ADMIN')")
public class PartA_ProjectController {

    private final PartA_ProjectService projectService;
    private final AppraisalFormService appraisalFormService;

    @PostMapping
    public ResponseEntity<ProjectDTO> add(@Valid @RequestBody ProjectDTO dto) {
        // SECURITY FIX: Validate ownership before allowing data modification
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized project creation attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Adding project to form {} by authorized user {}", dto.getAppraisalFormId(), currentUserEmail);
        return new ResponseEntity<>(projectService.addProject(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{formId}")
    public ResponseEntity<List<ProjectDTO>> getByForm(@PathVariable UUID formId) {
        // SECURITY FIX: Validate access before allowing data retrieval
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(formId, currentUserEmail)) {
            log.warn("Unauthorized project access attempt on form {} by user {}", 
                    formId, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Fetching projects for form {} by authorized user {}", formId, currentUserEmail);
        return ResponseEntity.ok(projectService.getProjectsByFormId(formId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProjectDTO> update(@PathVariable UUID id, @Valid @RequestBody ProjectDTO dto) {
        // SECURITY FIX: Validate ownership before allowing updates
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        if (!appraisalFormService.canUserAccessForm(dto.getAppraisalFormId(), currentUserEmail)) {
            log.warn("Unauthorized project update attempt on form {} by user {}", 
                    dto.getAppraisalFormId(), currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        log.info("Updating project {} by authorized user {}", id, currentUserEmail);
        return ResponseEntity.ok(projectService.updateProject(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        // SECURITY FIX: Validate ownership before allowing deletion
        String currentUserEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        
        try {
            projectService.deleteProject(id, currentUserEmail);
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            log.warn("Unauthorized project deletion attempt for ID {} by user {}", id, currentUserEmail);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
    }
}
