package com.cvrce.apraisal.controller;

import com.cvrce.apraisal.dto.user.*;
import com.cvrce.apraisal.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<UserResponseDTO> getMyProfile() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        log.info("Fetching profile for user: {}", email);
        return ResponseEntity.ok(userService.getUserByEmail(email));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('HOD') or @userService.isUserAllowedToViewProfile(#id, authentication.name)")
    public ResponseEntity<UserResponseDTO> getUserById(@PathVariable UUID id) {
        log.info("Fetching user by ID: {}", id);
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @GetMapping("/department/{deptId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('HOD') or hasRole('DCM')")
    public ResponseEntity<Page<UserResponseDTO>> getUsersByDepartment(
            @PathVariable Long deptId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "fullName") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        log.info("Listing users from department ID: {} with pagination", deptId);
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<UserResponseDTO> users = userService.getUsersByDepartment(deptId, pageable);
        return ResponseEntity.ok(users);
    }

    // List all users with pagination (admin only)
    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<UserResponseDTO>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "fullName") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long departmentId,
            @RequestParam(required = false) Boolean enabled) {
        
        log.info("Listing all users with pagination - page: {}, size: {}", page, size);
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<UserResponseDTO> users = userService.getAllUsers(pageable, search, departmentId, enabled);
        return ResponseEntity.ok(users);
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponseDTO> createUser(@Valid @RequestBody UserCreateDTO dto) {
        log.info("Creating new user with email: {}", dto.getEmail());
        return new ResponseEntity<>(userService.createUser(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or @userService.isCurrentUser(#id, authentication.name)")
    public ResponseEntity<UserResponseDTO> updateUser(
            @PathVariable UUID id, 
            @Valid @RequestBody UserUpdateDTO dto) {
        log.info("Updating user: {}", id);
        return ResponseEntity.ok(userService.updateUser(id, dto));
    }

    @PostMapping("/enable/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> toggleUserStatus(@PathVariable UUID id, @RequestParam boolean enable) {
        log.info("Toggling enabled status for user {} => {}", id, enable);
        userService.setUserEnabled(id, enable);
        return ResponseEntity.accepted().body("User status updated");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> softDeleteUser(@PathVariable UUID id) {
        log.info("Soft deleting user {}", id);
        userService.softDeleteUser(id);
        return ResponseEntity.ok("User deleted (soft)");
    }

    // Search users with pagination
    @GetMapping("/search")
    @PreAuthorize("hasRole('ADMIN') or hasRole('HOD') or hasRole('DCM')")
    public ResponseEntity<Page<UserResponseDTO>> searchUsers(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "fullName") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        log.info("Searching users with query: {}", query);
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<UserResponseDTO> results = userService.searchUsers(query, pageable);
        return ResponseEntity.ok(results);
    }

    // Get users by role with pagination
    @GetMapping("/role/{roleName}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('HOD')")
    public ResponseEntity<Page<UserResponseDTO>> getUsersByRole(
            @PathVariable String roleName,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "fullName") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        log.info("Listing users with role: {} with pagination", roleName);
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<UserResponseDTO> users = userService.getUsersByRole(roleName, pageable);
        return ResponseEntity.ok(users);
    }
}
