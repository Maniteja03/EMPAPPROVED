package com.cvrce.apraisal.exception;

import lombok.Getter;

@Getter
public class SystemException extends RuntimeException {
    
    private final String errorCode;
    private final String systemComponent;
    
    public SystemException(String message, String systemComponent) {
        super(message);
        this.errorCode = "SYSTEM_ERROR";
        this.systemComponent = systemComponent;
    }
    
    public SystemException(String message, String errorCode, String systemComponent) {
        super(message);
        this.errorCode = errorCode;
        this.systemComponent = systemComponent;
    }
    
    public SystemException(String message, String systemComponent, Throwable cause) {
        super(message, cause);
        this.errorCode = "SYSTEM_ERROR";
        this.systemComponent = systemComponent;
    }
    
    public SystemException(String message, String errorCode, String systemComponent, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.systemComponent = systemComponent;
    }
}

// Specific system exception classes
class DatabaseException extends SystemException {
    public DatabaseException(String message) {
        super(message, "DATABASE_ERROR", "DATABASE");
    }
    
    public DatabaseException(String message, Throwable cause) {
        super(message, "DATABASE_ERROR", "DATABASE", cause);
    }
}

class ExternalServiceException extends SystemException {
    public ExternalServiceException(String message, String serviceName) {
        super(message, "EXTERNAL_SERVICE_ERROR", serviceName);
    }
    
    public ExternalServiceException(String message, String serviceName, Throwable cause) {
        super(message, "EXTERNAL_SERVICE_ERROR", serviceName, cause);
    }
}

class ConfigurationException extends SystemException {
    public ConfigurationException(String message) {
        super(message, "CONFIGURATION_ERROR", "SYSTEM_CONFIG");
    }
}

class SecurityException extends SystemException {
    public SecurityException(String message) {
        super(message, "SECURITY_ERROR", "SECURITY");
    }
    
    public SecurityException(String message, Throwable cause) {
        super(message, "SECURITY_ERROR", "SECURITY", cause);
    }
}

class NotificationException extends SystemException {
    public NotificationException(String message) {
        super(message, "NOTIFICATION_ERROR", "NOTIFICATION_SERVICE");
    }
    
    public NotificationException(String message, Throwable cause) {
        super(message, "NOTIFICATION_ERROR", "NOTIFICATION_SERVICE", cause);
    }
}

class PdfGenerationException extends SystemException {
    public PdfGenerationException(String message) {
        super(message, "PDF_GENERATION_ERROR", "PDF_SERVICE");
    }
    
    public PdfGenerationException(String message, Throwable cause) {
        super(message, "PDF_GENERATION_ERROR", "PDF_SERVICE", cause);
    }
} 