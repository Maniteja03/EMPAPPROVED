package com.cvrce.apraisal.service;

import com.cvrce.apraisal.dto.dcm.DCMAssignmentDTO;
import com.cvrce.apraisal.dto.dcm.DCMSelectionDTO;
import com.cvrce.apraisal.dto.dcm.DCMValidationResult;
import com.cvrce.apraisal.dto.dcm.DCMWorkloadStats;
import com.cvrce.apraisal.entity.User;

import java.util.List;
import java.util.UUID;

public interface DCMManagementService {
    
    /**
     * Get all eligible staff members for DCM assignment in HOD's department
     * @param hodEmail The HOD's email
     * @param academicYear The academic year
     * @return List of eligible staff members
     */
    List<DCMSelectionDTO> getEligibleStaffForDCM(String hodEmail, String academicYear);
    
    /**
     * Get currently assigned DCMs for HOD's department
     * @param hodEmail The HOD's email  
     * @param academicYear The academic year
     * @return List of current DCM assignments
     */
    List<DCMAssignmentDTO> getCurrentDCMAssignments(String hodEmail, String academicYear);
    
    /**
     * Assign staff members as DCMs for the department
     * @param hodEmail The HOD making the assignment
     * @param staffIds List of staff member IDs to assign as DCMs
     * @param academicYear The academic year
     * @return List of created DCM assignments
     */
    List<DCMAssignmentDTO> assignDCMs(String hodEmail, List<UUID> staffIds, String academicYear);
    
    /**
     * Remove DCM assignment for a staff member
     * @param hodEmail The HOD removing the assignment
     * @param dcmAssignmentId The DCM assignment ID to remove
     * @return true if successfully removed
     */
    boolean removeDCMAssignment(String hodEmail, UUID dcmAssignmentId);
    
    /**
     * Replace all current DCM assignments with new ones
     * @param hodEmail The HOD making the replacement
     * @param staffIds New list of staff member IDs to assign as DCMs
     * @param academicYear The academic year
     * @return List of new DCM assignments
     */
    List<DCMAssignmentDTO> replaceDCMAssignments(String hodEmail, List<UUID> staffIds, String academicYear);
    
    /**
     * Check if a staff member is currently a DCM
     * @param staffMember The staff member to check
     * @param academicYear The academic year
     * @return true if staff member is currently a DCM
     */
    boolean isStaffMemberDCM(User staffMember, String academicYear);
    
    /**
     * Get DCM assignments for a specific staff member (their history)
     * @param staffId The staff member ID
     * @return List of DCM assignment history
     */
    List<DCMAssignmentDTO> getDCMAssignmentHistory(UUID staffId);
    
    /**
     * Get all DCMs across all departments for a specific academic year
     * @param academicYear The academic year
     * @return List of all DCM assignments
     */
    List<DCMAssignmentDTO> getAllDCMsForYear(String academicYear);
    
    /**
     * Validate DCM assignment constraints
     * @param hodEmail The HOD email
     * @param staffIds List of staff IDs to validate
     * @param academicYear The academic year
     * @return Validation result with any error messages
     */
    DCMValidationResult validateDCMAssignments(String hodEmail, List<UUID> staffIds, String academicYear);
    
    /**
     * Get DCM workload statistics for a department
     * @param hodEmail The HOD email
     * @param academicYear The academic year
     * @return DCM workload statistics
     */
    DCMWorkloadStats getDCMWorkloadStats(String hodEmail, String academicYear);
} 