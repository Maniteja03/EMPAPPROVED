package com.cvrce.apraisal.dto.auth;

import lombok.Data;
import jakarta.validation.constraints.*;

@Data
public class LoginRequestDTO {
    
    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    private String email;
    
    @NotBlank(message = "Password is required")
    private String password;
}
