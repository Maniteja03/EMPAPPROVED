package com.cvrce.apraisal.service;

import com.cvrce.apraisal.entity.AppraisalScoring;
import com.cvrce.apraisal.entity.StaffDesignation;
import com.cvrce.apraisal.dto.scoring.ScoringCalculationResult;
import com.cvrce.apraisal.dto.scoring.ComponentScoreBreakdown;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public interface ScoringCalculationService {
    
    /**
     * Calculate complete scoring for an appraisal form
     */
    ScoringCalculationResult calculateCompleteScoring(UUID appraisalFormId);
    
    /**
     * Calculate Part A scoring (Research and Professional Practice)
     */
    BigDecimal calculatePartAScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Part B scoring (Professional Contribution and Others)
     */
    BigDecimal calculatePartBScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Part C scoring (Student Trainings and Certifications)
     */
    BigDecimal calculatePartCScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Publications scoring (Annexure I)
     */
    BigDecimal calculatePublicationsScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Citations scoring (Annexure II)
     */
    BigDecimal calculateCitationsScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Patents scoring (Annexure III)
     */
    BigDecimal calculatePatentsScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Projects scoring (Annexure IV)
     */
    BigDecimal calculateProjectsScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Consultancy scoring (Annexure V)
     */
    BigDecimal calculateConsultancyScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Teaching Performance scoring (Annexure VI)
     */
    BigDecimal calculateTeachingPerformanceScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Conference scoring (Annexure VII & VIII)
     */
    BigDecimal calculateConferenceScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Administrative scoring (Annexure XII)
     */
    BigDecimal calculateAdministrativeScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Calculate Student Training scoring (Part C)
     */
    BigDecimal calculateStudentTrainingScoring(AppraisalScoring appraisalScoring);
    
    /**
     * Apply H&S Faculty special logic (50% from organizing events)
     */
    void applyHSFacultyLogic(AppraisalScoring appraisalScoring);
    
    /**
     * Get detailed scoring breakdown
     */
    List<ComponentScoreBreakdown> getDetailedScoreBreakdown(UUID appraisalFormId);
    
    /**
     * Validate scoring against designation limits
     */
    boolean validateScoringLimits(AppraisalScoring appraisalScoring);
    
    /**
     * Auto-calculate all component scores
     */
    void autoCalculateAllScores(AppraisalScoring appraisalScoring);
    
    /**
     * Apply manual override to specific component
     */
    void applyManualOverride(UUID appraisalFormId, String componentType, BigDecimal overrideScore, String reason);
    
    /**
     * Get maximum possible scores for designation
     */
    ComponentScoreBreakdown getMaxScoresForDesignation(StaffDesignation designation);
    
    /**
     * Recalculate scoring after component update
     */
    void recalculateScoring(UUID appraisalFormId);
} 